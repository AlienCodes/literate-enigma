#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('Greyback', '灰背'),
     ('cane', '蔗'),
     ('**beetles**,', '**甲虫**(beetles)'),
     ('whose', '它的'),
     ('**larvae**', '**幼虫**(larvae)'),
     ('**devour**', '**啃食**(devour)'),
     ('roots,', '根系，')],
    '（whose larvae devour roots：定语从句，修饰 beetles）'],
   [[('were **plaguing**', '正**困扰**(plaguing)着'),
     ('**lucrative**', '**利润丰厚的**(lucrative)'),
     ('sugar', '甘蔗'),
     ('**plantations**', '**种植园**(plantations)，'),
     ('in Queensland, north-eastern Australia.', '此种植园位于澳大利亚东北部的昆士兰州。')],
    '（in Queensland：后置定语，修饰 plantations；\nnorth-eastern Australia：同位语，补充说明 Queensland）']]),
 (1,
  [[[('In June 1935', '1935年6月，'),
     ('Queensland', '昆士兰州'),
     ('**imported**', '从夏威夷**引进了**(imported)'),
     ('102', '102只'),
     ('cane', '甘蔗'),
     ('toads,', '蟾蜍，')]],
   [[('**bulky**', '这是一种**原产于**(native to)美洲、**庞大笨重的**(bulky)'),
     ('**amphibians** **native to** the Americas, from Hawaii.', '**两栖动物**(amphibians)。')],
    '（bulky amphibians native to the Americas：同位语，补充说明 cane toads；\n'
    'native to…：原产于……；from Hawaii：修饰 imported）']]),
 (1,
  [[[('That August', '同年8月，'),
     ('about 2,400 of their young', '它们的约2,400只后代'),
     ('were **released**.', '被**释放**(released)到野外。')],
    '（young：名词，指动物的幼崽、后代）']]),
 (1,
  [[[('**Biological**', '**生物的**(Biological)'),
     ('control,', '防治，'),
     ('setting', '即用'),
     ('one **species**', '一个**物种**(species)'),
     ('against', '去对付'),
     ('a **pest**,', '一种**害虫**(pest)，')],
    '（setting one species against a pest：现在分词短语，补充说明 Biological control；\nset A against B：用 A 对付 B）'],
   [[('had', '就此迎来了'),
     ('an', '一名'),
     ('**ambitious**', '**雄心勃勃的**(ambitious)'),
     ('new **recruit**.', '**新兵**(recruit)。')],
    '（recruit：新兵，这里指刚被派上场的甘蔗蟾蜍）']]),
 (2,
  [[[('The **hasty** plan', '这个**草率的**(hasty)计划'), ('met **opposition**.', '遭到了**反对**(opposition)。')],
    '（meet opposition：遭到反对）']]),
 (2,
  [[[('In November 1935', '1935年11月，'),
     ('an insect', '昆虫'),
     ('expert,', '专家'),
     ('Walter Froggatt,', '沃尔特·弗罗格特'),
     ('**persuaded**', '**说服**(persuaded)'),
     ('officials', '官员'),
     ('to **halt**', '**停止**(halt)'),
     ('releases;', '释放；')],
    '（Walter Froggatt：同位语，补充说明 an insect expert；\npersuade sb to do sth：说服某人做某事）'],
   [[('after', '经'),
     ("Queensland's **lobbying**,", '昆士兰州**游说**(lobbying)，'),
     ('they', '释放'),
     ('**resumed** in September 1936.', '于1936年9月**恢复**(resumed)。')],
    '（they：指 releases，即释放）']]),
 (2,
  [[[('The **scheme**', '这套**计划/方案**(scheme)'),
     ('**flopped**:', '**彻底失败**(flopped)：'),
     ('the toads', '蟾蜍'),
     ('barely', '几乎没能'),
     ('**dented**', '**削减**(dented)'),
     ('beetle', '甲虫的'),
     ('numbers,', '数量，')],
    '（barely：几乎不，带否定意味；\n冒号后的分句具体说明 flopped）'],
   [[('perhaps', '或许'),
     ('because', '是因为'),
     ('the insects', '这些昆虫'),
     ('stayed', '一直待在'),
     ('high up on cane **stalks**.', '甘蔗**茎秆**(stalks)的高处。')],
    '（perhaps because…：原因状语从句，表推测）']]),
 (3,
  [[[('The toads', '蟾蜍自己'), ('**thrived** instead.', '反倒**兴旺**(thrived)起来。')],
    '（instead：反而，\n和上文甲虫没被消灭形成对照）']]),
 (3,
  [[[('With few **foes**', '**天敌**(foes)寥寥，'),
     ('and **fertile** females', '**能生育的**(fertile)雌蟾'),
     ('**spawning**', '**产下**(spawning)'),
     ('thousands of', '数千枚'),
     ('eggs,', '卵，')],
    '（with＋名词＋现在分词：with 复合结构作原因状语；\nfoes：敌人，这里指天敌）'],
   [[('they', '它们'), ('**multiplied** **unchecked**.', '**不受遏制地**(unchecked)**大量繁殖**(multiplied)。')],
    '（unchecked：形容词作状语，说明繁殖的状态）']]),
 (3,
  [[[('Their', '它们的'),
     ('**invasion**', '**入侵**(invasion)'),
     ('**frontier**,', '**前沿**(frontier)'),
     ('creeping about ten kilometres a year at first,', '起初每年缓慢行进约十公里，')],
    '（creeping…：现在分词短语作插入语，补充说明 frontier；\ncreep：缓慢移动）'],
   [[('**accelerated** to about 50 a year in the **tropical** north.',
      '到了**热带**(tropical)北部，**加快**(accelerated)到每年约50公里。')],
    '（about 50 a year：省略了 kilometres）']]),
 (3,
  [[[('In February 2009', '2009年2月，'),
     ('the first known', '已知的第一只'),
     ('toad', '蟾蜍'),
     ('**breached**', '**突破了**(breached)'),
     ("Western Australia's border.", '西澳大利亚州的边界。')],
    '（first known：已知的第一个）']]),
 (4,
  [[[('**Toxin**', '它们皮肤里的**毒素**(Toxin)'),
     ('**glands** in their skin', '**腺体**(glands)，'),
     ('make', '使'),
     ('them', '它们成为了'),
     ('a', '一顿'),
     ('deadly', '致命的'),
     ('meal.', '餐食。')],
    '（make A B：使 A 成为 B；\nToxin glands：毒腺，toxin 作定语）']]),
 (4,
  [[[('Numbers of goannas', '巨蜥'),
     ('(large', '（大型'),
     ('**lizards**)', '**蜥蜴**(lizards)）'),
     ('and', '和'),
     ('northern', '北'),
     ('quolls', '袋鼬'),
     ('(small', '（一种小型'),
     ('**marsupial**', '**有袋类**(marsupial)'),
     ('hunters)', '猎手）的数量')],
    '（Numbers of…：……的数量，of 结构语序倒过来；\ngoannas：巨蜥，括号里 large lizards 意为大型蜥蜴）'],
   [[('have **slumped** in places;', '在一些地方**锐减**(slumped)；')], '（in places：在一些地方）'],
   [[('some', '部分'),
     ('local', '地方的'),
     ('quoll', '袋鼬'),
     ('populations', '种群'),
     ('were **wiped out**.', '被**彻底消灭**(wiped out)。')],
    '（wipe out：彻底消灭）']]),
 (4,
  [[[('The toads', '蟾蜍'),
     ('have **wreaked**', '**造成了**(wreaked havoc)'),
     ('**havoc**,', '**严重破坏**(wreaked havoc)，')],
    '（wreak havoc：造成严重破坏）'],
   [[('but', '但'),
     ('the damage', '损害'),
     ('is **uneven**;', '并**不均衡**(uneven)；'),
     ('some', '有些'),
     ('species', '物种'),
     ('have **prospered**.', '反而**繁荣了**(prospered)起来。')],
    '（the damage is uneven：各地受害程度不一样）']]),
 (5, [[[('Biological control', '生物防治'), ('can **triumph**.', '也能**大获成功**(triumph)。')]]]),
 (5,
  [[[('From 1926', '从1926年起，'), ('the cactus **moth**, Cactoblastis,', '仙人掌螟这种**蛾子**(moth)')],
    '（Cactoblastis：同位语，补充说明 the cactus moth，即仙人掌螟）'],
   [[('cleared', '在约十年内清除了'),
     ('most', '大部分'),
     ('**prickly** pear,', '“**带刺的**(prickly)梨”，'),
     ('an', '这是一种'),
     ('**invasive**', '**外来入侵的**(invasive)'),
     ('**cactus**,', '**仙人掌**(cactus)，'),
     ('{{=}}from Queensland and New South Wales within about a decade.', '清除范围遍及昆士兰州和新南威尔士州。')],
    '（an invasive cactus：同位语，补充说明 prickly pear；\nclear A from B：把 A 从 B 清除掉）']]),
 (5,
  [[[('Tested first,', '这种蛾子放出前经过检验，'),
     ('its **larvae**', '其**幼虫**(larvae)'),
     ('**starved** rather than eat', '宁可**饿死**(starved)也不吃'),
     ('fifteen other', '另外十五种'),
     ('plants;', '植物；')],
    '（Tested first：过去分词短语作状语，逻辑主语是这种蛾子；\nrather than：宁可……也不……）'],
   [[('the toads', '蟾蜍却'), ('faced no such', '从未受过这样的'), ('test.', '检验。')], '（no such…：没有这样的……）']]),
 (5,
  [[[('Under an October 1984 law,', '根据1984年10月通过的一部法律，'), ('recruits now', '如今新兵')],
    '（Under…law：依据……法律；\nrecruits：新兵，这里指准备引进来做生物防治的物种）'],
   [[('face **stringent**', '都要经过**严格的**(stringent)'), ('**scrutiny**.', '**认真彻底的审查**(scrutiny)。')]]]),
 (5,
  [[[('The **blunder**', '这个**大错**(blunder)'),
     ('was born of **haste**', '起于**仓促**(haste)，'),
     ('and', '又因'),
     ('sealed by **lobbying**', '**游说**(lobbying)'),
     ('that **overrode** a warning:', '**压过了**(overrode)警告而成定局：')],
    '（be born of…：源于……；\nthat overrode a warning：定语从句，修饰 lobbying）'],
   [[('an **untested**', '**未经检验的**(untested)'),
     ('**ally**,', '**盟友**(ally)'),
     ('once', '一旦'),
     ('**loose**,', '**放出**(loose)，'),
     ('may never be **recalled**.', '就可能再也**召不回来**(recalled)。')],
    '（once loose：省略的状语从句，等于 once it is loose）\n'
    '（简述：▸引进：1935年，澳大利亚为对付危害甘蔗的甲虫，引进甘蔗蟾蜍，再把约2400只后代放进野外，希望它们吃掉害虫。▸冒进：专家曾促成暂停释放，但地方游说让计划恢复；放出前却缺少检查蟾蜍究竟吃什么的试验。▸失控：甲虫没被明显消灭，蟾蜍却因天敌少、繁殖快而不断扩散，在热带北部每年推进约50公里。▸伤害：蟾蜍皮肤有毒，捕食它们的巨蜥、北袋鼬在一些地方大幅减少，部分袋鼬种群消失；对不同物种的影响并不一致。▸教训：此前引进仙人掌螟时，试验发现它的幼虫宁可饿死也不吃另外15种植物，后来才用于控制仙人掌；蟾蜍没有经过同类食性检验。未经检验的“帮手”一旦失控，可能再也收不回来。）']])]

out = {'no': '41',
 'title_en': 'The Toad That Invaded Australia',
 'title_zh': '入侵澳洲的毒蟾',
 'title_fx': {'hl': ['Toad', 'Invaded'], 'ghost': []},
 'sentences': [],
 '核对确认': {'非人声': {'3.35–3.37s': {'配音指纹': '72938dd25a0d',
                                 '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S1 w 0.02–0.04：句首 Greyback '
                                       '的 /ɡ/ 浊音杠（-48→-38 dB、周期 0.24–0.52、重心 0.7–1.4 kHz），连续升到 0.0425 的 /ɡ/ '
                                       '除阻（-28 dB、重心 2.9 kHz），属于 Greyback',
                                 '实测': {'最响dB': -39.7, '重心Hz': 905, '周期': 0.43, '低频dB': -1.5}},
                  '7.63–7.65s': {'配音指纹': '72938dd25a0d',
                                 '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S1 w 3.975–3.99：were 衰减到 '
                                       '-55 dB 后，3.9825–3.99 -46～-49 dB 一路升进 3.9925 plaguing 的 /p/ 除阻（-22→-13 '
                                       'dB、重心 4.1 kHz），是 /p/ 除阻的起头，属于 plaguing',
                                 '实测': {'最响dB': -47.8, '重心Hz': 1551, '周期': 0.0, '低频dB': -0.5}},
                  '18.83–18.95s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S2 w 5.18–5.30：toads 的 '
                                         '/d/ 闭塞浊音杠（-37～-50 dB、周期 0.2–0.5、重心 0.6–1.8 kHz，前接 oʊ 的浊音连续衰减），5.3175 '
                                         '/d/ 除阻（-25.6 dB）接 /z/（重心 6 kHz），属于 toads',
                                   '实测': {'最响dB': -36.4, '重心Hz': 1552, '周期': 0.29, '低频dB': -3.2}},
                  '23.45–23.55s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S2 w 9.60–9.69：句末 Hawaii. '
                                         '的 iː 气声收尾（-36～-56 dB、重心 2.2–4.4 kHz、周期 0.1–0.3），从元音一路连续衰减到 9.76 '
                                         '数字静音，中间没有 -55 dB 的缝，属于 Hawaii',
                                   '实测': {'最响dB': -36.4, '重心Hz': 3689, '周期': 0.24, '低频dB': -6.0}},
                  '18.90–18.91s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S2 w 5.25–5.265：同上 toads '
                                         '的 /d/ 闭塞浊音杠中段（-37～-45 dB、周期 0.3–0.5、重心 0.6–1.5 kHz），前后连续，属于 toads',
                                   '实测': {'最响dB': -37.8, '重心Hz': 838, '周期': 0.0, '低频dB': -1.8}},
                  '18.92–18.93s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S2 w 5.27–5.285：同上 toads '
                                         '的 /d/ 闭塞浊音杠尾段（-41～-50 dB、周期 0.07–0.35），连到 5.3175 /d/ 除阻，属于 toads',
                                   '实测': {'最响dB': -43.0, '重心Hz': 898, '周期': 0.0, '低频dB': -1.3}},
                  '19.60–19.61s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S2 w 5.84–5.855：逗号停顿后 '
                                         'bulky 的 /b/ 浊音杠（-47→-30 dB、周期 0.3–0.5、重心 300–800 Hz），连续到 5.92 /b/ '
                                         '除阻，属于 bulky',
                                   '实测': {'最响dB': -31.2, '重心Hz': 502, '周期': 0.0, '低频dB': -1.8}},
                  '29.57–29.59s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S4 w 0.025–0.04：句首 '
                                         'Biological 的 /b/ 浊音杠（-39→-23 dB、周期 0.25–0.47、重心 340–800 Hz），连到 '
                                         '0.0925 /b/ 除阻，属于 Biological',
                                   '实测': {'最响dB': -30.1, '重心Hz': 596, '周期': 0.0, '低频dB': -1.0}},
                  '33.17–33.20s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S4 w 3.33–3.355：a pest 的 '
                                         '/p/ 闭塞里（-49～-59 dB，最响 -51 dB），3.355 起 /p/ 除阻（-38→-19 dB），属于 pest',
                                   '实测': {'最响dB': -51.3, '重心Hz': 2433, '周期': 0.29, '低频dB': -0.3}},
                  '33.62–33.67s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S4 w 3.77–3.825：pest, 的 '
                                         '/t/ 除阻：/s/ 到 3.735，闭塞 3.75–3.77（-55～-67 dB），3.775 除阻 -35.8 dB（重心 '
                                         '3.4–3.8 kHz）衰减到 3.82 的 -53 dB，属于 pest，不能切',
                                   '词尾': 't',
                                   '实测': {'最响dB': -30.2, '重心Hz': 3737, '周期': 0.17, '低频dB': -10.6}},
                  '55.16–55.16s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S7 w 1.005–1.015：flopped '
                                         '的 /p/ 除阻（闭塞 0.96–1.00 -57～-66 dB 后 1.005 爆出 -33.7 dB、重心 3.3 kHz），p '
                                         '后接 t，属于 flopped',
                                   '词尾': 'p',
                                   '实测': {'最响dB': -37.8, '重心Hz': 2307, '周期': 0.0, '低频dB': -12.2}},
                  '55.20–55.25s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S7 w 1.045–1.10：flopped: '
                                         '的 /t/ 除阻（闭塞 1.02–1.04 -58～-68 dB，1.05 -30.6 dB、重心 2.8–4.2 kHz，衰减到 '
                                         '1.10 的 -56 dB），属于 flopped，不能切',
                                   '词尾': 't',
                                   '实测': {'最响dB': -30.2, '重心Hz': 3344, '周期': 0.25, '低频dB': -12.8}},
                  '73.94–74.02s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S10 w '
                                         '1.495–1.575：frontier, 的 ɹ 气声收尾（-35～-55 dB、周期 0.2–0.3、重心 1.2–1.9 '
                                         'kHz），从 1.48 的浊音（-21 dB、周期 0.45）一路连续衰减到 1.585，中间没有缝，属于 frontier',
                                   '实测': {'最响dB': -35.7, '重心Hz': 1625, '周期': 0.25, '低频dB': -4.4}},
                  '72.47–72.48s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S10 w 0.02–0.035：句首 Their '
                                         '的 /ð/ 浊音起音（-51→-27 dB、周期 0.37–0.47、重心 0.9–1.3 kHz），0.05 起 /ð/ 摩擦（重心 '
                                         '4.3 kHz）、0.06 起元音，属于 Their',
                                   '实测': {'最响dB': -31.8, '重心Hz': 1709, '周期': 0.0, '低频dB': -2.6}},
                  '85.71–85.80s': {'配音指纹': '72938dd25a0d',
                                   '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S11 w 3.615–3.70：toad '
                                         'breached 的 /d/ 和 /b/ 闭塞浊音杠（-40～-55 dB、周期 0.4–0.5、重心 0.45–1.4 '
                                         'kHz），3.705 /b/ 除阻，属于 toad/breached',
                                   '实测': {'最响dB': -41.6, '重心Hz': 1373, '周期': 0.77, '低频dB': -0.1}},
                  '100.39–100.47s': {'配音指纹': '72938dd25a0d',
                                     '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S13 w '
                                           '7.385–7.47：places; 的 ᵻ 到 /z/ 的过渡（-38～-52 dB、重心 1.7–2.8 kHz），7.445 '
                                           '起 /z/ 升到 -25 dB（重心 4.4–5.7 kHz），中间没有 -55 dB 的缝，属于 places',
                                     '实测': {'最响dB': -35.8, '重心Hz': 3005, '周期': 0.21, '低频dB': -2.3}},
                  '103.63–103.72s': {'配音指纹': '72938dd25a0d',
                                     '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S13 w 10.635–10.72：out. '
                                           '的 aʊ 气声收尾进 /t/ 闭塞（-29～-57 dB 连续衰减），闭塞 10.725–10.77（-60～-70 '
                                           'dB），10.775 /t/ 除阻，属于 out',
                                     '实测': {'最响dB': -35.0, '重心Hz': 1802, '周期': 0.21, '低频dB': -6.6}},
                  '103.39–103.40s': {'配音指纹': '72938dd25a0d',
                                     '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S13 w '
                                           '10.39–10.405：wiped 的 /p/ 除阻（闭塞 10.375–10.39 -57～-64 dB 后 10.395 爆出 '
                                           '-34.4 dB、重心 2.4 kHz），之后 /t/ 闭塞、10.44 /t/ 除阻接 out，属于 wiped',
                                     '词尾': 'p',
                                     '实测': {'最响dB': -37.0, '重心Hz': 2398, '周期': 0.0, '低频dB': -18.2}},
                  '120.55–120.56s': {'配音指纹': '72938dd25a0d',
                                     '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S16 w '
                                           '5.45–5.465：prickly pear 的 /p/ 闭塞里（-52～-59 dB，最响 -49 dB），5.47 /p/ '
                                           '除阻（-24.7 dB），属于 pear',
                                     '实测': {'最响dB': -48.9, '重心Hz': 2171, '周期': 0.0, '低频dB': -0.4}},
                  '128.45–128.49s': {'配音指纹': '72938dd25a0d',
                                     '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S17 w '
                                           '0.845–0.885：first, 的 /t/ 除阻（/s/ 到 0.815，闭塞 0.82–0.845 -53～-63 '
                                           'dB，0.85 -31 dB、重心 2.8–3.4 kHz，衰减到 0.885），属于 first，不能切',
                                     '词尾': 't',
                                     '实测': {'最响dB': -32.4, '重心Hz': 3096, '周期': 0.18, '低频dB': -9.7}},
                  '151.81–151.91s': {'配音指纹': '72938dd25a0d',
                                     '依据': '2026-11-03 41 逐 2.5/5 ms 看实际声音（dossier_41）：S19 w '
                                           '9.28–9.37：recalled. 的 /l/ 到 /d/ 闭塞的浊音（-36～-56 dB、周期 0.2–0.45），闭塞 '
                                           '9.365–9.38，9.385 /d/ 除阻（-18.8 dB），属于 recalled',
                                     '实测': {'最响dB': -35.2, '重心Hz': 1952, '周期': 0.32, '低频dB': -5.4}}},
          '删除段': {'S1 raw 3.4600-3.8335': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '72938dd25a0d',
                                           '依据': '2026-11-03 逐 5 ms 实测（w 坐标）：roots, 的 /s/ 到 3.45 衰减到 -55 '
                                                 'dB；3.47–3.83 是 -42～-55 dB 的吸气（程序非人声区间 '
                                                 '[3.505,3.833458,紧贴词头]），3.835 起 were 的 /w/（-46→-10 dB），右头切在 '
                                                 '/w/ 起音前的过零点，were 完整'},
                  'S13 raw 3.7959-4.0000': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '72938dd25a0d',
                                            '依据': '2026-11-03 逐 5 ms 实测（w 坐标）：quolls 的 /z/ 衰减到 3.785（-57 '
                                                  'dB），3.7875–3.97 是 -38～-55 dB、重心 2.4–3.4 kHz 的吸气（非人声区间 '
                                                  '[3.785917,3.99,紧贴词尾]），左头在 /z/ 衰减到底的过零点，3.9975 起 small 的 /s/ '
                                                  '完整'},
                  'S14 raw 1.5301-1.6950': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '72938dd25a0d',
                                            '依据': '2026-11-03 逐 5 ms 实测（w 坐标）：havoc 的 /k/ 除阻和送气 '
                                                  '1.48–1.51（-28→-47 dB，已用 除阻加强 +3 dB），1.515–1.64 是 -36～-50 dB '
                                                  '的吸气（非人声区间 [1.510083,1.675,紧贴词尾]），左头在送气衰减到底的过零点，/k/ 完整；1.68 '
                                                  '起 but 的 /b/'},
                  'S17 raw 0.9041-1.1100': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '72938dd25a0d',
                                            '依据': '2026-11-03 逐 5 ms 实测（w 坐标）：first, 的 /t/ 除阻 '
                                                  '0.85–0.88（-31～-47 dB），0.885–1.06 是 -47～-56 dB 的吸气（非人声区间 '
                                                  '[0.884083,1.0875,紧贴词尾]），左头在除阻衰减处的过零点，/t/ 完整；1.095 起 its'},
                  'S18 raw 2.5900-2.9401': {'类型': '紧贴两头的非人声',
                                            '配音指纹': '72938dd25a0d',
                                            '依据': '2026-11-03 逐 5 ms 实测（w 坐标）：law, 停顿里 2.51–2.80 是 -44～-57 dB '
                                                  '的吸气，2.8425–2.8525 -47～-56 dB 低频闷响（非人声区间 '
                                                  '[2.840042,2.860208,紧贴两头]），右头在 recruits 的 ɹ 起音（2.8625 起 '
                                                  '-45→-12 dB）前的过零点，ɹ 完整'},
                  'S19 raw 7.3925-7.7227': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '72938dd25a0d',
                                            '依据': '2026-11-03 逐 5 ms 实测（w 坐标）：loose, 的 /s/ 到 7.355，7.36–7.38 '
                                                  '衰减到 -56 dB；7.3875–7.39 咔哒、7.395–7.62 -45～-56 dB '
                                                  '吸气、7.65–7.675 低频闷响（非人声区间 [7.3825,7.712708,紧贴词头]），右头在 may 的 '
                                                  '/m/ 起音（7.715 起）前的过零点，/m/ 完整'},
                  'S6 raw 4.7150-5.0450': '2026-11-03 逐 5 ms 实测（w 坐标）：Froggatt, 之后 4.474–4.83 是 -34～-52 dB '
                                          '的吸气（程序非人声区间 [4.474042,4.83,紧贴词尾]，删掉的最响 -32.7 dB 即 4.785–4.805 '
                                          '的吸气峰），4.865 起 persuaded，删掉的部分没有词的声音',
                  'S6 raw 10.6650-10.7150': '2026-11-03 逐 5 ms 实测（w 坐标）：in 的 /n/ 衰减到 10.475（-60 '
                                            'dB）后，10.4975–10.505 单独一下 -31～-47 dB 的咔哒（非人声区间 '
                                            '[10.4925,10.5125]，删掉的最响 -33 dB 即此），10.54 起 September 的 '
                                            '/s/，删掉的部分没有词的声音',
                  'S7 raw 3.8825-4.1200': '2026-11-03 逐 5 ms 实测（w 坐标）：numbers, 的 /z/ 到 3.865 衰减到 -56 '
                                          'dB；3.8775–4.08 是 -37～-47 dB 的气声和低频闷响（非人声区间 [3.8725,4.09]，删掉的最响 '
                                          '-37.5 dB 即此），4.08–4.115 是 perhaps 的 /p/ 闭塞，4.1175 /p/ 除阻完整',
                  'S10 raw 4.7300-5.0900': '2026-11-03 逐 5 ms 实测（w 坐标）：first, 的 /t/ 除阻 4.6475–4.69 '
                                           '之后，4.73–5.05 是 -38～-52 dB 的吸气（程序非人声区间 [4.73,5.058625,紧贴词头]，删掉的最响 '
                                           '-37.3 dB 即 4.985–5.005 的吸气峰），5.09 起 accelerated，删掉的部分没有词的声音',
                  'S19 raw 4.5850-5.0950': '2026-11-03 逐 5 ms 实测（w 坐标）：warning: 之后 4.58–4.80 是 -56～-69 dB '
                                           '静音，4.835–5.07 是 -38～-55 dB 的吸气（程序非人声区间 [4.835,5.07]，删掉的最响 -37.3 dB '
                                           '即 5.005 附近的吸气峰），5.09 起 an，删掉的部分没有词的声音',
                  'S16 raw 4.0200-4.3250': '2026-11-03 逐 5 ms 实测（w 坐标）：Cactoblastis, 之后 4.005–4.29 是 -39～-56 '
                                           'dB 的吸气（程序非人声区间 [3.99,4.295]，删掉的最响 -38.7 dB 即 4.135–4.165 '
                                           '的吸气峰），4.32 起 cleared，删掉的部分没有词的声音',
                  'S16 raw 4.0200-4.3448': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '72938dd25a0d',
                                            '依据': '2026-11-03 逐 2.5 ms 实测（S16 w）：Cactoblastis, 的 /s/ 到 '
                                                  '3.965，衰减到 3.985（-58 dB）；3.9875–3.9925 一下 -39～-44 dB、重心 4.4 '
                                                  'kHz 的咔哒紧贴在 /s/ 尾后，4.005–4.29 是 -39～-56 dB 的吸气，4.29 和 4.3025 '
                                                  '各一下 -43～-48 dB、重心 5.4–6.2 kHz 的咔哒（非人声区间 [3.99,4.3125]，删掉的最响 '
                                                  '-38.7 dB 即吸气峰）；4.31–4.3175 -58～-63 dB，4.32 起 cleared 的 /k/ '
                                                  '完整；/s/ 本身在 3.985 前已衰减完，没切到'}},
          '停顿位置': {'S6 lobbying, / they @9.377': '2026-11-03 逐 2.5 ms 看声音实测（S6 w，区间声音指纹 e1f61244081d）：lobbying '
                                                 '的 ŋ 浊鼻音 9.25–9.375（周期 0.44–0.57、重心 540–1220 Hz、低频 -0.7～-3.6 '
                                                 'dB，-20 降到 -35 dB，9.33 单帧 -43.7 dB 是鼻音内部的低谷，之后 9.36–9.3725 '
                                                 '又回到 -29～-33 dB 浊鼻音），9.3775 起 they 的 ð 摩擦（重心 1.7→3.6 kHz、周期 '
                                                 '0.46→0.37），9.40 起元音；两词之间没有静音，用停顿插入点放到 ŋ 结束、ð 开始的过零点 '
                                                 '9.376708，不切 ŋ 也不切 ð；程序原来的 9.345 会把 ŋ 尾巴 30 ms 留到停顿后',
                   'S16 cactus, / from @7.715': '2026-11-03 逐 2.5 ms 看声音实测（S16 w，区间声音指纹 17a90c9d58b4）：cactus 的 '
                                                '/s/ 7.60–7.69（-16～-20 dB、重心 4.8–5.8 kHz），7.69–7.7125 衰减到 -32 '
                                                'dB（重心 4.9–5.9 kHz）；7.7175 起 from 的 /f/ 摩擦平台（-28～-34 dB、重心 '
                                                '6.0–7.3 kHz），7.7875 起 ɹ、7.7975 元音；两个擦音之间没有静音，7.715 是 /s/ '
                                                '衰减到底、重心越过 6 kHz 换成 /f/ 的交界，插在这里不切 /s/ 也不切 /f/（A42）',
                   'S19 ally, / once @6.574': '2026-11-03 逐 2.5 ms 看声音实测（S19 w，区间声音指纹 3122ce8f2e82）：ally 的 aɪ '
                                              '6.50–6.56 一路是浊元音（-13～-22 dB、周期 0.33–0.48、重心 1.3–2.8 kHz，ɪ 尾 F2 '
                                              '高），6.565–6.5725 重心 996→678 Hz 往下滑，6.575–6.62 是 once 的 /w/（重心 '
                                              '330–720 Hz、周期 0.48–0.50），6.625 起 ʌ 重心回升到 0.6–1.5 '
                                              'kHz；两词连读没有低谷，程序原来的 6.605 落在 /w/ 正中（重心 375 Hz），会把 /w/ '
                                              '切成两半；用停顿插入点改到 aɪ 滑到 /w/ 的过零点 6.57425（重心刚降到 700 Hz 以下），不切 ally '
                                              '也不切 once 的 /w/；两词无缝连读（整段浊音、没有低谷，交界处约 -14～-19 dB），按 A42 写成交界插入点 '
                                              '[6.57425,"交界"]'},
          '机器复听': {'S6': {'配音指纹': '72938dd25a0d',
                          '依据': '2026-11-03 实测（配音指纹 72938dd25a0d）：Froggatt 按 读音改正 读 fɹˈɑːɡət（末音节弱读 ə，英格兰地名姓氏 '
                                'frogga+cot），读音核对 0；small.en、parakeet 两路都听成 froggett，正是弱读 -ət 的拼法（-gatt/-gett '
                                '同音），首音节 frog 两路都对；交用户听'},
                   'S13': {'配音指纹': '72938dd25a0d',
                           '依据': '2026-11-03 实测（配音指纹 72938dd25a0d）：quolls/quoll 配音读 kwˈɑːlz / kwˈɑːl（美式 '
                                 '/kwɑːl/，Lingoland US），读音核对 0；两路听成 quals/quall/qual，都是 kwɑːl 的近音拼法（识别词表里没有 '
                                 'quoll），首辅音 kw、元音 ɑː、尾 l(z) 都对；交用户听'}},
          '合组': {'S12 make them a deadly meal': '对齐不了：make A B 结构，文章定稿中文化成两个小句“谁吃了它们，这一餐就是致命的”，拆开 '
                                                'make、deadly、meal 中文不通',
                 'S13 Numbers of goannas (large lizards)': '对齐不了：goannas (large lizards) 中文就是“巨蜥”一个词，括号里 large '
                                                           'lizards 是英文对 goannas 的解释，“巨蜥”已经包含；Numbers of 是 of '
                                                           '结构，“的数量”必须放到后面（沿用文章定稿）',
                 'S16 cleared most prickly pear': '对齐不了：后面的 from Queensland and New South Wales within about a '
                                                  'decade 是地点、时间状语，中文“在约十年内清除了昆士兰州和新南威尔士州的大部分刺梨”必须提到这里，同位语 an '
                                                  'invasive cactus 放到最后（沿用文章定稿语序）',
                 'S16 an invasive cactus, from Queensland and New South Wales within about a decade': '对齐不了：from '
                                                                                                      'Queensland '
                                                                                                      'and New '
                                                                                                      'South '
                                                                                                      'Wales、within '
                                                                                                      'about a '
                                                                                                      'decade '
                                                                                                      '是地点、时间状语，中文已提到前一组“清除了”前后，这一组只剩同位语“这是一种外来入侵的仙人掌”（沿用文章定稿语序）',
                 'S7 high up on cane stalks': '对齐不了：high up on cane stalks 是地点状语，中文“甘蔗茎秆的高处”方位词 high up '
                                              '必须放到后面，on 结构语序倒过来',
                 'S10 creeping about ten kilometres a year at first': '对齐不了：a year、at first '
                                                                      '是时间状语，中文“起初每年缓慢行进约十公里”（用户 2026-11-03 '
                                                                      '改）时间必须放到动词前（沿用文章定稿语序）',
                 'S10 accelerated to about 50 a year in the tropical north': '对齐不了：in the tropical north '
                                                                             '是地点状语，中文“到了热带北部”必须放到“加快”前；a year '
                                                                             '中文“每年”放到数字前（沿用文章定稿语序）',
                 'S13 Numbers of goannas': '对齐不了：Numbers of 是 of 结构，“的数量”必须放到后面（沿用文章定稿）',
                 'S16 cleared': '对齐不了：within about a decade 是时间状语，中文“在约十年内”必须放到“清除了”前（用户 2026-11-03 定的译文）',
                 'S16 from Queensland and New South Wales within about a decade': '对齐不了：用户 2026-11-03 '
                                                                                  '定的译文“清除范围遍及昆士兰州和新南威尔士州”，from '
                                                                                  '两州化成“清除范围遍及”，within about a '
                                                                                  'decade 已提到前面“在约十年内”',
                 'S17 starved rather than eat': '对齐不了：rather than 中文“宁可……也不……”，“宁可”必须放到 starved 前，拆开语序不通',
                 'S17 fifteen other': '对齐不了：fifteen other 中文“另外十五种”，other 必须放到数字前',
                 'S18 recruits now': '对齐不了：now 是时间状语，中文沿用文章定稿“如今新兵”，“如今”放到主语前',
                 'S19 sealed by lobbying that overrode a warning': '对齐不了：by lobbying that overrode a warning '
                                                                   '是方式状语加定语从句，中文“游说压过了警告而成定局”必须放到 sealed 前'},
          '对齐': {'S1-2 plantations in Queensland, nor': 'in Queensland, north-eastern Australia '
                                                        '是后置定语（地点），中文“澳大利亚东北部昆士兰州”必须提前（放到 lucrative 下面）',
                 'S12-1 make them a deadly meal.': 'make A B 结构，文章定稿中文化成两个小句，拆开不通',
                 'S13-1 Numbers of goannas (large liza': 'of 结构：Numbers of…，“的数量”放到后面；goannas (large lizards) '
                                                         '中文就是“巨蜥”',
                 'S16-2 an invasive cactus, from Queen': 'from…、within about a decade '
                                                         '是地点、时间状语，中文已提到“清除了”前后，这一组只剩同位语',
                 'S16-2 from Queensland and New South': '用户 2026-11-03 选定的译文“清除范围遍及昆士兰州和新南威尔士州”，from '
                                                        '两州化成“清除范围遍及”，within about a decade 已提到前面“在约十年内”',
                 'S19-1 sealed by lobbying that overro': 'by lobbying that overrode a warning '
                                                         '是方式状语加定语从句，中文必须放到 sealed（而成定局）前',
                 'S2-2 amphibians native to the Ameri': 'native to the Americas 是后置定语，中文“原产美洲”必须提前（放到 bulky '
                                                        '下面）；from Hawaii 修饰 imported，中文“从夏威夷”放到“引进了”前',
                 'S3-1 about 2,400 of their young': 'of 结构：about 2,400 of their young，中文“它们的约2,400只后代”语序必须倒过来',
                 'S7-2 high up on cane stalks.': 'high up on cane stalks 是地点状语，中文“甘蔗茎秆的高处”方位词必须放到后面',
                 'S10-1 creeping about ten kilometres ': 'a year、at first 是时间状语，中文“起初每年”必须放到动词前',
                 'S10-2 accelerated to about 50 a year': 'in the tropical north 是地点状语，中文“到了热带北部”必须放到“加快”前',
                 'S16-2 from Queensland and New South ': '用户 2026-11-03 选定的译文“清除范围遍及昆士兰州和新南威尔士州”，from '
                                                         '两州化成“清除范围遍及”，within about a decade 已提到前面“在约十年内”',
                 'S18-1 Under an October 1984 law,': 'Under…law 中文“根据1984年10月通过的一部法律”，时间定语 October 1984 '
                                                     '必须放到“一部法律”前'},
          '牛津逗号': {'S16 an invasive cactus, from Queensland and': '不是三项并列：an invasive cactus 是 prickly pear '
                                                                  '的同位语，逗号后 from Queensland and New South '
                                                                  'Wales 是地点状语，and 只连接两个州'},
          '方向': {'S6-2 after→经': "after Queensland's lobbying 中文“经昆士兰州游说”，“经”就是经过……之后，方向一致（沿用文章定稿）"},
          '词性': {'S9-2 unchecked 不受遏制地': 'unchecked 是 adj.，在 multiplied unchecked '
                                         '里作状语（说明繁殖的状态），中文“不受遏制地”作状语，沿用文章定稿'},
          '即': {'S4-1 即': '沿用文章定稿中文“即用一个物种去对付一种害虫”，同位说明 Biological control，用“即”简洁准确'},
          '引号': {'S16-2 “”': '用户 2026-11-03 原话自带引号：“在10年内清除了大部分 '
                             '“带刺的梨”，这是一种外来入侵的仙人掌。来自于昆士兰和新南威尔士州。仙人掌，仙人掌标注为重点词汇。prickly '
                             '也标注重点词汇。对应中文意思，带刺的。Invasive 后面那个仙人掌要标注为重点词汇。”（“带刺的梨”）'},
          '同词异译': {'wreaked havoc：严重破坏/造成了': '不是两种译法：wreak havoc 的意思“造成了严重破坏”，wreaked 对“造成了”、havoc '
                                             '对“严重破坏”，整体标同一个英文（T22/T23，用户 2026-11-03 原话“wreaked 为重点词汇”）'},
          '括号含重点词': {'S13-1 （大型**蜥蜴**(lizards)）': '英文原文就是括号 (large lizards)，中文照英文括号对应，不是补充说明；用户原话：“Lizard '
                                                  '没重点词汇标注为重点词汇。标注意重点词汇。 marsupial 也标注重点词汇，也标注重点词汇。”——lizards '
                                                  '在英文括号里，按用户原话标重点词',
                     'S13-1 （一种小型**有袋类**(marsupial)猎手）': '英文原文就是括号 (small marsupial '
                                                         'hunters)，中文照英文括号对应（沿用文章定稿），不是补充说明；用户原话：“Lizard '
                                                         '没重点词汇标注为重点词汇。标注意重点词汇。 marsupial '
                                                         '也标注重点词汇，也标注重点词汇。”——marsupial 在英文括号里，按用户原话标重点词'},
          '中文意思': {'S2 native to': '不是被隔开的两处：用户 2026-11-03 原话定的“原产于美洲”，native to 只对应“原产于”，后面直接接“美洲、”，没有“……的”'},
          '短语': {'S19 by … lobbying': '不是搭配：by 只引出 sealed 的方式（被游说定局），lobbying 本身就是“游说”（同 S2 imported … from '
                                      '的判法）',
                 'S2 imported … from': '不是搭配：from Hawaii 只引出来源（从夏威夷），imported 本身就是“引进”（同 40 dispensed … to '
                                       '的判法）',
                 'S2 imported … to': '不是搭配：to 属于 native to the Americas，和 imported 无关',
                 'S4 species … against': '不是搭配：against 属于 setting one species against a pest（set A against B 用 '
                                         'A 对付 B），和 species 无关',
                 'S6 persuaded … to': '不是搭配：to 是不定式符号，引出 halt releases（persuade sb to do sth 句型），halt '
                                      '本身是重点词已标；中文“说服官员叫停释放”',
                 'S7 dented … on': '不是搭配：on 属于 high up on cane stalks，和 dented 无关',
                 'S9 spawning … of': '不是搭配：of 属于 thousands of eggs，和 spawning 无关',
                 'S10 accelerated … to': '不是搭配：to 只引出加快后达到的速度（到每年约50公里），accelerated 本身就是“加快”'}},
 '结尾解说': '简述',
 'allow_clash': ['prickly', 'starved', 'loose', 'ally'],
 '重点词颜色': {'multiplied': '#FBBF24', 'unchecked': '#2DD4BF'},
 '高亮按实际开口': True,
 '高亮开口门槛': 40,
 '术语': {'Biological': '生物',
        'Queensland': '昆士兰州',
        'Australia': '澳大利亚',
        'Hawaii': '夏威夷',
        'Americas': '美洲',
        'Walter Froggatt': '沃尔特·弗罗格特',
        'Western Australia': '西澳大利亚州',
        'goannas': '巨蜥',
        'northern quolls': '北袋鼬',
        'quoll': '袋鼬',
        'Cactoblastis': '仙人掌螟',
        'prickly pear': '梨',
        'New South Wales': '新南威尔士州'},
 '结尾句': {'S19': {'前段语速': 0.9,
                 '最后一段语速': 0.78,
                 '最后一段前停顿': 0.7,
                 '接点': [185100, 238860],
                 '依据': '全篇结尾句按 07 定下的标准（用户 2026-10-10 同意并要求所有视频统一）：前段 0.9、最后一段“may never be recalled.” '
                       '0.78、前面停 0.7 秒。接点由 结尾句接点.py 自动找：0.9 那遍最后一个标点后最长静音（35 ms）的正中 7.713 s，0.78 那遍（45 ms）的正中 '
                       '9.953 s，所在帧和两侧各 5 ms 都低于 -55 dB（程序以 08 校准：与人工核实的接点落在同一段静音里）'}},
 '非人声区间': {'S1': [[3.505, 3.833458, '紧贴词头'], [7.115, 7.328167, '紧贴词头']],
           'S2': [[5.555, 5.805]],
           'S6': [[4.474042, 4.83, '紧贴词尾'], [10.4925, 10.5125]],
           'S9': [[3.8, 4.035]],
           'S10': [[4.73, 5.058625, '紧贴词头']],
           'S11': [[1.955, 2.16]],
           'S12': [[1.535, 1.757417, '紧贴词头']],
           'S13': [[5.765, 6.095], [3.785917, 3.99, '紧贴词尾']],
           'S16': [[3.99, 4.3125]],
           'S19': [[4.835, 5.07], [7.3825, 7.712708, '紧贴词头']],
           'S7': [[3.8725, 4.09]],
           'S14': [[1.510083, 1.675, '紧贴词尾']],
           'S17': [[0.884083, 1.0875, '紧贴词尾']],
           'S18': [[2.840042, 2.860208, '紧贴两头']]},
 '词尾除阻': {'S3': {'句末': [3.97, 't']},
          'S4': {'句末': [6.085, 't']},
          'S6': {'2': [4.46, 't']},
          'S13': {'句末': [10.765, 't']},
          'S17': {'句末': [6.875, 't']}},
 '停顿处除阻': {'S6': {'1': [3.495, 3.5, 't']}},
 '区间声音指纹': {'S1': '97c2ae1a56b4',
            'S2': 'f41c6616cfbf',
            'S3': '114140581b36',
            'S4': 'a9ef1c614557',
            'S6': 'e1f61244081d',
            'S7': 'f23d72bab4d6',
            'S9': '317242eb3bec',
            'S10': '9d4cd2b62068',
            'S11': '315f693b0b16',
            'S12': '199a8538b53e',
            'S13': '695d3520747a',
            'S14': '567e5f88e6ed',
            'S16': '17a90c9d58b4',
            'S17': '771f8cba9f1d',
            'S18': '599485374c15',
            'S19': '3122ce8f2e82'},
 '停顿插入点': {'S6': {'4': 9.376708}, 'S19': {'2': [6.57425, '交界']}},
 '除阻加强': {'S14': {'1': [1.478, 1.51, 3.0]}},
 '分段增益dB': {'S6': {'4': -1.5, '5': 2.5}},
 '换行变更记录': [{'日期': '2026-11-04',
             'S16': '用户 2026-11-03 原话：“在10年内清除了大部分 “带刺的梨”，这是一种外来入侵的仙人掌。来自于昆士兰和新南威尔士州。仙人掌，仙人掌标注为重点词汇。prickly '
                    '也标注重点词汇。对应中文意思，带刺的。Invasive '
                    '后面那个仙人掌要标注为重点词汇。”，并选定译文“在约十年内清除了大部分“带刺的梨”，这是一种外来入侵的仙人掌，清除范围遍及昆士兰州和新南威尔士州。”',
             'S1': '用户 2026-11-03 原话：“最后一句，最后一句。改为 此种植园位于澳大利亚东北部的昆士兰州。把前面那个正困扰着 后面的澳大利亚东北部昆士兰州给去掉。”'}]}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
