#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('Chernobyl', '切尔诺贝利，（虽然）'),
     ('is **synonymous with** **disaster**,', '是**灾难**(disaster)的**代名词**(synonymous with)，'),
     ('yet', '但是'),
     ('it', '这里'),
     ('holds', '却容纳着'),
     ('a **startling** amount of', '数量**惊人的**(startling)'),
     ('**wildlife**.', '**野生动物**(wildlife)。')],
    '（be synonymous with…：是……的代名词，等同于……；\na startling amount of：数量惊人的）']]),
 (1,
  [[[('Early on 26 April 1986,', '1986年4月26日凌晨，'),
     ('one of its **reactors**', '它的一座**反应堆**(reactors)'),
     ('exploded', '爆炸'),
     ('in Soviet Ukraine,', '于苏联乌克兰，')],
    '（one of its reactors：它的其中一座反应堆，its 指切尔诺贝利）'],
   [[('**dispersing**', '**扩散**(dispersing)'),
     ('**radioactive**', '**放射性的**(radioactive)'),
     ('**fallout**', '**尘降物**(fallout)'),
     ('across Europe.', '遍及整个欧洲。')],
    '（dispersing…：现在分词短语作结果状语；\n'
    'fallout：放射性沉降物）\n'
    '（disperse 向四面八方散开、扩散。\n'
    '无论是人群散开、雾气消散，还是放射性物质弥漫，\n'
    '核心画面都是“一个整体向四面八方分散开来”。）']]),
 (1,
  [[[('On 27 April,', '在4月27日，'),
     ('nearby', '附近的'),
     ('Pripyat', '普里皮亚季'),
     ('**was emptied of**', '**被清空了**(was emptied of)'),
     ('about 45,000 **inhabitants**', '约45,000名**居民**(inhabitants)，'),
     ('within hours.', '发生在数小时内。')],
    '（be emptied of…：被清空……；within hours：几小时之内）']]),
 (1,
  [[[('A zone some 30 kilometres in **radius**', '一片**半径**(radius)约30公里的区域'),
     ('became', '变成了'),
     ('**off-limits**,', '**禁区**(off-limits)，')],
    '（some 30 kilometres in radius：后置定语，修饰 zone，\nsome 表示“大约”）\n（off-limits：形容词，不准进入的；禁止入内的）'],
   [[('and Belarus', '白俄罗斯也'),
     ('**fenced off**', '**用栅栏隔开了**(fenced off)'),
     ('**adjoining**', '**相邻的**(adjoining)'),
     ('**terrain**.', '**地带**(terrain)。')],
    '（fence off：用栅栏隔开，围起来）']]),
 (2,
  [[[('In October 2015,', '2015年10月，'),
     ('a study in **Current Biology**', '**《当代生物学》**(Current Biology)上的一项研究'),
     ('combined', '结合了'),
     ('**aerial** surveys', '**空中的**(aerial)调查'),
     ('with', '与'),
     ('**footprint**', '**足迹**(footprint)'),
     ('counts', '计数，'),
     ('on the Belarusian side.', '这些数据都在白俄罗斯一侧。')],
    '（combine A with B：把 A 与 B 结合起来；\naerial survey：空中调查，航测）']]),
 (2,
  [[[('**Elk**,', '**驼鹿**(elk)、'),
     ('**roe deer**,', '**狍**(roe deer)、'),
     ('red deer,', '马鹿'),
     ('and wild **boar**', '和**野猪**(boar)'),
     ('were **comparable** in **density**', '在数量**密度**(density)方面，**相当**(comparable to)'),
     ('**to** those in four **reserves** free of **contamination**,',
      '**于**(comparable to)四个未受**污染**(contamination)的**保护区**(reserves)里的同类，')],
    '（be comparable to…：与……相当；\n'
    'in density：在密度方面；those 指代前面几种动物；\n'
    'free of contamination：未受污染的，后置定语，修饰 reserves）'],
   [[('and', '而'),
     ('wolves', '狼'),
     ('were over seven times as **numerous**.', '的**数量非常多**(numerous)，是那些保护区里的同类的七倍之多。')],
    '（X times as numerous：数量是……的 X 倍）']]),
 (2,
  [[[('Earlier', '更早的'),
     ('**helicopter**', '**直升机**(helicopter)'),
     ('counts', '计数（空中盘点）'),
     ('showed', '显示，'),
     ('**elk**,', '**驼鹿**(elk)、'),
     ('**roe deer**,', '**狍**(roe deer)'),
     ('and **boar**', '和**野猪**(boar)'),
     ('**surging** in the **post-disaster** decade.', '在**灾后的**(post-disaster)那十年里数量**激增**(surging)。')],
    '（show sth doing：显示……正在怎样；post-disaster：灾后的）\n（helicopter counts：直升机计数，\n坐在直升机上向下清点动物的数量，盘点动物有多少）']]),
 (3,
  [[[('Later', '后来的'),
     ('**fieldwork**', '**实地考察**(fieldwork)'),
     ('**bolstered**', '**佐证了**(bolstered)'),
     ('these findings.', '这些发现。')],
    '（bolster：支持/加强）']]),
 (3,
  [[[('In April 2016,', '2016年4月，'),
     ('camera', '相机'),
     ('traps', '陷阱'),
     ('**snapped** wolves, boar, and raccoon dogs near the most **hazardous** spots,',
      '在最**危险的**(hazardous)几个地点附近，**拍到了**(snapped)狼、野猪和貉，')],
    '（camera trap：相机陷阱，自动拍摄的相机；\nraccoon dog：貉）'],
   [[('with no sign of', '没有迹象表明'), ('**suppressed** numbers.', '动物的数量**被抑制**(suppressed)。')],
    '（with no sign of…：没有……的迹象）']]),
 (3,
  [[[('The **probable** reason', '**可能的**(probable)原因'),
     ('is **mundane**:', '很**平常**(mundane)：'),
     ('the **absence** of', '**没有**(absence)'),
     ('**agriculture**,', '**农耕**(agriculture)、'),
     ('**forestry**,', '**伐木**(forestry)'),
     ('and hunting.', '和狩猎。')],
    '（the absence of…：没有……，缺乏……）']]),
 (4,
  [[[('Smaller **organisms** fared worse in some studies.', '在一些研究中，\n更小的**生物**(organisms)过得更差。')],
    '（fare：过得，进展；fare worse：过得更差）\n'
    '（organism：指任何有生命的个体（也就是生物体或有机体）。\n'
    '例：人类 a human organism，树木 a plant organism，\n'
    '细菌 a single-celled organism（单细胞生物））']]),
 (4,
  [[[('One,', '一项研究'),
     ('in March 2007,', '于2007年3月'),
     ('found', '发现了'),
     ('fewer', '更少的'),
     ('**nesting** birds,', '**筑巢的**(nesting)鸟类，'),
     ('and', '以及'),
     ('fewer', '更少的'),
     ('species,', '种类，'),
     ('where', '在这里'),
     ('radiation', '辐射'),
     ('was more', '更加'),
     ('**intense**.', '**强烈**(intense)。')],
    '（One 指一项研究；where…：地点状语从句，在……的地方）\n'
    '（intense：强烈的、极度集中的。例：强光 intense light，\n'
    '剧痛 intense pain，激烈的竞争 intense competition）']]),
 (4,
  [[[('Another,', '另一项研究'),
     ('in March 2009,', '于2009年3月'),
     ('found', '发现，'),
     ('**pollinators**', '**传粉昆虫**(pollinators)'),
     ('and spiders', '和蜘蛛'),
     ('less **plentiful**', '没那么**丰富/数量众多**(plentiful)，'),
     ('where **exposure** was greater.', '在这些地方，辐射**接触**(exposure)更大。')],
    '（find A less plentiful：发现 A 没那么多，复合宾语）\n'
    '（exposure：“暴露”或“接触”，指毫无遮挡地处在某种环境（尤其是有害环境）中。\n'
    'exposure to radiation 就是“暴露于辐射中”，大白话就是“受到辐射照射”）']]),
 (4,
  [[[('A third,', '第三项研究'),
     ('in March 2014,', '于2014年3月'),
     ('found', '发现，'),
     ('leaves **decomposing** about 40 per cent less at the most **polluted** sites,',
      '在最严重**被污染的**(polluted)地点，落叶的**分解**(decomposing)少了约40%，')],
    '（find sth doing：发现……在怎样；per cent：百分之……）'],
   [[('**impeding**', '**阻碍了**(impeding)'),
     ('the return of **nutrients** to the soil.', '**养分**(nutrients)回归土壤。')],
    '（impeding…：现在分词短语作结果状语；\nthe return of A to B：A 回到 B）']]),
 (5,
  [[[('Counting heads', '仅靠清点动物的数量'),
     ('cannot **guarantee**', '无法**确保**(guarantee)'),
     ('the health of **individual** animals,', '动物**个体**(individual)就是健康的；')],
    '（切尔诺贝利这里的动物数量比较多，不一定就说明这里的环境更加健康和适合这群动物）'],
   [[('and', '并且'),
     ('**how much damage** low but **continual** doses **inflict**',
      '较低但是却**一直持续的**(continual)辐射剂量究竟会（对生物）**造成**(inflict)**多大伤害**(how much damage)，'),
     ('remains **contentious**,', '目前仍然存在**争议**(contentious)，')],
    '（how much damage…inflict：主语从句，\ndamage 是 inflict 的宾语，提到了前面；\nremain + 形容词：仍然……）'],
   [[('as', '因为'),
     ('studies', '各项研究'),
     ('**clash over** methods.', '**在**(clash over)方法**上存在冲突**(clash over)。')],
    '（clash over…：在……上冲突）']]),
 (5,
  [[[('The **burgeoning**', '**迅速增长的**(burgeoning)'),
     ('**herds**', '**兽群**(herds)'),
     ('may **trumpet**', '或许在**宣扬**(trumpet)'),
     ('the **dividend** of human **departure**,', '人类**离开**(departure)所带来的**红利**(dividend)，')],
    '（trumpet：大肆宣扬，与后面的 quieter 对比；\nthe dividend of…：……带来的红利）'],
   [[('but', '但'),
     ('the **sluggish**', '落叶**迟缓的**(sluggish)'),
     ('**rot** of fallen leaves', '**腐烂**(rot)，'),
     ('keeps', '记着'),
     ('a quieter **ledger**', '一笔更安静的**账**(ledger)：'),
     ("of radiation's", '辐射的'),
     ('cost.', '代价。')],
    '（keep a ledger of…：记下……的账，这里比喻记录代价）\n'
    '（简述：▸灾后：1986年切尔诺贝利核事故后，居民撤离、周边封禁，受污染地区却出现大量野生动物。\n'
    '▸繁盛：白俄罗斯一侧多种兽类密度与四个未污染保护区相当，狼的数量为对照区的七倍多。\n'
    '▸原因：可能的解释是农耕、伐木和狩猎消失，人类活动减少给野生动物带来了生存空间。\n'
    '▸代价：部分研究发现高辐射处筑巢鸟数量及鸟种较少，\n'
    '▹传粉昆虫和蜘蛛也少；污染最重地点的落叶分解明显变慢，养分更难回到土壤。\n'
    '▸限度：动物多不等于个体健康；长期低剂量辐射造成多大伤害仍有争议，不能据此说辐射无害。）']])]

out = {'no': '27',
 'title_en': 'Life in the Forbidden Zone',
 'title_zh': '禁区里的生机',
 'title_fx': {'hl': ['Life', 'Forbidden'], 'ghost': []},
 'sentences': [],
 '核对确认': {'牛津逗号': {'S13 in March 2009, found pollinators and': '不是三项并列：并列的只有 pollinators 和 spiders 两项，in March '
                                                               '2009 是时间状语'},
          '方向': {'S13-1 less→没那么丰富/数量众多，': 'less 译“没那么”，和英文同方向（更少），less plentiful 就是没那么丰富/数量众多（第32条用户给的译法）'},
          '词性': {'S16-2 sluggish 迟缓地': 'rot 在中文里译作动词“腐烂着”，sluggish 修饰它要用“地”，沿用文章定稿“迟缓地”'},
          '短语': {'S1 with … disaster': '不是搭配：with 属于 synonymous with（已整体标），disaster 是它的宾语',
                 'S4 in … radius': '不是搭配：in 是表示“在……方面”的普通介词，30 kilometres in radius 就是半径30公里，同 in length、in '
                                   'width',
                 'S5 with … footprint': '不是搭配：with 属于 combine A with B，footprint 是 counts 的定语',
                 'S6 comparable … in': '不是搭配：in 是普通介词“在……方面”，引出 density；comparable 的搭配是 comparable to（已整体标）',
                 'S6 in … density': '不是搭配：in 是普通介词“在……方面”，in density 不是 in desperation 那样的固定短语',
                 'S7 surging … in': '不是搭配：in the post-disaster decade 是时间状语，surge in（某方面激增）的 in 后面接的是方面，这里不是',
                 'S10 absence … of': '不是搭配：the absence of 是普通的 of 结构（没有……），同 26 repertoire of 的判法，absence '
                                     '单独是重点词',
                 'S14 impeding … of': '不是搭配：of 属于 the return of nutrients，impeding 的宾语是 the return',
                 'S9 hazardous spots': '不是搭配：spots 是普通名词“地点”，整体搭配是 the most hazardous（已整体标）',
                 'S12 nesting birds': '不是搭配：nesting 本身就是“筑巢（繁殖）的”，birds 是普通名词“鸟”，单独对齐',
                 'S16 human departure': '不是搭配：departure 速查第一个意思就是“离开，离去”，human 是普通定语“人类”',
                 'S14 impeding … to': '不是搭配：to 属于 the return of A to B，impeding 的宾语是 the return',
                 'S15 guarantee … of': '不是搭配：of 属于 the health of individual animals，guarantee 的宾语是 the health',
                 'S16 herds … of': '不是搭配：of 属于 the dividend of human departure，和 herds 无关',
                 'S16 trumpet … of': '不是搭配：of 属于 the dividend of human departure，trumpet 的宾语是 the dividend',
                 'S16 dividend … of': '不是搭配：the dividend of A 是普通的 of 结构（A 带来的红利），dividend 单独是重点词',
                 'S16 rot … of': '不是搭配：the rot of A 是普通的 of 结构（A 的腐烂），rot 单独是重点词',
                 'S16 ledger … of': '不是搭配：a ledger of A 是普通的 of 结构（记 A 的账），ledger 单独是重点词',
                 'S5 in … Current': '不是搭配：in 是普通介词“在……上”，in Current Biology 指刊登在这本期刊上，Current Biology '
                                    '是刊名，单独标（用户第7条）',
                 'S2 radioactive fallout': '不是搭配：radioactive 和 fallout 用户第3条逐词给了中文（放射性的、尘降物），两个词已各自加粗、各标各的意思',
                 'S6 seven times as numerous': '不是搭配：seven times as … 是普通倍数结构，用户第10、11条只把 numerous '
                                               '对“数量非常多”加粗，“七倍之多”另成一组',
                 'S9 suppressed numbers': '不是搭配：numbers 是普通名词“数量”，用户第18条只标 suppressed（被抑制）',
                 'S11 Smaller organisms': '不是搭配：smaller 是普通形容词比较级“更小的”，organisms 的中文“生物”是用户第31条给的',
                 'S14 polluted sites': '不是搭配：sites 是普通名词“地点”，polluted 的中文“被污染的”是用户第23条给的',
                 'S13 less plentiful where': '不是搭配：where 引出地点状语从句“在这些地方”，less 是普通比较“没那么”，plentiful '
                                             '的中文“丰富/数量众多”是用户第32条给的',
                 'S15 guarantee the health of': '不是搭配：guarantee 单独就是“确保”（用户第37条），the health of individual '
                                                'animals 是它的宾语，中文“就是健康的”另成一组',
                 'S15 continual doses': '不是搭配：doses 是普通名词“剂量”，continual 的中文“一直持续的”是用户第39条给的'},
          '同词异译': {'comparable to：于/相当': 'S6 comparable to“相当于”被“密度”这一组隔开，“相当”“于”是同一个意思的两部分（T22/T23），不是两种译法',
                   'clash over：在/上相互冲突': 'S15 clash over“在……上相互冲突”被“方法”隔开，是同一个意思的两部分（T22/T23），不是两种译法',
                   'clash over：上相互冲突/在': 'S15 clash over“在……上相互冲突”被“方法”隔开，是同一个意思的两部分（T22/T23），不是两种译法',
                   'clash over：上存在冲突/在': '不是两种译法：clash over 一个译法“在……上存在冲突”，被宾语“方法”隔开，两段都加粗标 clash over（T23 '
                                         '意思标全），全篇只这一处'},
          '中文重复': {'污染': '文章定稿 contamination（名词：污染）、polluted（形容词：受污染的）中文都是“污染”，已定稿的中文意思未经用户允许不改（铁律），发草稿时请用户定'},
          '合组': {'S4 A zone some 30 kilometres in radius': '对齐不了：some 30 kilometres in radius 是后置定语修饰 '
                                                           'zone，中文“一片半径约30公里的区域”定语必须提前，拆开后中文语序就乱了',
                 'S6 roe deer': '对齐不了：roe deer 是一种动物，中文就一个字“狍”',
                 'S7 roe deer': '对齐不了：roe deer 是一种动物，中文就一个字“狍”',
                 'S6 red deer': '对齐不了：red deer 是一种动物，中文“马鹿”是专名，拆开 red 不是“马”',
                 'S9 raccoon dogs': '对齐不了：raccoon dog 是一种动物，中文就一个字“貉”',
                 'S6 to those in four reserves free of contamination': '对齐不了：free of contamination 是后置定语修饰 '
                                                                       'reserves，中文“四个未受污染的保护区里的同类”定语必须提前，those '
                                                                       '译“同类”放在最后',
                 'S9 near the most hazardous spots': '对齐不了：near 中文是方位词“……附近”，必须放在“地点”后面',
                 'S14 about 40 per cent less': '对齐不了：less 中文“少了”必须放在“约40%”前面，per cent 就是“%”',
                 'S14 the return of nutrients to the soil': '对齐不了：the return of A to B 中文“A 回归 B”，return 必须放到 '
                                                            'nutrients 后面',
                 'S15 the health of individual animals': '对齐不了：the health of A，用户给的中文（第38条）“动物个体就是健康的”把 A '
                                                         '放在前面，of 结构语序倒过来',
                 'S16 of fallen leaves': '对齐不了：fallen leaves 中文是一个词“落叶”，拆开不通',
                 'S3 within hours': '对齐不了：within hours 是一个时间短语，用户给的中文（第4条）“发生在数小时内”用“在……内”把“数小时”夹在中间，拆开就把短语切断',
                 'S9 snapped wolves, boar, and raccoon dogs near the most hazardous spots': '对齐不了：near the '
                                                                                            'most hazardous '
                                                                                            'spots '
                                                                                            '是地点状语，用户给的中文（第17条）把它提到“拍到了”前面，和英文语序相反，拆开中文就不按用户的语序读',
                 'S11 Smaller organisms fared worse in some studies': '对齐不了：用户要求（第19条）“在一些研究中”放上面一行、“更小的生物过得更差”放下面一行（第31条改“生物”），和英文语序相反',
                 'S14 leaves decomposing about 40 per cent less at the most polluted sites': '对齐不了：at the most '
                                                                                             'polluted sites '
                                                                                             '是地点状语，用户给的中文（第23条）把它提到“落叶的分解少了约40%”前面，和英文语序相反',
                 'S15 how much damage low but continual doses inflict': '对齐不了：how much damage 是 inflict '
                                                                        '提前的宾语，用户给的中文（第39条）“较低但是却一直持续的辐射剂量究竟会（对生物）造成多大伤害”按中文语序放回动词后面，和英文语序相反',
                 'S16 rot of fallen leaves': '对齐不了：of fallen leaves 是 of 结构，用户给的中文（第27条）“落叶迟缓的腐烂”把“落叶”提到最前面，放在 '
                                             'the sluggish 下面，rot 下面只剩“腐烂”'},
          '对齐': {'S1-1 is synonymous with disaster,': 'be synonymous with A 中文“是 A 的代名词”，A '
                                                      '必须放在“代名词”前面，语序必须倒过来；synonymous、disaster '
                                                      '两个重点词因语序倒过来同在一组（T34 倒装）',
                 'S4-1 A zone some 30 kilometres in r': 'some 30 kilometres in radius 是后置定语修饰 '
                                                        'zone，中文“一片半径约30公里的区域”定语提前，语序必须倒过来',
                 'S5-1 a study in Current Biology': '介词短语 in Current Biology 作后置定语修饰 '
                                                    'study，中文“《当代生物学》上的一项研究”定语提前，语序必须倒过来',
                 'S5-1 footprint counts on the Belaru': '介词短语 on the Belarusian side 作后置定语修饰 '
                                                        'counts，中文“白俄罗斯一侧的足迹计数”定语提前，语序必须倒过来',
                 'S6-1 to those in four reserves free': 'free of contamination 是后置定语修饰 '
                                                        'reserves，中文“四个未受污染的保护区”定语提前；those 译“同类”放在最后，语序必须倒过来',
                 'S6-2 were over seven times as numer': '倍数比较 X times as '
                                                        'numerous，中文“数量是后者的七倍多”，numerous（多）必须放在倍数后面，语序必须倒过来',
                 'S9-1 near the most hazardous spots,': '介词 near 中文是方位词“……附近”，必须放在地点后面，语序必须倒过来',
                 'S9-2 suppressed numbers.': '前置定语 suppressed 中文“数量被压低”，必须放在“数量”后面，语序必须倒过来',
                 'S14-2 the return of nutrients to th': 'the return of A to B 中文“A 回归 B”，return 必须放到 nutrients '
                                                        '后面，语序必须倒过来',
                 'S15-1 the health of individual anim': '倒序：the health of A，用户给的中文（第38条）“动物个体就是健康的”把 A 放在前面，of '
                                                        '结构语序必须倒过来',
                 'S15-2 how much damage low but conti': '倒序：how much damage '
                                                        '是宾语从句里提前的宾语，中文按用户给的句子（第39条）放回“造成”后面；continual、inflict '
                                                        '两个重点词因此同在一组（T34 倒装）',
                 'S15-3 clash over methods.': 'clash over A 中文“在 A 上冲突”，介词短语必须提前，语序必须倒过来',
                 'S16-1 the dividend of human departu': 'the dividend of A 中文“A 带来的红利”，of '
                                                        '结构语序必须倒过来；dividend、departure 两个重点词因此同在一组（T34 倒装）',
                 'S16-2 the sluggish rot of fallen le': 'the sluggish rot of A 中文“A 迟缓地腐烂”，of '
                                                        '结构语序必须倒过来；sluggish、rot 两个重点词因此同在一组（T34 倒装）',
                 'S14-2 the return of nutrients to the': 'the return of A to B 中文“A 回归 B”，return 必须放到 '
                                                         'nutrients 后面，语序必须倒过来',
                 'S15-1 the health of individual anima': '倒序：the health of A，用户给的中文（第38条）“动物个体就是健康的”把 A '
                                                         '放在前面，of 结构语序必须倒过来',
                 'S16-1 the dividend of human departur': 'the dividend of A 中文“A 带来的红利”，of '
                                                         '结构语序必须倒过来；dividend、departure 两个重点词因此同在一组（T34 倒装）',
                 'S2-1 Early on 26 April 1986,': '日期 26 April 1986 '
                                                 '中文要按“1986年4月26日”年月日排，Early（凌晨）放在日期后面，语序必须倒过来',
                 'S14-1 about 40 per cent less': 'less 中文“少了”必须放在“约40%”前面，语序必须倒过来；per cent 就是“%”',
                 'S7-1 surging in the post-disaster d': '倒序：in the post-disaster decade '
                                                        '是时间状语，中文按用户给的句子（第13条）提到动词“激增”前面',
                 'S9-1 snapped wolves, boar, and racc': '倒序：near the most hazardous spots '
                                                        '是提前的地点状语，中文按用户给的句子（第17条）放在“拍到了”前面',
                 'S11-1 Smaller organisms fared worse ': '倒序：in some studies '
                                                         '是提前的介词短语，用户要求（第19条）“在一些研究中”单独放上面一行',
                 'S14-1 leaves decomposing about 40 pe': '倒序：at the most polluted sites '
                                                         '是提前的地点状语，中文按用户给的句子（第23条）放在最前面',
                 'S15-2 how much damage low but contin': '倒序：how much damage '
                                                         '是宾语从句里提前的宾语，中文按用户给的句子（第39条）放回“造成”后面；continual、inflict '
                                                         '两个重点词因此同在一组（T34 倒装）'},
          '非人声': {'8.35–8.60s': {'配音指纹': '79f315bb8b44',
                                 '依据': '2026-10-26 27 逐 10 ms 实测（S1 w 5.560–5.650s，元音气声收尾）：wildlife 的 /aɪ/ 从 '
                                       '-34 dB 连续降到 -46 dB（重心 2.3–3.1 kHz），中间没有 -55 dB 低谷，紧接 5.62 起的 /f/（重心 '
                                       '>4.7 kHz），是词的一部分，保留',
                                 '实测': {'最响dB': -32.3, '重心Hz': 0, '周期': 0.0, '低频dB': 0.0}},
                  '8.38–8.47s': {'配音指纹': '79f315bb8b44',
                                 '依据': '2026-10-26 27 逐 10 ms 实测（S1 w 5.560–5.650s，元音气声收尾）：wildlife 的 /aɪ/ 从 '
                                       '-34 dB 连续降到 -46 dB（重心 2.3–3.1 kHz），中间没有 -55 dB 低谷，紧接 5.62 起的 /f/（重心 '
                                       '>4.7 kHz），是词的一部分，保留',
                                 '实测': {'最响dB': -36.5, '重心Hz': 3332, '周期': 0.2, '低频dB': -7.4}},
                  '13.45–13.47s': {'配音指纹': '79f315bb8b44',
                                   '依据': '2026-10-26 27 逐 10 ms 实测（S2 w 3.865–3.890s，词头起始浊音）：逗号停顿后 one 的 /w/ '
                                         '起始：-48～-54 dB、低频占比 -1～-2 dB，紧连 3.89 起 -31→-16 dB、重心 0.6 kHz 的 '
                                         '/w/，是词的一部分，保留',
                                   '实测': {'最响dB': -47.0, '重心Hz': 2483, '周期': 0.25, '低频dB': -0.5}},
                  '14.33–14.36s': {'配音指纹': '79f315bb8b44',
                                   '依据': '2026-10-26 27 逐 10 ms 实测（S2 w 4.750–4.775s，塞音除阻）：reactors 的 '
                                         '/kt/：4.73–4.81 是 -52～-65 dB 的闭塞，4.75 一帧 -44 dB 是 /k/ 除阻，4.82 起 -32 '
                                         'dB、重心 2.5–3.4 kHz 是 /t/ 除阻，是词的一部分，保留',
                                   '实测': {'最响dB': -42.9, '重心Hz': 1914, '周期': 0.25, '低频dB': -9.2}},
                  '20.38–20.42s': {'配音指纹': '79f315bb8b44',
                                   '依据': '2026-10-26 27 逐 10 ms 实测（S2 w 10.795–10.840s，塞音除阻）：Europe 句尾 '
                                         '/p/：10.73–10.78 是 -57～-63 dB 闭塞，10.79 -33 dB 除阻、10.80–10.83 送气衰减到 '
                                         '-59 dB，是词尾 /p/，保留',
                                   '实测': {'最响dB': -31.3, '重心Hz': 1685, '周期': 0.14, '低频dB': -4.3}},
                  '28.51–28.61s': {'配音指纹': '79f315bb8b44',
                                   '依据': '2026-10-26 27 逐 10 ms 实测（S3 w 7.105–7.205s，元音气声收尾）：hours 的 /ɚ/ 从 -38 '
                                         'dB 连续降到 -48 dB（重心 1.0–2.6 kHz），中间没有 -55 dB 低谷，7.19 起是重心 3.8–5.5 '
                                         'kHz、低频 -27～-57 dB 的词尾 /z/，是词的一部分，保留',
                                   '实测': {'最响dB': -36.2, '重心Hz': 1864, '周期': 0.22, '低频dB': -3.0}},
                  '33.45–33.47s': {'配音指纹': '79f315bb8b44',
                                   '依据': '2026-10-26 27 逐 10 ms 实测（S4 w 3.715–3.730s，元音收尾）：off-limits 末尾 /ɪ/ 从 '
                                         '-29 dB 连续降到 -50 dB，3.73–3.76 是 -58～-69 dB 的 /t/ 闭塞，3.77 起重心 3.6–6.5 '
                                         'kHz 的 /ts/，是词的一部分，保留',
                                   '实测': {'最响dB': -45.2, '重心Hz': 2308, '周期': 0.0, '低频dB': -1.8}},
                  '46.57–46.65s': {'配音指纹': '79f315bb8b44',
                                   '依据': '2026-10-26 27 逐 10 ms 实测（S5 w 8.815–8.840s，浊音闭塞）：side 的 /d/ '
                                         '浊音闭塞：-38～-48 dB、低频 -1～-2 dB、周期 0.5，8.84 -57 dB 低谷后 8.85 是 /d/ 除阻，是词尾 '
                                         '/d/，保留',
                                   '实测': {'最响dB': -37.0, '重心Hz': 2845, '周期': 0.29, '低频dB': -1.3}},
                  '46.62–46.65s': {'配音指纹': '79f315bb8b44',
                                   '依据': '2026-10-26 27 逐 10 ms 实测（S5 w 8.815–8.840s，浊音闭塞）：side 的 /d/ '
                                         '浊音闭塞：-38～-48 dB、低频 -1～-2 dB、周期 0.5，8.84 -57 dB 低谷后 8.85 是 /d/ 除阻，是词尾 '
                                         '/d/，保留',
                                   '实测': {'最响dB': -37.0, '重心Hz': 1028, '周期': 0.5, '低频dB': -0.9}},
                  '74.57–74.60s': {'配音指纹': '79f315bb8b44',
                                   '依据': '2026-10-26 27 逐 10 ms 实测（S9 w 4.160–4.190s，词头起始浊音）：wolves 的 '
                                         '/z/（4.06–4.13 重心 5.5 kHz）之后 4.15 -49 dB 低谷，4.16–4.28 是 -41→-22 dB、重心 '
                                         '0.3–0.6 kHz、低频 -1 dB 的 boar /b/ 浊音起始，是词的一部分，保留',
                                   '实测': {'最响dB': -33.9, '重心Hz': 790, '周期': 0.55, '低频dB': -1.0}},
                  '78.78–78.82s': {'配音指纹': '79f315bb8b44',
                                   '依据': '2026-10-26 27 逐 10 ms 实测（S9 w 8.150–8.185s，词头起始浊音）：逗号停顿后 with 的 /w/ '
                                         '起始：-45～-52 dB、低频占比 0～-3 dB，紧连 8.19 起 -32→-11 dB 的 /w/，是词的一部分，保留',
                                   '实测': {'最响dB': -44.3, '重心Hz': 2315, '周期': 0.3, '低频dB': -0.4}},
                  '118.72–118.75s': {'配音指纹': '79f315bb8b44',
                                     '依据': '2026-10-26 27 逐 10 ms 实测（S14 w 7.765–7.795s，塞音除阻）：polluted 词尾 '
                                           '/d/：7.67–7.76 /ᵻ/ 衰减，7.76–7.78 -37～-49 dB、低频 -1～-3 dB 是 /d/ '
                                           '除阻，7.79–7.82 -56～-67 dB 静音后 7.83 起是 sites 的 /s/（重心 3.8–6.3 '
                                           'kHz），是词的一部分，保留',
                                     '实测': {'最响dB': -34.1, '重心Hz': 1896, '周期': 0.27, '低频dB': -1.4}},
                  '127.78–127.81s': {'配音指纹': '79f315bb8b44',
                                     '依据': '2026-10-26 27 逐 10 ms 实测（S15 w 4.510–4.530s，词头起始浊音）：逗号停顿后 and '
                                           '的浊音起始：-43～-46 dB、低频占比 0～-5 dB，紧连 4.54 起 -24→-5 dB 的 and '
                                           '元音；左边是已删的吸气（非人声区间到 4.509），同 26 的判法，是词的一部分，保留',
                                     '实测': {'最响dB': -42.7, '重心Hz': 1853, '周期': 0.18, '低频dB': -0.2}},
                  '135.19–135.22s': {'配音指纹': '79f315bb8b44',
                                     '依据': '2026-10-26 27 逐 10 ms 实测（S15 w 11.925–11.945s，浊音闭塞）：methods 的 /d/ '
                                           '浊音闭塞：11.87–11.93 -32～-44 dB、重心 0.7–1.3 kHz、低频 -2～-4 dB，11.94–11.95 '
                                           '-57～-63 dB 低谷后 11.96 起是词尾 /z/（重心 3.4–6.1 kHz），是词的一部分，保留',
                                     '实测': {'最响dB': -40.2, '重心Hz': 873, '周期': 0.2, '低频dB': -2.3}},
                  '148.08–148.13s': {'配音指纹': '79f315bb8b44',
                                     '依据': '2026-10-26 27 逐 10 ms 实测（S16 w 11.625–11.680s，塞音除阻）：cost 句尾 '
                                           '/t/：11.59–11.61 是 -54～-67 dB 闭塞，11.62–11.67 -34～-52 dB、重心 2.3–4.0 '
                                           'kHz 是 /t/ 除阻送气，之后降到 -62 dB 以下，是词尾 /t/，保留',
                                     '实测': {'最响dB': -30.8, '重心Hz': 3794, '周期': 0.22, '低频dB': -14.0}},
                  '97.38–97.41s': {'配音指纹': '79f315bb8b44',
                                   '依据': '2026-10-26 27 逐 10 ms 实测（S12 w 4.205–4.240s，词头起始浊音）：合成标点换分号后 birds; '
                                         '停顿之后 and 的浊音起始：-44～-50 dB、低频占比 0～-5 dB、周期 0.38，紧连 4.24 起 -24→-9 dB 的 '
                                         'and 元音；左边 4.01–4.206 是程序已删的吸气（非人声区间 紧贴词头），同 26、本篇 S15 的判法，是词的一部分，保留',
                                   '实测': {'最响dB': -45.7, '重心Hz': 3002, '周期': 0.38, '低频dB': -0.6}}},
          '删除段': {'S2 raw 7.2700-7.6600': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '79f315bb8b44',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[7.405, 7.650958, '紧贴词头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['lost'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S6 raw 7.5400-8.0210': {'类型': '紧贴词头的非人声',
                                           '配音指纹': 'f431c52b5e94',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[7.79, 8.021125, '紧贴词头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['lost', 'post'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S7 raw 3.3841-3.5050': {'类型': '紧贴词尾的非人声',
                                           '配音指纹': '79f315bb8b44',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[3.294125, 3.41, '紧贴词尾']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S15 raw 4.1050-4.5086': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '79f315bb8b44',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[4.255, 4.508667, '紧贴词头']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost', 'post'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S16 raw 4.0950-4.6850': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '79f315bb8b44',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[4.44, 4.655875, '紧贴词头']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S16 raw 11.3702-11.4546': {'类型': '紧贴两头的非人声',
                                              '配音指纹': '79f315bb8b44',
                                              '依据': "2026-10-15 删除段对应 非人声区间 [[11.360208, 11.444625, '紧贴两头']]（w "
                                                    '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 '
                                                    '< -10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                    "内最安静处的过零点；复核报 ['lost', 'post', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 "
                                                    'dB），不是词'},
                  'S12 raw 3.8550-4.2161': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '79f315bb8b44',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[4.01, 4.206083, '紧贴词头']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['post'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S6 raw 7.5650-8.0210': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '79f315bb8b44',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[7.79, 8.021125, '紧贴词头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['lost', 'post'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"}},
          '停顿位置': {'S10 agriculture, / forestry, @4.255': '2026-10-26 27 逐 5 ms 实测（w 秒）：agriculture 末尾 /ɚ/ 从 '
                                                          '-20 dB 连续降到 4.255 的 -44 dB（重心 1→3.8 kHz），4.265 起是 '
                                                          'forestry 的 /f/（重心 4.8–7.4 kHz、-41→-25 '
                                                          'dB）；插入点在两词之间的最低处',
                   'S10 forestry, / and @5.048': '2026-10-26 27 逐 5 ms 实测（w 秒）：forestry 的 /i/ 直接连 and 的 /æ/，没有 '
                                                 '-55 dB 低谷；按频段量，1.7–2.8 kHz（/i/ 的 F2）到 5.05 前后才降，300–900 '
                                                 'Hz（/æ/ 的 F1）5.04 起升到最高；交界段 5.030（-25.4 dB）、5.045（-24.4 '
                                                 'dB）是两个局部最低，取 5.045 这一帧里的过零点 5.047625 写进 停顿插入点；程序原来插在 5.000，是 '
                                                 '/i/ 的中间',
                   'S6 deer, / and @2.150': '2026-10-26 27 逐 5 ms 实测（w 秒）：deer 的 /ɪɹ/ 降到 2.130 的 -27 '
                                            'dB，2.135–2.150 是 -43～-47 dB 的最低段，2.155 起是 and 的起音（-31、-34、-46、-38 '
                                            'dB 后 2.175 起 -22 dB）；插入点在两词之间最深的 2.150',
                   'S9 boar, / and @4.730': '2026-10-26 27 逐 5 ms 实测（w 秒）：boar 的 /ɹ/ 直接连 and 的 /æ/，没有 -55 dB '
                                            '低谷；4.705–4.730 是交界段（-25、-27、-16、-16、-24、-28 dB），4.730（-28 '
                                            'dB）是其中最低，之后 4.735 起 and 开口（-14 dB）；插入点在交界最低处，已 ≤ -24 dB',
                   'S9 wolves, / boar, @4.155': '2026-10-26 27 逐 5 ms 实测（w 秒）：wolves 的 /z/（重心 5.5 kHz）到 4.135 '
                                                '止，4.150–4.155 是 -48～-49 dB 的低谷，4.160 起是 boar 的 /b/ 浊音起始（重心 '
                                                '0.3–1.2 kHz）；插入点在两词之间最深的低谷',
                   'S12 2007, / found @2.060': '2026-10-26 27 逐 5 ms 实测（w 秒，合成标点换分号后的新声音）：2007 末尾 seven 的 '
                                               '/n/（重心 0.4–0.7 kHz）从 -27 dB 降到 2.045 的 -55 dB，2.060 是 -59 dB '
                                               '最深处，2.075 起 found 的 /f/（重心 4.1–7.3 '
                                               'kHz）升起；插入点在两词之间最深的低谷；停顿删除区间（逐 2.5 ms，出片程序同一算法）：2007 的 /n/ 降到 '
                                               '2.045 的 -55 dB，found 的 /f/ 2.075 后升到 -54 dB 以上；程序原来删 '
                                               '2.060–2.075，起点前 5 ms 是 -54.0 dB（独立复核 pre -54.7，A10）；改删 '
                                               '2.065–2.0725：起点前 5 ms -59.2 dB、终点后 5 ms -57.9 dB，删掉的部分最响 -57 '
                                               'dB，没有词的声音',
                   'S12 One, / in @0.405': '2026-10-26 27 逐 5 ms 实测（w 秒，合成标点换分号后的新声音）：One 的 /n/（重心 0.6–1.8 '
                                           'kHz）从 -9 dB 降到 0.405 的 -49 dB，0.410 起 in 开口（-22 dB）；插入点在两词之间的最低处'},
          '响度骤降': {'98.1–98.8s': {'配音指纹': '79f315bb8b44',
                                  '低': 6.1,
                                  '句子': 'S12 fewer species 的 -pecies',
                                  '依据': '2026-10-26 实际声音核实（合成标点换分号、停顿删除区间之后的新声音）：audio_qc 报比全片低 6.1 dB，在 01–25 '
                                        '已定稿成片同一检查的基线 6.1–7.9 dB 以内。这一段是 species 的 /p/ 闭塞（98.00–98.04 '
                                        '数字静音）把后半个词单独切成一段；a.wav 逐 20 ms（dB/重心Hz）98.06:-33/3324 98.08:-23/1290 '
                                        '98.14:-26/1720 98.20:-29/2648 98.24:-27/5859 98.30:-29/6038 '
                                        '98.36:-30/1791 98.42:-30/1543 98.50:-40/2467 98.58:-40/1948 '
                                        '98.64:-37/5110 98.68:-34/4902 98.72:-53/2268：/p/ 除阻、/iː/、/s/、/iː/、词尾 '
                                        '/z/ 依次相连，第二个 /iː/ 在逗号前从 -28 自然减弱到 -42 dB，重心 1.2–2.5 kHz 与正常 /iː/ '
                                        '一致，没有发闷；草稿发出时请用户试听这一处',
                                  '用户原话': '用户 '
                                          '2026-10-22（第22篇做声音时）：“关于这个制作音频……你按照你认为最好的方式来做就行，不用特意问我……然后给我这个视频。”'}},
          '中文意思': {'S1 synonymous with': '不是被隔开的意思：“是”对应英文 is（单独一组），synonymous with '
                                         '在中文里只对“代名词”，“是灾难的代名词”里“灾难”是 disaster，用户审过的标法'}},
 '结尾解说': '简述',
 '高亮按实际开口': True,
 '高亮开口门槛': 40,
 '术语': {'Chernobyl': '切尔诺贝利',
        'Soviet Ukraine': '苏联乌克兰',
        'Europe': '欧洲',
        'Pripyat': '普里皮亚季',
        'Belarus': '白俄罗斯',
        'Current Biology': '《当代生物学》',
        'Belarusian': '白俄罗斯'},
 '结尾句': {'S16': {'前段语速': 0.9,
                 '最后一段语速': 0.78,
                 '最后一段前停顿': 0.7,
                 '接点': [101940, 131340],
                 '依据': '全篇结尾句按 07 定下的标准（用户 2026-10-10 同意并要求所有视频统一）：前段 0.9、最后一段“but the sluggish rot of fallen '
                       "leaves keeps a quieter ledger of radiation's cost.” 0.78、前面停 0.7 秒。接点由 结尾句接点.py "
                       '自动找：0.9 那遍最后一个标点后最长静音（315 ms）的正中 4.247 s，0.78 那遍（430 ms）的正中 5.473 s，所在帧和两侧各 5 ms 都低于 '
                       '-55 dB（程序以 08 校准：与人工核实的接点落在同一段静音里）'}},
 '非人声区间': {'S2': [[7.405, 7.650958, '紧贴词头']],
           'S6': [[7.79, 8.021125, '紧贴词头']],
           'S15': [[4.255, 4.508667, '紧贴词头']],
           'S16': [[4.44, 4.655875, '紧贴词头'], [11.360208, 11.444625, '紧贴两头']],
           'S7': [[3.294125, 3.41, '紧贴词尾']],
           'S12': [[4.01, 4.206083, '紧贴词头']]},
 '区间声音指纹': {'S2': 'cba32620d71a',
            'S6': '348ffa5634fe',
            'S7': 'd1a01f274ca3',
            'S10': 'b688e7ab5731',
            'S12': '37a272d3d6d6',
            'S15': 'f8b766ac3df5',
            'S16': '44468766ad0b'},
 '停顿插入点': {'S10': {'3': 5.047625}},
 '合成标点': {'S12': [['birds, and', 'birds; and']]},
 '停顿删除区间': {'S12': {'2': [2.065, 2.0725]}, 'S6': {'4': [7.57, 7.95]}},
 'allow_clash': ['reserves', 'nutrients'],
 '说明放宽特批': {'S16': {'倍数': '整屏',
                    '依据': '用户 2026-10-28 原话（问 27 换行变化后）：“哎呀，都同意，都同意，按照你认为最好的方式来做，按照你认为最好的方式来做”；用户 2026-10-28 '
                          '原话（看 27 S16 '
                          '结尾简述截图，用户要求整屏，特批）：“然后整个屏幕啊，整个屏幕这个整整体字体实在太小了，尽量把整个屏幕的字体扩大，把整个屏幕的全部的空间尽量全都利用起来。合理的分行，要合理分行就尽量让，就是尽量在这个屏幕内，就是尽可能的让我们这个字体就是能够去达到一个最大的程度。这个大小最大的程度这这这个字体大小实在太小了。”'}},
 '换行变更记录': [{'日期': '2026-10-28',
             'S11': '用户 2026-10-28 原话（问 27 换行变化后）：“哎呀，都同意，都同意，按照你认为最好的方式来做，按照你认为最好的方式来做”；用户 2026-10-28 '
                    '原话（待改清单第19条）：“在一些研究中放到 上面。更小的微生物过得更差。放到下面。汉语意思分成两行。在一些研究中，占一行更小的微生物过得更差占一行。”',
             'S14': '用户 2026-10-28 原话（问 27 换行变化后）：“哎呀，都同意，都同意，按照你认为最好的方式来做，按照你认为最好的方式来做”；用户 2026-10-28 '
                    '原话（待改清单第23条）：“第三项研究于2014年3月发现，在最严重的 被污染的 地点，落叶的分解少了约40%， 这个调整一下继续。按照我给的意思来，你按照最好的方法来调整。”',
             'S16': '用户 2026-10-28 原话（问 27 换行变化后）：“哎呀，都同意，都同意，按照你认为最好的方式来做，按照你认为最好的方式来做”；用户 2026-10-28 '
                    '原话（待改清单第28条）：“尽量把整个屏幕的字体扩大，把整个屏幕的全部的空间尽量全都利用起来。合理的分行”；第27条：“但落叶迟缓的腐烂，这个改为……就按照我这个意思来改”',
             'S9': '用户 2026-10-28 原话（问 27 '
                   '换行变化后）：“哎呀，都同意，都同意，按照你认为最好的方式来做，按照你认为最好的方式来做”；第17条用户给的中文把地点状语提到“拍到了”前面，整组后换行变了',
             'S15': '用户 2026-10-28 原话（问 27 '
                    '换行变化后）：“哎呀，都同意，都同意，按照你认为最好的方式来做，按照你认为最好的方式来做”；第25条用户给的中文“低但持续的剂量会造成多大损害”整组倒序后换行变了'}],
 '分段增益dB': {'S13': {'1': 1.5}, 'S14': {'1': 1.25}}}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
