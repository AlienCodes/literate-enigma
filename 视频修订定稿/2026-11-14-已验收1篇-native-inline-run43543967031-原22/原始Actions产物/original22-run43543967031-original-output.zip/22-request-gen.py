#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('On 2 September 2013', '2013年9月2日，'),
     ('the news broke', '一则新闻传开，'),
     ('that', '说'),
     ('a London', '伦敦一座'),
     ('**skyscraper** **under construction**', '**正在建设中的**(under construction)**摩天大楼**(skyscraper)'),
     ('had damaged', '损坏了'),
     ('a Jaguar.', '一辆捷豹车。')],
    '（that…：同位语从句，说明 news 的内容，被谓语 broke 隔开；\nunder construction：在建）']]),
 (1,
  [[[('Martin Lindsay', '马丁·林赛'),
     ('had left the **saloon**', '把这辆**轿车**(saloon)停在'),
     ('by the **pavement** on Eastcheap,', '伊斯特奇普街的**人行道**(pavement)旁边，'),
     ('opposite', '正对着'),
     ("the tower's", '这座高楼的'),
     ('**frontage**.', '**正面**(frontage)。')],
    '（leave sth somewhere：把某物停放在某处；\nopposite…：介词短语，补充说明位置）']]),
 (1,
  [[[('He returned', '他回来时'),
     ('to find', '发现，'),
     ('its wing mirror', '车的后视镜已经'),
     ('**warped**,', '**翘曲**(warped)，'),
     ('its panels', '车身板'),
     ('**deformed**', '**变形**(deformed)，'),
     ('and', '并且'),
     ('its **badge**', '**车标**(badge)也'),
     ('**distorted**.', '**扭曲了**(distorted)。')],
    '（returned to find…：不定式表结果，回来后发现……；\nfind sth done：发现某物处于……状态，三组并列）']]),
 (1,
  [[[('The **glazed**', '上方那面**镶玻璃的**(glazed)'),
     ('**facade** above', '**正面墙**(facade)'),
     ('was to blame.', '是罪魁祸首。')],
    '（be to blame：应负责任，是……的原因）\n（这面玻璃外墙向内弯曲，像凹面镜一样，\n把阳光反射并集中到街面，造成局部高温，\n烤坏了停在那里的汽车，因此成了“罪魁祸首”。）']]),
 (2,
  [[[('Rafael Viñoly', '拉斐尔·维诺利（在设计中）'),
     ('curved the south face of 20 Fenchurch Street inward,', '将芬丘奇街20号的南立面向内弯曲，')],
    '（curve sth inward：使……向内弯曲）'],
   [[('**enlarging**', '**扩大了**(enlarging)'),
     ('the upper **storeys**,', '上部**楼层**(storeys)，'),
     ('where', '那里的'),
     ('**tenants**', '**租户**(tenants)'),
     ('pay', '支付着'),
     ('a **premium**.', '**溢价**(premium)（更高的租金）。')],
    '（enlarging…：现在分词短语表结果；\nwhere…：非限制性定语从句，修饰 storeys）']]),
 (2,
  [[[('That **geometry**', '这种**几何形状**(geometry)'),
     ('acted like', '就像'),
     ('a **magnifying** glass,', '一面**放大**(magnifying)镜，')],
    '（act like：起……的作用）'],
   [[('focusing **sunlight**', '把**阳光**(sunlight)汇聚'),
     ('into a **beam**', '成一道**光束**(beam)，'),
     ('up to six times brighter than direct sun.', '亮度可达直射阳光的六倍。')],
    '（focusing…：现在分词短语表结果；\nfocus A into B：把 A 汇聚成 B；\nup to…brighter…：形容词短语作后置定语，修饰 beam）']]),
 (2,
  [[[('It was measured', '测得的温度'), ('at about', '约为'), ('110 degrees Celsius,', '110摄氏度，')],
    '（be measured at：测得为……）'],
   [[('and a **reporter**', '一名**记者**(reporter)还'),
     ('fried an egg in a **pan**', '在**平底锅**(pan)里'),
     ('using the', '利用'),
     ('**reflection**.', '**反射光**(reflection)煎熟了一个鸡蛋。')],
    '（using…：现在分词短语表方式）']]),
 (3,
  [[[('The **developers**', '**开发商**(developers)'),
     ('issued', '作出了'),
     ('an **apology**', '**道歉**(apology)，'),
     ('and **reimbursed**', '并**赔付了**(reimbursed)'),
     ('almost 1,000 pounds', '近1,000英镑的'),
     ('for repairs.', '修理费。')],
    '（issue an apology：公开道歉；\nreimburse…for…：赔付……的费用）']]),
 (3,
  [[[('Parking bays', '路边停车位'),
     ('were **suspended**', '**暂停使用**(suspended)，'),
     ('and', '并且'),
     ('a', '一道'),
     ('**provisional**', '**临时的**(provisional)'),
     ('**barrier**', '**屏障**(barrier)'),
     ('was **erected**.', '被**搭建了起来**(erected)。')]]]),
 (3,
  [[[('The beam', '这道光束'),
     ('struck for about two hours a day, two to three weeks **annually**,',
      '**每年**(annually)会照射两到三周、每天约照射两小时，')],
    '（for…, …：两个时间状语并列）'],
   [[('because of', '因为这是'), ("the sun's", '太阳的'), ('**angle of elevation**.', '**仰角**(angle of elevation)。')],
    '（angle：角度）']]),
 (3,
  [[[('Newspapers', '报纸'),
     ('dubbed the Walkie-Talkie', '把对讲机大楼'),
     ('the Walkie-Scorchie,', '戏称为“烤焦机大楼”，'),
     ('a **taunt**.', '这是一句**嘲讽**(taunt)。')],
    '（dub：把……戏称为、给……起绰号；\nWalkie-Talkie：大楼的俗称，原意是对讲机；\nScorchie：由 scorch（烤焦）改字而来；\na taunt：同位语，说明这个绰号）']]),
 (4,
  [[[('The **architect**', '这位**建筑师**(architect)'),
     ('was **candid**,', '很**坦率**(candid)，'),
     ('admitting', '承认犯了'),
     ('many mistakes.', '很多错误。')],
    '（admitting…：现在分词短语作伴随状语）']]),
 (4,
  [[[('Viñoly had **anticipated** the focusing, he said,', '维诺利说，他**预料到了**(anticipated)外墙会聚光，'),
     ('but not', '却没想到'),
     ('its **intensity**.', '聚光的**强度**(intensity)会这么大。')],
    '（he said：插入语；\nbut not its intensity：省略句，\n= but he had not anticipated its intensity）']]),
 (4,
  [[[('**Sun louvres** in the original design', '据报道，原设计中的**遮阳百叶**(Sun louvres)'),
     ('were reportedly removed in **cost-cutting**.', '在**削减成本**(cost-cutting)时被删掉了。')],
    '（Sun louvres：遮阳百叶，外墙上成排的斜板，\n用来遮挡直射阳光、减少强光和热量；\nreportedly：据报道，插入的副词；\nin cost-cutting：在削减成本时）']]),
 (4,
  [[[('Nor was this', '这也不是'),
     ('his first', '他第一次'),
     ('**architectural**', '出现**建筑上的**(architectural)'),
     ('**miscalculation**.', '**失算**(miscalculation)。')],
    '（Nor 放句首：也不……，主谓倒装）']]),
 (4,
  [[[('In 2010', '2010年，'),
     ('the **infamous** **glare** from his curved, **reflective** Vdara hotel in Las Vegas',
      '他那座位于拉斯维加斯、弯曲**反光的**(reflective)维达拉酒店反射出**臭名昭著的**(infamous)**强光**(glare)，')],
    '（from his…hotel：介词短语作后置定语，修饰 glare）'],
   [[("burned a guest's **scalp** by the pool.", '在泳池边灼伤了一位客人的**头皮**(scalp)。')]]]),
 (5,
  [[[('On 12 February 2014', '2014年2月12日，'),
     ('a', '一项'),
     ('**permanent**', '**永久性的**(permanent)'),
     ('**fixture**', '**固定装置**(fixture)方案'),
     ('was announced:', '公布，')],
    '（冒号后补充说明 fixture 的内容）'],
   [[('**horizontal**', '那就是在外墙加装**水平的**(horizontal)'),
     ('**aluminium**', '**铝制**(aluminium)散光'),
     ('**fins**', '**鳍片**(fins)，'),
     ('to', '来'),
     ('**diffuse**', '**散射**(diffuse)光线、减弱'),
     ('the **brightness**,', '**亮度**(brightness)，'),
     ('reportedly', '据报道'),
     ('costing', '花费达'),
     ('several million pounds.', '数百万英镑。')],
    '（to diffuse…：不定式表目的；\nreportedly costing…：现在分词短语，补充说明花费）']]),
 (5,
  [[[('In September 2015', '2015年9月，'),
     ("Building Design's **critics**", '《建筑设计》杂志的**评论家**(critics)们'),
     ('gave the **notorious** tower the Carbuncle Cup,', '将“烂疮杯”颁给了这座**声名狼藉的/臭名远扬的**(notorious)大楼，')],
    '（give sb sth：授予某人某物）'],
   [[("a **trophy** for the UK's worst new building.", '这是一个专门颁给英国最糟糕新建筑的**奖杯**(trophy)。')],
    '（a trophy…：同位语，说明 the Carbuncle Cup）']]),
 (5,
  [[[('The **ballot**', '这次**投票**(ballot)'), ('was **unanimous**.', '**全体一致**(unanimous)。')],
    '（简述：▸事故：2013年，伦敦芬丘奇街20号、俗称对讲机的大楼，把阳光反射到街边，将马丁·林赛的捷豹车烤得变形。▸原理：内凹的玻璃南墙扩大了租金更高的上层面积，也像凹面镜，把反射的阳光集中到街面；光束亮度最高为直射阳光六倍，受照处温度约110℃。▸应急：开发商赔偿近千英镑，停用车位并设屏障；由于太阳高度角变化，这种强光每年只出现两三周、每天约两小时。▸失算：建筑师维诺利预料到聚光，却低估了强度；遮挡阳光的百叶板据报因省钱被删，他设计的另一酒店也曾反光灼伤客人。▸整改：2014年公布在外墙加装横向铝片、分散光线的方案，据报需数百万英镑；2015年，这座楼获颁英国最差新建筑的烂疮杯。）']])]

out = {'no': '22',
 'title_en': 'The Building That Melted a Car',
 'title_zh': '会烤化汽车的大楼',
 'title_fx': {'hl': ['Melted', 'Car'], 'ghost': []},
 'sentences': [],
 '核对确认': {'引号': {'S11 “”': '用户 2026-10-23 原话“报纸把对讲机大楼戏称为“烤焦机大楼””自带引号，照用户原话保留（待改清单第7条）',
                 'S11-1 “”': '用户 2026-10-23 原话“报纸把对讲机大楼戏称为“烤焦机大楼””自带引号，照用户原话保留（待改清单第7条）',
                 'S18-1 “”': '用户 2026-10-23 原话“将“烂疮杯”颁给了这座……大楼”自带引号，照用户原话保留（待改清单第10条）'},
          '已告诉用户被去掉的重点词': '2026-10-22 已在会话中把 reflection（撞02）、elevation（撞10）从22去掉原样告诉用户，并说明42的 distortion 改回普通词',
          '牛津逗号': {'S3 its wing mirror warped, its panels deformed and': '文章英文是英式写法，三项并列不用牛津逗号；英文正文与文章逐字一致，不改'},
          '短语': {'S10 angle … of': 'angle of elevation 里 elevation 因撞词（第10篇）已去掉加粗；angle 本身就是“角度”（速查表释义），of '
                                   'elevation 写在 note',
                 'S14 in … cost-cutting': 'in 是普通介词（在……时），cost-cutting 本身就是“削减成本”（速查表释义），不是 in + 名词的固定用法'},
          '非人声': {'3.63–3.64s': {'配音指纹': 'fdd76effa2da',
                                 '依据': '2026-10-22 逐段看声音（S1 w 0.91–0.92s，孤立杂音）：September 词头 /s/ 擦音（重心 3.7 '
                                       'kHz，在词的时间范围内）'},
                  '10.53–10.61s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S1 w 8.08–8.16s，呼吸声）：Jaguar. 句尾 /ɑːɹ/ '
                                         '的气声收尾（连着元音，像呼吸的只占 3%）'},
                  '15.15–15.20s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S2 w 3.56–3.60s，孤立杂音）：Eastcheap 词尾 /p/ 除阻（前面 '
                                         '3.50–3.55 s 闭塞静音 -60 dB，除阻短于 60 ms）'},
                  '20.75–20.76s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S3 w 2.39–2.40s，孤立杂音）：warped 词尾 /pt/ 除阻（在词的时间范围内，短于 '
                                         '60 ms）'},
                  '26.54–26.55s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S4 w 1.43–1.45s，噗声）：above 词尾 /v/ 浊擦音收尾（低频重、紧贴词尾）'},
                  '44.33–44.34s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S6 w 5.93–5.94s，孤立杂音）：up 词尾 /p/ 除阻（重心 3.4 kHz、10 '
                                         'ms，在词的时间范围内）'},
                  '58.46–58.49s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S8 w 2.42–2.45s，噗声）：and 词头起始浊音（低频 -1～-2 dB 很重，紧接 '
                                         '2.46 s 元音 æ，词头起音）；它前面 2.17–2.42 s 的吸气已删'},
                  '61.44–61.45s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S8 w 5.40–5.42s，噗声）：repairs 词中 /p/ 除阻（在词的时间范围内，短于 '
                                         '60 ms）'},
                  '61.73–61.84s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S8 w 5.70–5.80s，呼吸声）：repairs 词中 /ɹ/ 向词尾 /z/ '
                                         '的过渡（5.68–5.79 s 弱浊音，5.80 s 起 /z/，在同一个词里）'},
                  '66.79–66.91s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S9 w 4.07–4.08s，噗声）：erected 词尾 /ᵻd/ 元音收尾（低频重、周期 '
                                         '0.4，连着元音）'},
                  '66.82–66.83s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S9 w 4.07–4.08s，噗声）：erected 词尾 /ᵻd/ 元音收尾（低频重、周期 '
                                         '0.4，连着元音）'},
                  '75.05–75.14s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S10 w 7.08–7.18s，呼吸声）：elevation. 句尾 /ən/ '
                                         '的鼻音/气声收尾（像呼吸的 0%）'},
                  '95.94–95.94s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S14 w 4.49–4.50s，孤立杂音）：cost-cutting 词中 /st/ '
                                         '擦音与除阻（重心 4.2 kHz）'},
                  '96.30–96.41s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S14 w 4.86–4.96s，呼吸声）：cost-cutting 词尾 /ɪŋ/ '
                                         '的弱收尾（4.80–4.95 s 连续衰减，无 -55 dB 断开）'},
                  '96.42–96.43s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S14 w 4.97–4.99s，噗声）：cost-cutting 句尾 /ŋ/ 收尾（-51 '
                                         'dB，低频重）'},
                  '98.25–98.34s': {'配音指纹': 'fdd76effa2da',
                                   '依据': '2026-10-22 逐段看声音（S15 w 0.83–0.93s，呼吸声）：his 词头 /h/（this 的 /s/ 在 0.83 '
                                         's 收住后，0.845–0.94 s 是 /h/ 送气，重心 2.5 kHz，直接连进 0.945 s 的元音 ɪ，无低谷）'},
                  '104.14–104.16s': {'配音指纹': 'fdd76effa2da',
                                     '依据': '2026-10-22 逐段看声音（S16 w 2.40–2.42s，噗声）：infamous 词尾 /s/ '
                                           '擦音收尾（左边贴着擦音）'},
                  '116.90–116.94s': {'配音指纹': 'fdd76effa2da',
                                     '依据': '2026-10-22 逐段看声音（S17 w 4.87–4.92s，孤立杂音）：announced 词尾 /st/ 除阻（短于 60 '
                                           'ms，在词的时间范围内）'},
                  '121.48–121.50s': {'配音指纹': 'fdd76effa2da',
                                     '依据': '2026-10-22 逐段看声音（S17 w 9.53–9.55s，噗声）：reportedly 词头 /ɹ/ 起始浊音（周期 '
                                           '0.4、低频重）'},
                  '124.02–124.15s': {'配音指纹': 'fdd76effa2da',
                                     '依据': '2026-10-22 逐段看声音（S17 w 12.06–12.20s，呼吸声）：pounds 词中 /aʊn/ 的收尾，接 '
                                           '12.19 s /d/ 闭塞、12.20 s 起 /dz/（在同一个词里）'},
                  '135.24–135.25s': {'配音指纹': 'fdd76effa2da',
                                     '依据': '2026-10-22 逐段看声音（S18 w 10.14–10.16s，噗声）：building. 句尾 /ŋ/ '
                                           '收尾（低频重、紧贴词尾）'}},
          '停顿位置': {'S13 focusing, / he @2.480': '2026-10-22 逐段看声音（S13 w 2.38–2.62s）：focusing 的 /ŋ/ 浊音到 2.47 s '
                                                '收住（周期 0.29→0.16），he 的 /h/ 送气 2.475–2.57 s（重心 2.9→4.9 '
                                                'kHz），两词之间没有静音低谷（交界约 -42 dB）；2.480 是交界处的最低点（-45.3 '
                                                'dB），在词与词之间，没插进元音。试过插在 2.475 交界：/h/ 整段 0.10 s 被 A19 当成停顿后吸气，故用 '
                                                '2.480'},
          '删除段': {'S16 raw 6.5950-6.9550': {'类型': '紧贴两头的非人声',
                                            '配音指纹': 'fdd76effa2da',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[6.585042, 6.943042, '紧贴两头']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S17 raw 2.8513-3.0411': {'类型': '紧贴两头的非人声',
                                            '配音指纹': 'fdd76effa2da',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[2.84125, 3.031125, '紧贴两头']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost', 'post', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 "
                                                  'dB），不是词'},
                  'S18 raw 2.2100-2.5100': '2026-10-15 删除段对应 非人声区间 [[2.2, 2.5]]（w 秒）：自动切点.py '
                                           '用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < -10 dB、周期 < '
                                           "0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms 内最安静处的过零点；复核报 ['lost'] "
                                           '是删掉的呼吸声本身偏响（-34～-47 dB），不是词',
                  'S5 raw 4.7750-5.1600': '2026-10-15 删除段对应 非人声区间 [[4.775, 5.12]]（w 秒）：自动切点.py '
                                          '用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < -10 dB、周期 < '
                                          "0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms 内最安静处的过零点；复核报 ['lost'] "
                                          '是删掉的呼吸声本身偏响（-34～-47 dB），不是词'},
          '对齐': {'S2-1 by the pavement on Eastcheap,': '后置介词短语 on Eastcheap 修饰 '
                                                       'pavement，中文“伊斯特奇普街的人行道旁边”前置作定语，by…旁边 包在两头，语序必须倒过来',
                 'S5-1 curved the south face of 20 Fe': '将字句：curved…inward 被宾语隔开，中文“将……向内弯曲”；of 20 Fenchurch '
                                                        'Street 前置作“芬丘奇街20号的”，语序必须倒过来',
                 'S6-2 up to six times brighter than ': '倍数比较结构（T13 整组处理）：中文“亮度可达直射阳光的六倍”，than direct sun '
                                                        '前置，语序必须倒过来',
                 'S10-1 struck for about two hours a d': '时间状语倒序：annually 在中文里提到最前（每年），two to three weeks 与 '
                                                         'two hours a day 在中文里先后对调，语序必须倒过来',
                 'S13-1 Viñoly had anticipated the foc': '插入语 he said 在中文里提到最前（维诺利说，他……），语序必须倒过来',
                 'S14-1 Sun louvres in the original de': '后置定语 in the original design 修饰 Sun '
                                                         'louvres，中文“原设计中的遮阳百叶”前置；reportedly '
                                                         '的“据报道，”按待改清单第19条“画面上要有：据报道，原设计中的遮阳百叶”留在最前，语序必须倒过来',
                 'S14-1 were reportedly removed in cos': '提前的介词短语：in cost-cutting '
                                                         '在中文里提到动词前（在削减成本时被删掉了），语序必须倒过来',
                 'S16-1 the infamous glare from his cu': '后置介词短语 from his … Vdara hotel in Las Vegas 修饰 '
                                                         'glare，中文整段前置（他那座位于拉斯维加斯、……维达拉酒店反射出……强光），in Las Vegas '
                                                         '也前置，语序必须倒过来',
                 "S16-2 burned a guest's scalp by the ": '提前的介词短语：by the pool 在中文里提到动词前（在泳池边灼伤了……），语序必须倒过来',
                 'S18-1 gave the notorious tower the C': '将字句、双宾语倒序：gave the tower the Cup → '
                                                         '将“烂疮杯”颁给了这座……大楼，语序必须倒过来',
                 "S18-2 a trophy for the UK's worst ne": "后置定语 for the UK's worst new building 修饰 "
                                                         'trophy，中文“专门颁给英国最糟糕新建筑的奖杯”前置，语序必须倒过来',
                 'S7-2 fried an egg in a pan': '提前的介词短语：in a pan、using the reflection '
                                               '两个状语在中文里提到动词前（在平底锅里利用反射光煎熟了），语序必须倒过来'},
          '排版指令': {'S14-1 删掉': '“被删掉了”是 removed 的译文（用户定稿原文），不是排版指令'}},
 '说明放宽特批': {},
 'allow_clash': ['reflection', 'enlarging', 'suspended', 'critics', 'permanent'],
 '高亮按实际开口': True,
 '高亮开口门槛': 40,
 '结尾句': {},
 '术语': {'London': '伦敦',
        'Jaguar': '捷豹',
        'Martin Lindsay': '马丁·林赛',
        'Eastcheap': '伊斯特奇普街',
        'Rafael Viñoly': '拉斐尔·维诺利',
        'Viñoly': '维诺利',
        'Fenchurch Street': '芬丘奇街',
        'Celsius': '摄氏度',
        'Walkie-Talkie': '对讲机',
        'Walkie-Scorchie': '烤焦机',
        'Vdara': '维达拉',
        'Las Vegas': '拉斯维加斯',
        'Building Design': '建筑设计',
        'Carbuncle Cup': '烂疮杯',
        'UK': '英国'},
 '非人声区间': {'S1': [[2.86, 3.126208, '紧贴词头']],
           'S8': [[2.17, 2.419208, '紧贴词头']],
           'S9': [[1.87, 2.05]],
           'S16': [[1.52, 1.72], [6.585042, 6.943042, '紧贴两头']],
           'S17': [[2.84125, 3.031125, '紧贴两头']],
           'S18': [[2.2, 2.5], [8.019458, 8.175, '紧贴词尾']],
           'S14': [[2.3, 2.54]],
           'S5': [[4.775, 5.12]]},
 '换行变更记录': [{'日期': '2026-10-23',
             'S1': '用户 2026-10-23 '
                   '原话：“如果要是ok的话，尽可能的就是英文上下和它的汉译尽量能够就是位置对齐……我们设置好的标准，尽量一定要去执行啊……你看现在这个前后这个标准它又不统一了。”',
             'S9': '用户 2026-10-23 '
                   '原话：“如果要是ok的话，尽可能的就是英文上下和它的汉译尽量能够就是位置对齐……我们设置好的标准，尽量一定要去执行啊……你看现在这个前后这个标准它又不统一了。”'},
            {'日期': '2026-10-23',
             'S4': '用户 2026-10-23 '
                   '原话：“这个避免它还是没有完美的对应到这个avert的下面……才智也没有非常非常就是非常精准的放到这个intellect的下面……你认认真真的处理一下这件事儿，立一道闸好不好？”（T34：同序的重点词拆开，中文字不改）',
             'S7': '用户 2026-10-23 '
                   '原话：“这个避免它还是没有完美的对应到这个avert的下面……才智也没有非常非常就是非常精准的放到这个intellect的下面……你认认真真的处理一下这件事儿，立一道闸好不好？”（T34：同序的重点词拆开，中文字不改）',
             'S9': '用户 2026-10-23 '
                   '原话：“这个避免它还是没有完美的对应到这个avert的下面……才智也没有非常非常就是非常精准的放到这个intellect的下面……你认认真真的处理一下这件事儿，立一道闸好不好？”（T34：同序的重点词拆开，中文字不改）',
             'S15': '用户 2026-10-23 '
                    '原话：“这个避免它还是没有完美的对应到这个avert的下面……才智也没有非常非常就是非常精准的放到这个intellect的下面……你认认真真的处理一下这件事儿，立一道闸好不好？”（T34：同序的重点词拆开，中文字不改）',
             'S17': '用户 2026-10-23 '
                    '原话：“这个避免它还是没有完美的对应到这个avert的下面……才智也没有非常非常就是非常精准的放到这个intellect的下面……你认认真真的处理一下这件事儿，立一道闸好不好？”（T34：同序的重点词拆开，中文字不改）'}],
 '结尾解说': '简述'}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
