#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('Each winter,', '每年冬天，'),
     ('**male**', '**雄性**(male)'),
     ('**humpback whales**,', '**座头鲸**(humpback whales)，'),
     ('and only males,', '而且只有雄性，')],
    '（and only males：插入语，强调只有雄性）'],
   [[('fill their **breeding grounds**', '会让它们的**繁殖地**(breeding grounds)回荡着'),
     ('with a **haunting**', '一段**萦绕于心头的**(haunting)'),
     ('**melody**.', '**旋律**(melody)。')],
    '（fill A with B：让 A 充满 B）']]),
 (1,
  [[[('**Sound units**', '若干**声音单元**(Sound units)'),
     ('**constitute**', '**构成**(constitute)'),
     ('phrases,', '乐句，')]],
   [[('and phrases', '乐句又'),
     ('build', '组成'),
     ('**themes**', '**主题**(themes)，'),
     ('in an **elaborate**', '形成一个**复杂精细的**(elaborate)'),
     ('**hierarchy**.', '**层级结构**(hierarchy)。')],
    '（in an elaborate hierarchy：方式状语）']]),
 (1,
  [[[('Each **rendition**', '每一次**表演/演奏**(rendition)'), ('lasts', '持续'), ('minutes,', '数分钟，')]],
   [[('and the song', '而这首歌'),
     ('can **recur**', '能**反复出现**(recur)'),
     ('for hours,', '数个小时，'),
     ('probably for **courtship**.', '很可能是为了**求偶**(courtship)。')],
    '（probably for courtship：目的状语，\n很可能是为了求偶）']]),
 (1,
  [[[('All the males in a **population**', '同一**种群**(population)中的所有雄性'),
     ('sing', '都唱着'),
     ('an **identical**', '**完全相同的**(identical)'),
     ('version,', '版本，')],
    '（in a population：后置定语，修饰 males）'],
   [[('which', '而它'), ('**evolves** **subtly** each year.', '每年都**不易察觉地**(subtly)**演变**(evolves)。')],
    '（which 引导非限制性定语从句，修饰 version）']]),
 (2,
  [[[('That is the rule.', '这就是规则。')],
    '（假设这群座头鲸的“年度金曲”是这样演变的：\n'
    '1. 第一年（版本 1.0）：\n'
    '整个海域的雄鲸都在唱一首完整的《鲸之歌 V1.0》。\n'
    '2. 第二年（版本 1.1）：某只带头的雄鲸，\n'
    '在唱高潮部分时，稍微拖长了一个音，\n'
    '或者变了一下调（这就是 subtly 不易察觉地演变）。\n'
    '其他鲸鱼觉得：“哎？这个改版挺帅啊！”于是纷纷跟着学。\n'
    '这一年，大家统一唱《鲸之歌 V1.1》。\n'
    '3. 第三年（版本 1.2）：又有鲸鱼在这个基础上，\n'
    '把结尾的节奏稍微加快了一点点。\n'
    '大家又统一跟着学，变成《鲸之歌 V1.2》。\n'
    '4. 第十年（版本 2.0）：经过连续十年的“微调打补丁”，\n'
    '这首歌可能已经面目全非，\n'
    '跟第一年的《V1.0》听起来完全不一样了。\n'
    '为什么要这么改？\n'
    '这是它们的一种“文化潮流”（求偶手段）。\n'
    '谁掌握了最新版本的流行歌，谁就能吸引到异性。\n'
    '这个规则就是这个样子，需要去演变歌曲。）']]),
 (2,
  [[[('**Off** eastern Australia,', '**在**(Off)澳大利亚东部**海域**(Off)，'), ('it was broken.', '这个规则被打破了。')],
    '（off：在……附近的海域）']]),
 (2,
  [[[('From 1995 to 1998,', '1995年至1998年间，'),
     ('**researchers**', '**研究人员**(researchers)'),
     ('used', '用'),
     ('hydrophones,', '水听器，'),
     ('or', '即'),
     ('underwater', '水下'),
     ('**microphones**,', '**麦克风**(microphones)，')],
    '（or underwater microphones：同位语，解释 hydrophones）'],
   [[('to record', '录下了'),
     ('{{=}}humpbacks on their **seasonal** **migration** along the **coastline**.',
      '沿**海岸线**(coastline)进行**季节性**(seasonal)**迁徙**(migration)的座头鲸。')],
    '（to record…：不定式作目的状语；\non their seasonal migration along the coastline：后置定语，\n修饰 humpbacks）']]),
 (2,
  [[[('In the mid-1990s,', '20世纪90年代中期，'),
     ('**merely** two of 82 singers', '82只歌者中**仅**(merely)有两只'),
     ('**emitted**', '**发出了**(emitted)'),
     ('a **distinctive**', '一首**与众不同的**(distinctive)'),
     ('new song,', '新歌，')],
    '（emit 指从某个源头向外释放或发出（光、声音、气味、气体等））'],
   [[('**utterly unlike**', '**完全不像**(utterly unlike)'),
     ('the **reigning**', '**占据主导地位的**(reigning)'),
     ('**chorus**.', '**合唱**(chorus)。')],
    '（utterly unlike…：形容词短语作后置修饰，补充说明 song）']]),
 (3,
  [[[('Within about two years,', '大约两年之内，'),
     ('**virtually**', '**几乎**(virtually)'),
     ('every', '每只'),
     ('singer', '歌者'),
     ('had **converted**,', '都已**转变**(converted)；')]],
   [[('and by 1998', '到1998年，'),
     ('the old song', '旧歌'),
     ('had been **displaced** **wholesale**.', '已被**全盘**(wholesale)**取代**(displaced)。')],
    '（had been displaced：过去完成时的被动语态）']]),
 (3,
  [[[('A study published in Nature in November 2000', '2000年11月发表于《自然》（Nature）的一项研究'), ('found that', '发现，')],
    '（published in…：过去分词短语作后置定语，修饰 study）'],
   [[('the new song', '这首新歌'),
     ('**resembled** that of the Indian Ocean population off western Australia,',
      '**与**(resembled)澳大利亚西部海域印度洋种群的歌**相似**(resembled)，')],
    '（that：指代 song）'],
   [[('apparently', '似乎是'),
     ('**ferried** east by **a handful of** visiting **performers**.',
      '由**一小批**(a handful of)来访的**歌手**(performers)向东**带来**(ferried)的。')],
    '（ferried east by…：过去分词短语作状语，被……向东带来）']]),
 (4,
  [[[('Nor was it', '这也并非'), ('a **freak**.', '**不寻常的事**(freak)。')],
    '（Nor was it…：\n'
    'nor 放在句首，\n'
    '意思是“也不是”“也没有”，\n'
    '在上文之外再补充一层否定。\n'
    '规则：nor 放在句首时，\n'
    '句子要部分倒装：\n'
    'be 动词、助动词或情态动词\n'
    '提到主语前面，\n'
    '即 Nor + be/助动词/情态动词 + 主语 + 其余部分。\n'
    '本句正常语序：\n'
    'It was not a freak either.\n'
    "例：He didn't call, nor did he write.\n"
    '（他没打电话，也没写信。）\n'
    "例：I can't swim, nor can my brother.\n"
    '（我不会游泳，\n'
    '我弟弟也不会。））']]),
 (4,
  [[[('In April 2011,', '2011年4月，'),
     ('a study in Current Biology', '《当代生物学》（Current Biology）上的一项研究'),
     ('**analysed**', '**分析了**(analysed)')]],
   [[('over a decade of **recordings** from six South **Pacific** populations.',
      '南**太平洋**(Pacific)六个种群十余年的**录音**(recordings)。')],
    '（from six South Pacific populations：后置定语，\n修饰 recordings）']]),
 (4,
  [[[('Song types', '歌型'),
     ('**primarily**', '**主要**(primarily)'),
     ('arose', '起源于'),
     ('off eastern Australia,', '澳大利亚东部海域附近，')]],
   [[('then **rippled** **eastward**', '然后**向东**(eastward)**如同涟漪般扩散**(rippled)，'),
     ('through **successive** populations', '穿过**相继的**(successive)一个个种群'),
     ('to French **Polynesia**,', '传至法属**波利尼西亚**(Polynesia)，')],
    '（ripple through…：如涟漪般扩散到……）'],
   [[('**generally**', '**通常**(generally)'),
     ('crossing the **region** within about two years.', '在大约两年内横跨该**区域**(region)。')],
    '（crossing the region…：现在分词短语作状语，表结果）']]),
 (5,
  [[[('Such', '如此'),
     ('**rapid change**,', '**快速的变化**(rapid change)，'),
     ('too fast for genetic **evolution**,', '对基因**演化**(evolution)来说太快了，')],
    '（too fast for…：插入语，补充说明 change）'],
   [[('points to', '指向的是'),
     ('**imitation**', '**模仿**(imitation)'),
     ('rather than', '而非'),
     ('**inheritance**,', '**遗传**(inheritance)，')],
    '（point to：指向；A rather than B：是 A 而不是 B）'],
   [[('a **persuasive** case of **cultural** **transmission**.',
      '即**文化**(cultural)**传递**(transmission)的一个**有说服力的**(persuasive)例证。')],
    '（同位语，补充说明前面的结论）']]),
 (5,
  [[[('Why males sing,', '雄性为何歌唱，'),
     ('and why they **overhaul** their songs,', '以及它们为何要**全面改造**(overhaul)它们的歌曲，'),
     ('remain', '仍然'),
     ('**controversial**.', '**存在争议**(controversial)。')],
    '（Why…and why…：两个主语从句并列作主语，谓语用复数 remain）']]),
 (5,
  [[[('One idea is that', '一种观点是，'),
     ('**novelty** itself', '**新奇**(novelty)本身'),
     ('**spurs**', '**推动了**(spurs)'),
     ('change.', '变化。')],
    '（that 引导表语从句；spur：促使，推动）']]),
 (5,
  [[[('Some', '一些'),
     ('**scholars**', '**学者**(scholars)'),
     ('are **reluctant** to', '**不愿**(reluctant)'),
     ('**define** this **as**', '把这种现象**界定为**(define as)'),
     ('culture in the human sense.', '人类意义上的文化。')],
    '（be reluctant to do：不愿做……；define A as B：把 A 界定为 B）']]),
 (5,
  [[[('Whatever the label,', '不管叫什么名号，'),
     ('a few **outsiders** off eastern Australia', '澳大利亚东部海域的一小批**外来者**(outsiders)，')],
    '（Whatever the label：让步状语，无论贴什么标签）'],
   [[('**reshaped**', '**重塑了**(reshaped)'), ('an entire', '整个'), ("population's music.", '种群的音乐。')],
    '（简述：▸常态：同一群体的雄性座头鲸会唱同一个版本的歌，通常每年只作细微改变，歌唱可能用于求偶。▸换歌：研究者在澳洲东部录到的82头鲸中，最初仅两头唱全新歌；约两年后，几乎整个鲸群都改唱新歌。▸来源：新歌与澳洲西部鲸群的歌相似，研究推测是少量来访鲸把它带到了东部。▸传播：六个南太平洋鲸群的十余年录音显示，新歌多从澳洲东部出现，再逐群向东传播，通常约两年传到法属波利尼西亚。▸解释：变化快得来不及靠基因一代代改变，支持鲸会相互模仿、学习的解释；为何换歌、是否等同人类文化，仍有争议。）']])]

out = {'no': '57',
 'title_en': 'A Change of Anthem in the Deep',
 'title_zh': '鲸歌易帜',
 'title_fx': {'hl': ['Anthem', 'Deep'], 'ghost': []},
 'sentences': [],
 '核对确认': {'合组': {'S4 subtly each year': '对齐不了：each year 中文“每年”（沿用文章定稿）放在“都在演变”前，subtly 中文“只是变化细微”放最后，拆开不通',
                 'S1 humpback whales': '对齐不了：humpback whales 是专名“座头鲸”，拆开不通',
                 'S4 All the males in a population': '对齐不了：in a population 是后置定语，修饰 males，中文“同一种群的所有雄鲸”定语必须提前',
                 'S4 evolves subtly each year': '对齐不了：用户 2026-11-07 给的译法“每年都不易察觉地演变”，each year 提到最前、subtly 放在 '
                                                'evolves 前，语序整体换了，拆开不通',
                 'S7 humpbacks on their seasonal migration along the coastline': '对齐不了：on their seasonal '
                                                                                 'migration along the '
                                                                                 'coastline 是后置定语，修饰 '
                                                                                 'humpbacks，中文“沿海岸线进行季节性迁徙的座头鲸”定语必须提前，along '
                                                                                 'the coastline 也要提到最前',
                 'S8 new song': '对齐不了：new song 中文“新歌”是一个词，拆开不通',
                 'S9 the old song': '对齐不了：old song 中文“旧歌”是一个词，拆开不通',
                 'S10 A study published in Nature in November 2000': '对齐不了：published in Nature in November '
                                                                     '2000 是后置定语，修饰 '
                                                                     'study，中文“2000年11月发表于《自然》的一项研究”定语必须提前',
                 'S10 the new song': '对齐不了：new song 中文“新歌”是一个词，the 化成“这首”',
                 'S10 resembled that of the Indian Ocean population off western Australia': '对齐不了：resemble sth '
                                                                                            '中文“与……相似”包住对象；that '
                                                                                            'of the Indian '
                                                                                            'Ocean population '
                                                                                            'off western '
                                                                                            'Australia 是 of '
                                                                                            '结构加后置定语，中文“澳大利亚西部海域印度洋种群的歌”语序必须倒过来',
                 'S10 ferried east by a handful of visiting performers': '对齐不了：by a handful of visiting '
                                                                         'performers '
                                                                         '是施动者，中文“由一小批来访的歌手向东带来的”必须放到动词前，east '
                                                                         '化成“向东”贴着动词',
                 'S12 over a decade of recordings from six South Pacific populations': '对齐不了：from six South '
                                                                                       'Pacific populations '
                                                                                       '是后置定语，over a decade of '
                                                                                       '是 of '
                                                                                       '结构，中文“南太平洋六个种群十余年的录音”语序必须倒过来',
                 'S13 then rippled eastward through successive populations': '对齐不了：through successive '
                                                                             'populations '
                                                                             '是方式状语（经由），中文“随后经由一个个相继的种群如涟漪般扩散，向东”必须放到动词前',
                 'S13 crossing the region within about two years': '对齐不了：within about two years '
                                                                   '是时间状语，中文“在大约两年内横跨该区域”时间必须放到动词前',
                 'S14 too fast for genetic evolution': '对齐不了：too fast for… 中文沿用文章定稿“快得远非基因演化所能及”，too…for '
                                                       '化成“远非……所能及”包住对象，拆开不通',
                 'S15 Why males sing': '对齐不了：主语从句 Why males sing 中文“雄鲸为何歌唱”，疑问词 why 必须放到主语后',
                 'S17 culture in the human sense': '对齐不了：in the human sense 是后置定语，修饰 '
                                                   'culture，中文“人类意义上的文化”定语必须提前',
                 "S18 population's music": "对齐不了：population's music 中文“种群的音乐”，所有格整体对应，拆开不通",
                 'S18 a few outsiders off eastern Australia': '对齐不了：用户 2026-11-07 '
                                                              '要求这两块合并为一组，中文“澳大利亚东部海域的一小批外来者”把地点放到前面作定语，语序整体换了，拆开不通',
                 'S3 Each rendition': '对齐不了：拆开会改换行，L13 未获同意（主会话 2026-11-07 定：K128 那句没说换行，不算换行同意；列给用户，用户同意再拆）',
                 'S3 probably for courtship': '对齐不了：拆开会改换行，L13 未获同意（主会话 2026-11-07 定：K128 '
                                              '那句没说换行，不算换行同意；列给用户，用户同意再拆）',
                 'S18 a few outsiders': '对齐不了：拆开会改换行，L13 未获同意（主会话 2026-11-07 定：K128 那句没说换行，不算换行同意；列给用户，用户同意再拆）',
                 'S13 to French Polynesia': '对齐不了：French Polynesia 是专名“法属波利尼西亚”，French 对“法属”嵌在专名里，拆开不通'},
          '对齐': {'S4-1 All the males in a population': 'in a population 是后置定语，中文定语必须提前',
                 'S7-2 humpbacks on their seasonal mi': 'on their seasonal migration along the coastline '
                                                        '是后置定语，中文定语必须提前',
                 'S8-1 merely two of 82 singers': 'two of 82 singers 是 of 结构，中文“82只歌者中仅有两只”语序必须倒过来',
                 'S8-2 utterly unlike the reigning ch': '用户 2026-11-07 给的译法“完全不像占据主导地位的合唱”，组内三处都是重点词，各自标',
                 'S10-1 A study published in Nature in': 'published in… 是后置定语，中文定语必须提前',
                 'S10-2 resembled that of the Indian O': 'resemble 中文“与……相似”包住对象，of 结构和后置定语语序必须倒过来',
                 'S10-3 ferried east by a handful of v': 'by… 是施动者，中文“由……向东带来的”必须放到动词前',
                 'S12-1 a study in Current Biology': 'in Current Biology 是后置定语，中文“《当代生物学》上的一项研究”定语必须提前',
                 'S12-2 over a decade of recordings fr': 'from… 是后置定语，of 结构，中文语序必须倒过来',
                 'S13-2 then rippled eastward through ': 'through successive populations 是方式状语，中文必须放到动词前',
                 'S13-3 crossing the region within abo': 'within about two years 是时间状语，中文必须放到动词前',
                 'S14-1 too fast for genetic evolution': 'too…for 中文“快得远非……所能及”包住对象，拆开不通',
                 'S14-3 a persuasive case of cultural ': 'a persuasive case of… 是 of '
                                                         '结构，中文“文化传递的一个有说服力的例证”语序必须倒过来',
                 'S15-1 and why they overhaul their so': 'and why they overhaul their songs 中文“又为何彻底改换歌曲”，why '
                                                         '放到动词前，they 承前省略',
                 'S17-1 culture in the human sense.': 'in the human sense 是后置定语，中文定语必须提前',
                 'S18-1 a few outsiders off eastern Au': '用户 2026-11-07 要求 a few outsiders 与 off eastern '
                                                         'Australia '
                                                         '两块合并为一组；中文“澳大利亚东部海域的一小批外来者”地点作定语提前，语序必须倒过来'},
          '短语': {'S3 recur … for': '不是搭配：for hours 是时间状语（数小时），recur 单独就是“反复出现”',
                 'S10 resembled … of': '不是搭配：of 属于 that of the Indian Ocean population（……种群的歌），和 resembled 无关',
                 'S12 analysed … from': '不是搭配：from 属于 recordings from six South Pacific populations，和 analysed '
                                        '无关',
                 'S12 analysed … of': '不是搭配：of 属于 a decade of recordings，和 analysed 无关',
                 'S13 rippled … through': '不是搭配：through 引出经过的种群（经由一个个相继的种群），rippled 单独就是“如涟漪般扩散”',
                 'S13 rippled … to': '不是搭配：to French Polynesia 是终点状语（传至法属波利尼西亚），rippled 单独就是“如涟漪般扩散”',
                 'S17 reluctant … to': '不是搭配：to 是不定式符号，引出 define 作 reluctant 的补足语，reluctant 单独就是“不愿”',
                 'S1 a haunting melody': '不是搭配：haunting 只是修饰 melody 的形容词，两个都是文章定稿的重点词，各自标（萦绕于心头的 / 旋律），中文已标全',
                 'S10 by … a': '不是搭配：by 引出施动者（由……），用户 2026-11-07 要求标的是 a handful of（已整体标）',
                 'S16 spurs change': '不是搭配：change 是 spurs 的宾语，用户 2026-11-07 只让标 spur（推动了），中文“推动了变化”已对应'},
          '词性': {'S1-2 breeding grounds 繁殖地': 'breeding grounds 是 n.，“繁殖地”的“地”是“地方”的地，不是副词标记'},
          '同词异译': {'utterly unlike：与/截然不同': '不是两种译法：utterly unlike 中文“与……截然不同”，意思被隔开两处，按 T23 标全',
                   'resembled：与/相似': '不是两种译法：resemble 中文“与……相似”，意思被隔开两处，按 T23 标全',
                   'off：在/海域': '不是两种译法：off 的意思“在……海域”被“澳大利亚东部”隔开，“在”和“海域”是同一个意思的两部分（T23，用户 2026-11-07 要求标）',
                   'off：海域/在': '同上，“在……海域”被隔开的两部分'},
          '中文重复': {'与': '“与”是“与……截然不同”“与……相似”两个框式结构的前半，各自连着后半一起看，学生分得清'},
          '即': {'S7-1 即': '沿用文章定稿中文“即水下麦克风”，同位语说明 hydrophones，用“即”简洁准确',
                'S14-3 即': '用户 2026-11-07 给的译法“即文化传递的一个有说服力的例证”，照用户原话'},
          '数字': {'S8-1 1990': 'mid-1990s 译作“20世纪90年代中期”，数值正确'},
          '非人声': {'16.15–16.23s': {'配音指纹': '98c6b392ade6',
                                   '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                         '增益改后同一段声音、时刻不变）：S2 w 5.60–5.69 hierarchy. 句末 /i/ 的衰减：-24 dB 起连续降到 '
                                         '-52 dB 进数字静音，低频占 -3～-12 dB、重心 0.4–1.9 kHz，中间无低谷，是元音收尾（词的一部分）',
                                   '实测': {'最响dB': -35.7, '重心Hz': 3528, '周期': 0.27, '低频dB': -3.2}},
                  '16.18–16.20s': {'配音指纹': '98c6b392ade6',
                                   '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                         '增益改后同一段声音、时刻不变）：S2 w 5.60–5.69 hierarchy. 句末 /i/ 的衰减：-24 dB 起连续降到 '
                                         '-52 dB 进数字静音，低频占 -3～-12 dB、重心 0.4–1.9 kHz，中间无低谷，是元音收尾（词的一部分）',
                                   '实测': {'最响dB': -41.3, '重心Hz': 3670, '周期': 0.0, '低频dB': -2.5}},
                  '19.37–19.39s': {'配音指纹': '98c6b392ade6',
                                   '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                         '增益改后同一段声音、时刻不变）：S3 w 1.98–2.01 逗号后 and 的浊音起音：-41～-48 dB、150 Hz 以下占 '
                                         '-1～-3 dB、重心 0.2–0.8 kHz，向后连续升到 æ（-18 dB），无静音隔开，是词头声带起振（词的一部分）',
                                   '实测': {'最响dB': -42.1, '重心Hz': 2396, '周期': 0.24, '低频dB': -0.4}},
                  '29.88–29.96s': {'配音指纹': '98c6b392ade6',
                                   '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                         '增益改后同一段声音、时刻不变）：S4 w 5.82–5.91 句末 year. 的 /ɹ/ 衰减：-20 dB 起连续降到 -50 dB '
                                         '进数字静音，低频占 -2～-17 dB、重心 0.5–1.2 kHz，无低谷，是词尾（词的一部分）',
                                   '实测': {'最响dB': -36.4, '重心Hz': 1548, '周期': 0.3, '低频dB': -7.3}},
                  '27.95–27.98s': {'配音指纹': '98c6b392ade6',
                                   '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                         '增益改后同一段声音、时刻不变）：S4 w 3.89–3.94 逗号后 which 的 /w/ 浊音起音：-46～-56 dB、低频占 '
                                         '0～-2 dB、重心 0.1–0.4 kHz，向后连续升进 /w/（-37→-12 dB），无静音隔开，是词头（词的一部分）',
                                   '实测': {'最响dB': -48.4, '重心Hz': 2334, '周期': 0.34, '低频dB': -0.4}},
                  '48.75–48.87s': {'配音指纹': '98c6b392ade6',
                                   '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                         '增益改后同一段声音、时刻不变）：S7 w 12.16–12.27 句末 coastline. 的 /n/ 衰减：-33 dB 起降到 '
                                         '-52 dB，低频占 -2～-9 dB、重心 0.1–0.8 kHz（鼻音），连续无低谷，是词尾（词的一部分）',
                                   '实测': {'最响dB': -35.4, '重心Hz': 2433, '周期': 0.24, '低频dB': -4.0}},
                  '39.95–39.97s': {'配音指纹': '98c6b392ade6',
                                   '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                         '增益改后同一段声音、时刻不变）：S7 w 3.38–3.40 逗号后 researchers 的 /ɹ/ 浊音起音：-48～-56 '
                                         'dB、低频占 0～-1 dB、重心 0.2 kHz，向后连续升进 /ɹ/（-36→-17 dB），是词头（词的一部分）',
                                   '实测': {'最响dB': -50.3, '重心Hz': 2372, '周期': 0.0, '低频dB': -0.2}},
                  '55.70–55.75s': {'配音指纹': '98c6b392ade6',
                                   '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                         '增益改后同一段声音、时刻不变）：S8 w 5.80–5.85 song, 的 /ŋ/ 衰减：-34～-46 dB、低频占 -1～-2 '
                                         'dB、重心 0.1–0.2 kHz、周期 0.63（嗓音），从元音连续衰减到 -57 dB，是鼻音词尾（词的一部分）',
                                   '实测': {'最响dB': -34.2, '重心Hz': 1255, '周期': 0.63, '低频dB': -0.4}},
                  '61.00–61.03s': {'配音指纹': '98c6b392ade6',
                                   '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                         '增益改后同一段声音、时刻不变）：S9 w 1.58–1.61 years, 后 virtually 的 /v/ 浊音起音：-49～-55 '
                                         'dB、低频占 0～-3 dB、重心 0.1–0.4 kHz，后面紧接升到 -21 dB 的词，是词头浊音（词的一部分）',
                                   '实测': {'最响dB': -48.7, '重心Hz': 2420, '周期': 0.46, '低频dB': -0.4}},
                  '82.09–82.23s': {'配音指纹': '98c6b392ade6',
                                   '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                         '增益改后同一段声音、时刻不变）：S10 w 13.615–13.73 performers 词中 m→ɚ 的弱浊音段：-32～-50 '
                                         'dB、低频占 -2～-13 dB、重心 0.2–0.9 kHz，后面直接进词尾 /z/（-20 dB、重心 4–5 '
                                         'kHz），在词内（词的一部分）',
                                   '实测': {'最响dB': -35.2, '重心Hz': 1831, '周期': 0.19, '低频dB': -3.1}},
                  '78.54–78.56s': {'配音指纹': '98c6b392ade6',
                                   '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                         '增益改后同一段声音、时刻不变）：S10 w 10.06–10.075 Australia, 后 apparently 的 ɐ '
                                         '浊音起音：-37～-50 dB、低频占 -1～-3 dB、重心 0.1–0.3 kHz，向后连续升到 -15 dB，是词头（词的一部分）',
                                   '实测': {'最响dB': -41.4, '重心Hz': 1530, '周期': 0.0, '低频dB': -0.2}},
                  '107.78–107.88s': {'配音指纹': '98c6b392ade6',
                                     '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                           '增益改后同一段声音、时刻不变）：S13 w 11.675–11.775 years. 词中 /ɹ/ 到 /z/ '
                                           '的过渡：-40～-55 dB、低频占 -2～-18 dB、重心 0.2–1.5 kHz，后面直接进 /z/（-24 dB、重心 '
                                           '4.6–4.9 kHz），在词内（词的一部分）',
                                     '实测': {'最响dB': -35.3, '重心Hz': 2284, '周期': 0.22, '低频dB': -6.3}},
                  '107.78–107.80s': {'配音指纹': '98c6b392ade6',
                                     '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                           '增益改后同一段声音、时刻不变）：S13 w 11.675–11.775 years. 词中 /ɹ/ 到 /z/ '
                                           '的过渡：-40～-55 dB、低频占 -2～-18 dB、重心 0.2–1.5 kHz，后面直接进 /z/（-24 dB、重心 '
                                           '4.6–4.9 kHz），在词内（词的一部分）',
                                     '实测': {'最响dB': -40.2, '重心Hz': 1376, '周期': 0.0, '低频dB': -1.3}},
                  '131.88–131.88s': {'配音指纹': '98c6b392ade6',
                                     '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                           '增益改后同一段声音、时刻不变）：S17 w 1.39 reluctant 词中 /k/ 的除阻（ʌ 1.337、k 1.386、t '
                                           '1.436）：10 ms、-44.7 dB、重心 2.0 kHz，在 /k/ 闭塞与 /t/ 之间，是塞音除阻（词的一部分）',
                                     '实测': {'最响dB': -44.7, '重心Hz': 2008, '周期': 0.0, '低频dB': -3.7}},
                  '141.17–141.19s': {'配音指纹': '98c6b392ade6',
                                     '依据': '2026-11-07 逐 2.5/5 ms 实测（57 出稿会话，w 与 a.wav 对照；S1 插入点、S5 '
                                           '增益改后同一段声音、时刻不变）：S18 w 5.035–5.06 reshaped 的 /ɹ/ 浊音起音（非人声区间 '
                                           '4.8077–5.03175 之后）：-46～-50 dB、低频占 0～-5 dB、重心 0.1–0.2 kHz，向后连续升进 '
                                           '/ɹ/（-33→-12 dB），是词头（词的一部分）',
                                     '实测': {'最响dB': -44.4, '重心Hz': 2203, '周期': 0.2, '低频dB': -0.3}}},
          '停顿位置': {'S1 whales, / and @2.239': '2026-11-07 逐 1.25/2.5 ms 实测（S1 w）：whales 的 /z/（-13～-20 dB、重心 '
                                              '4.4–4.8 kHz）到 2.2325，2.2325–2.241 是 /z/ 到 æ 的过渡低谷（-23～-29 '
                                              'dB、重心降到 0.3–0.9 kHz），2.2412 起 and 的 æ（-16 dB）；原插入点 2.235 还贴着 '
                                              '/z/ 尾，机器复听两路把 and 听成 than/then，插入点改到低谷里的过零点 '
                                              '2.239042（交界），停顿在两词之间'},
          '删除段': {'S2 raw 2.1650-2.5325': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '98c6b392ade6',
                                           '依据': '2026-11-07 逐 5/10 ms 实测（S# w，57 出稿会话）：phrases, 后：/z/ 尾之后 '
                                                 '2.15 起 -65 dB 渐升到 2.45 -46 dB 的吸气（重心 1.0–1.6 '
                                                 'kHz、无周期），2.465–2.51 低频杂声，2.5175 起 and 的 æ；非人声区间 '
                                                 '2.200167–2.512458 即此，紧贴 and '
                                                 '词头切在过零点，词本身不动（原始合成里的区间不变，删掉的是同一段声音；配音指纹 aef0bfe46750 → '
                                                 '98c6b392ade6，复核仍逐处重算两侧）'},
                  'S3 raw 1.7800-2.0020': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '98c6b392ade6',
                                           '依据': '2026-11-07 逐 5/10 ms 实测（S# w，57 出稿会话）：minutes, 后：/s/ 尾 1.73 '
                                                 '衰减到 -53 dB，1.76–1.975 平稳 -44～-53 dB 的吸气（重心 1.0–1.7 kHz、低频 '
                                                 '-9～-23 dB、无周期），与 and 前的低频起音之间没有 -55 dB 低谷，只能紧贴切（自动切点 '
                                                 '1.76–1.982 紧贴词头），复核报的“词头被切 45 ms”是这段吸气；1.98 起的低频起音和 2.02 起的 '
                                                 'æ 保留（原始合成里的区间不变，删掉的是同一段声音；配音指纹 aef0bfe46750 → '
                                                 '98c6b392ade6，复核仍逐处重算两侧）'},
                  'S3 raw 4.0153-4.2850': {'类型': '紧贴词尾的非人声',
                                           '配音指纹': '98c6b392ade6',
                                           '依据': '2026-11-07 逐 5/10 ms 实测（S# w，57 出稿会话）：hours, 后：/z/ 尾 3.99 '
                                                 '衰减到 -49 dB，3.995–4.11 平稳 -46～-52 dB 的气声（重心 1.0–1.4 '
                                                 'kHz、无周期），4.11 起 -55～-60 dB；非人声区间 3.99525–4.125 '
                                                 '紧贴词尾切在过零点（原始合成里的区间不变，删掉的是同一段声音；配音指纹 aef0bfe46750 → '
                                                 '98c6b392ade6，复核仍逐处重算两侧）'},
                  'S7 raw 5.8600-6.1100': {'类型': '紧贴词尾的非人声',
                                           '配音指纹': '98c6b392ade6',
                                           '依据': '2026-11-07 逐 5/10 ms 实测（S# w，57 出稿会话）：or 与 underwater '
                                                 '之间（无标点）：or 的 /ɹ/ 浊音（低频 -1～-3 dB、重心 0.1–0.5 kHz）到 '
                                                 '5.84，5.845–5.97 平稳 -37～-42 dB、低频 -11～-27 dB、重心 1.1–1.9 '
                                                 'kHz、无周期的气声（不是 /ɹ/），5.975–6.015 低频杂声，6.095 起 underwater；非人声区间 '
                                                 '5.840042–6.020792 紧贴词尾，复核报的“词尾被切 135 '
                                                 'ms”就是这段气声（原始合成里的区间不变，删掉的是同一段声音；配音指纹 aef0bfe46750 → '
                                                 '98c6b392ade6，复核仍逐处重算两侧）'},
                  'S9 raw 1.3700-1.5850': {'类型': '紧贴词尾的非人声',
                                           '配音指纹': '98c6b392ade6',
                                           '依据': '2026-11-07 逐 5/10 ms 实测（S# w，57 出稿会话）：years, 后：/z/ 尾到 1.35 '
                                                 '衰减到 -55 dB（低谷），1.36–1.56 平稳 -40～-47 dB 的吸气（重心 1.3–1.7 kHz、低频 '
                                                 '-11～-20 dB），1.57 -55 dB，1.58 起 virtually 的低频起音；自动切点 '
                                                 '1.36–1.57，复核报的“词尾被切 5 ms”在 /z/ '
                                                 '之后的低谷里（原始合成里的区间不变，删掉的是同一段声音；配音指纹 aef0bfe46750 → '
                                                 '98c6b392ade6，复核仍逐处重算两侧）'},
                  'S10 raw 9.5150-9.9433': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '98c6b392ade6',
                                            '依据': '2026-11-07 逐 5/10 ms 实测（S# w，57 出稿会话）：Australia, '
                                                  '后：9.66–9.88 从 -60 dB 渐升到 -42 dB 的吸气（重心 1.0–1.6 kHz、低频 '
                                                  '-14～-27 dB），9.89–9.94 低频起音，9.95 起 apparently；自动切点 '
                                                  '9.725–9.943417 紧贴词头（原始合成里的区间不变，删掉的是同一段声音；配音指纹 aef0bfe46750 '
                                                  '→ 98c6b392ade6，复核仍逐处重算两侧）'},
                  'S12 raw 4.1510-4.3750': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '98c6b392ade6',
                                            '依据': '2026-11-07 逐 5/10 ms 实测（S# w，57 出稿会话）：Biology 后：/i/ 衰减到 '
                                                  '4.135 -42 dB、4.14 -51 dB，4.145–4.27 平稳 -42～-46 dB 的气声（重心 '
                                                  '1.5–2.0 kHz、低频 -10～-21 dB），4.27–4.31 低频杂声，4.315 起 -57 dB '
                                                  '以下；非人声区间 4.140917–4.315 紧贴词尾切在过零点（原始合成里的区间不变，删掉的是同一段声音；配音指纹 '
                                                  'aef0bfe46750 → 98c6b392ade6，复核仍逐处重算两侧）'},
                  'S13 raw 8.4350-8.8537': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '98c6b392ade6',
                                            '依据': '2026-11-07 逐 5/10 ms 实测（S# w，57 出稿会话）：Polynesia, '
                                                  '后：8.50–8.56 -55～-57 dB 底噪，8.57–8.76 渐升到 -45 dB 再回落的吸气（重心 '
                                                  '1.0–1.9 kHz、低频 -8～-23 dB），8.78–8.83 低频起音，8.84 起 '
                                                  'generally；自动切点 8.57–8.83375 紧贴词头（原始合成里的区间不变，删掉的是同一段声音；配音指纹 '
                                                  'aef0bfe46750 → 98c6b392ade6，复核仍逐处重算两侧）'},
                  'S14 raw 3.8250-4.2100': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '98c6b392ade6',
                                            '依据': '2026-11-07 逐 5/10 ms 实测（S# w，57 出稿会话）：evolution, 后：n 尾 3.79 '
                                                  '衰减到 -55 dB，3.82–4.08 渐升到 -42 dB 的吸气（重心 0.8–1.4 kHz、低频 '
                                                  '-12～-24 dB），4.09–4.14 低频杂声，4.15–4.19 -62～-66 dB，4.20 起 '
                                                  'points 的 /p/；自动切点 3.815–4.181208（原始合成里的区间不变，删掉的是同一段声音；配音指纹 '
                                                  'aef0bfe46750 → 98c6b392ade6，复核仍逐处重算两侧）'},
                  'S15 raw 3.1100-3.2499': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '98c6b392ade6',
                                            '依据': '2026-11-07 逐 5/10 ms 实测（S# w，57 出稿会话）：songs, 后：/z/ 尾到 '
                                                  '3.095（-42 dB、重心 3.0 kHz），3.10 -51 dB，3.105–3.18 平稳 -41～-50 '
                                                  'dB 的气声（重心 1.3–2.0 kHz、低频 -9～-23 dB、无周期），3.19 起 -55～-63 '
                                                  'dB，3.245 起 remain；非人声区间 3.1–3.195 '
                                                  '紧贴词尾（原始合成里的区间不变，删掉的是同一段声音；配音指纹 aef0bfe46750 → '
                                                  '98c6b392ade6，复核仍逐处重算两侧）'},
                  'S18 raw 4.8177-5.0417': {'类型': '紧贴两头的非人声',
                                            '配音指纹': '98c6b392ade6',
                                            '依据': '2026-11-07 逐 5/10 ms 实测（S# w，57 出稿会话）：Australia 与 reshaped '
                                                  '之间（无标点）：Australia 的 ə 衰减到 4.80 -48 dB，4.82–4.99 平稳 -41～-45 '
                                                  'dB 的吸气（重心 1.2–1.7 kHz、低频 -12～-22 dB），5.01–5.06 低频起音，5.065 起 '
                                                  'reshaped 的 /ɹ/；自动切点 4.807708–5.03175 '
                                                  '紧贴两头（原始合成里的区间不变，删掉的是同一段声音；配音指纹 aef0bfe46750 → '
                                                  '98c6b392ade6，复核仍逐处重算两侧）'}},
          '机器复听': {'S1': {'配音指纹': '98c6b392ade6',
                          '依据': '2026-11-07 逐 1.25/2.5 ms 实测（S1 w，配音指纹 aef0bfe46750；S7 加分段增益后 S1 声音逐样本不变，换新指纹 '
                                '98c6b392ade6）：whales 的 /z/（-13～-20 dB、重心 4.4–4.8 kHz）到 2.2325，过渡低谷 '
                                '2.2325–2.241 归前词（停顿插入点 2.239042 在低谷里）；停顿后 and 从 2.2412 直接以元音起音（-16 dB、重心 0.3 '
                                'kHz、低频 -2 dB），前面没有 /ð/ 应有的 2–5 kHz 擦音，后接 n、d；parakeet 听成 and，small.en 听成 '
                                'then（停顿后弱读 and 的识别混淆）。原插入点 2.235 时两路都错，改后只剩 small.en 一路'}},
          '口述': {'S5-1 觉得': '用户 2026-11-07 给的小字原文“其他鲸鱼觉得：‘哎？这个改版挺帅啊！’”，照用户原话抄，不是口述多出来的词'},
          '响度骤降': {'57.7–58.3s': {'配音指纹': '98c6b392ade6',
                                  '低': 6.1,
                                  '句子': 'S8 In the mid-1990s, merely two of 82 singers emitted a distinctive '
                                        'new song, utterly unlike the reigning chorus.',
                                  '依据': '2026-11-07 逐 25 ms 实测（w，配音指纹 aef0bfe46750）：S8 句末 chorus.：/k/ 7.875 '
                                        '除阻，ɔː -11～-17 dB，ɹ-ə 衰减到 -35 dB，/s/ 8.25–8.375（-17～-22 dB、重心 4–5 '
                                        'kHz）完整，随后自然收尾进句末静音；骤降是句末收尾，不闷、不断（a_old.wav → 新配音：这一段声音逐样本相同，位置挪了 '
                                        '+0.000 秒；确认平移.py 自动挪，配音指纹 aef0bfe46750 → 98c6b392ade6）'},
                   '43.7–44.2s': {'配音指纹': '98c6b392ade6',
                                  '低': 6.4,
                                  '句子': 'S7 From 1995 to 1998, researchers used hydrophones, or underwater '
                                        'microphones, to record humpbacks on their seasonal migration along '
                                        'the coastline.',
                                  '依据': '2026-11-07 逐 25 ms 实测（w）：S7 microphones, 后半 m-aɪ -10～-12 dB，/k/ '
                                        '除阻，/f/ 重心 7–9 kHz，/oʊ/ 衰减、鼻音 /n/ 本来就弱，句中逗号前 /z/（-17～-22 dB、重心 5 '
                                        'kHz）清楚；原比全片低 7.7 dB（超过可确认上限 7.1），第3段加分段增益 1.5 dB 后为 6.4 dB；是 /oʊn/ '
                                        '自然收尾加逗号停顿，不闷、不断'}}},
 '结尾解说': '简述',
 '高亮按实际开口': True,
 '高亮开口门槛': 40,
 '术语': {'humpback whales': '座头鲸',
        'Australia': '澳大利亚',
        'Nature': '《自然》',
        'Indian Ocean': '印度洋',
        'Current Biology': '《当代生物学》',
        'South Pacific': '南太平洋',
        'French Polynesia': '法属波利尼西亚'},
 '结尾句': {'S18': {'前段语速': 0.9,
                 '最后一段语速': 0.78,
                 '最后一段前停顿': 0.7,
                 '接点': [34260, 44580],
                 '依据': '全篇结尾句按 07 定下的标准（用户 2026-10-10 同意并要求所有视频统一）：前段 0.9、最后一段“a few outsiders off eastern '
                       "Australia reshaped an entire population's music.” 0.78、前面停 0.7 秒。接点由 结尾句接点.py 自动找：0.9 "
                       '那遍最后一个标点后最长静音（45 ms）的正中 1.427 s，0.78 那遍（70 ms）的正中 1.857 s，所在帧和两侧各 5 ms 都低于 -55 dB（程序以 '
                       '08 校准：与人工核实的接点落在同一段静音里）'}},
 '非人声区间': {'S3': [[1.76, 1.982, '紧贴词头'], [3.99525, 4.125, '紧贴词尾']],
           'S9': [[1.36, 1.57], [4.165, 4.323083, '紧贴词头']],
           'S10': [[3.360042, 3.63], [9.725, 9.943417, '紧贴词头']],
           'S13': [[8.57, 8.83375, '紧贴词头']],
           'S14': [[3.815, 4.181208, '紧贴词头']],
           'S18': [[4.807708, 5.03175, '紧贴两头']],
           'S2': [[2.200167, 2.512458, '紧贴词头']],
           'S7': [[5.840042, 6.020792, '紧贴词尾']],
           'S12': [[4.140917, 4.315, '紧贴词尾']],
           'S15': [[3.1, 3.195, '紧贴词尾']]},
 '除阻加强': {'S18': {'句末': [8.38, 8.45, 4.0]}},
 '词尾除阻': {'S7': {'1': [2.95, 't']}, 'S11': {'句末': [1.29, 'k']}},
 '区间声音指纹': {'S1': '919068be1596',
            'S2': '74f8fd5c7746',
            'S3': '7f7f13dcd752',
            'S7': '86d990abebbe',
            'S9': 'd0ca4605fcbb',
            'S10': '50eb5abe4f34',
            'S11': 'c92f98d1725e',
            'S12': '1980c334ea2b',
            'S13': '5c2cdda82552',
            'S14': '5d3d6fe74b5a',
            'S15': '482312c9f742',
            'S18': '0c6b826ba7c4'},
 '停顿插入点': {'S1': {'2': [2.239042, '交界']}},
 '句子增益dB': {'S5': -1.0},
 '说明放宽特批': {'S5': {'倍数': '屏宽',
                   '依据': '用户 2026-11-07 特批：问“S5 小字放不下，怎么处理？”时用户选“S5 小字放宽到全屏宽”（只对 S5 这段小字，不受“不比英文宽”限制，按屏宽折行）'},
            'S11': {'倍数': '屏宽',
                    '依据': '用户 2026-11-07 特批：问“S11 详细语法小字太宽，怎么处理？”时用户选“S11 也放宽到全屏宽”（只对 S11 这段小字，按屏宽折行）'}},
 'allow_clash': ['spurs'],
 '分段增益dB': {'S7': {'3': 1.5}},
 '换行变更记录': [{'日期': '2026-11-07',
             'S18': '用户 2026-11-07（看 S18 a few outsiders / off eastern Australia '
                    '两块截图）：“两块合并为一行，这两块合并为一行。并且把意思改为下面的意思”',
             'S13': '用户 2026-11-07：问“S13 按你的译法重新分组后，英文换行和上次发给你的版本不一样了。同意 S13 改换行吗？”时用户选“同意 S13 改换行”'}]}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
