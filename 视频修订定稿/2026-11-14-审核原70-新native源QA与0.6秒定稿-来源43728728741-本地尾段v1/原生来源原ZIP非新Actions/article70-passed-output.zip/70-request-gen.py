#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('Before 1840,', '1840年以前，'),
     ('British', '英国的'),
     ('**postage**', '**邮费**(postage)'),
     ('was **levied** according to the number of **sheets** in a letter and the **mileage** of its '
      '**carriage**.',
      '是根据一封信件中的**纸张**(sheets)数量及其**运输**(carriage)的**里程**(mileage)来**征收**(levied)的。')],
    '（according to A and B：按 A 和 B；its 指 letter）']]),
 (1,
  [[[('The sum', '这笔钱'),
     ('was usually', '通常是'),
     ('**payable** on **delivery**,', '在**投递**(delivery)时**应支付的**(payable)，')]],
   [[('so', '所以，'),
     ('the person receiving the **correspondence**,', '收到**信件**(correspondence)的人，'),
     ('not the **sender**,', '而非**寄信人**(sender)，'),
     ('settled it.', '结清邮费。')],
    '（receiving the correspondence：现在分词短语作后置定语，\n修饰 person；\nit 指 the sum）']]),
 (1,
  [[[('Prices', '价格'),
     ('thus', '此种方式'),
     ('**fluctuated**', '**波动**(fluctuated)，'),
     ('from one', '从一件'),
     ('**postal**', '**邮政**(postal)'),
     ('**item**', '**物品**(item)'),
     ('to the next.', '到下一件。')],
    '（from one … to the next：从一件到下一件）\n（item：指一件具体的物品\n（在此处指“一件邮件/包裹”））']]),
 (2,
  [[[('In 1837', '1837年，'),
     ('Rowland Hill', '罗兰·希尔'),
     ('published', '出版了'),
     ('a **booklet**', '一本**小册子**(booklet)，'),
     ('urging', '呼吁'),
     ('reform.', '改革。')],
    '（urging reform：现在分词短语，补充说明 booklet）']]),
 (2,
  [[[('Parliament', '议会'),
     ('**enacted**', '于1839年**立法通过了**(enacted)'),
     ("the **campaigner**'s", '这位**改革倡导者**(campaigner)的'),
     ('**proposal** in 1839,', '**提议**(proposal)，')],
    '（campaigner 指 Rowland Hill）'],
   [[('and', '并且'),
     ('on 10 January 1840', '在1840年1月10日，'),
     ('the Uniform Penny Post', '“统一便士邮资”'),
     ('began.', '开始实行。')]]]),
 (2,
  [[[('A letter of up to half an **ounce**', '一封重量不超过半**盎司**(ounce)的信，'),
     ('now cost one **penny** to any **destination** in Britain,',
      '现在寄往英国境内任何**目的地**(destination)都只花费一**便士**(penny)，')],
    '（of up to half an ounce：介词短语作后置定语，修饰 letter）'],
   [[('and the fee', '并且费用'), ('was **prepaid** by whoever sent it.', '由寄信的人**预付**(prepaid)。')],
    '（whoever sent it：名词性从句作 by 的宾语；it 指 letter）']]),
 (2,
  [[[('One', '一种'),
     ('**flat-rate charge**', '**统一收费**(flat-rate charge)'),
     ('replaced **variation** with **simplicity**.', '以**简便**(simplicity)取代了**差异**(variation)。')],
    '（replace A with B：以 B 取代 A）']]),
 (3,
  [[[('The Penny Black,', '黑便士，'), ('a one-penny **denomination**,', '一枚**面值**(denomination)一便士的邮票，')],
    '（a one-penny denomination：同位语，补充说明 Penny Black）'],
   [[('was released', '发行'), ('on 1 May 1840,', '于1840年5月1日，')]],
   [[('its **validity**', '它的**有效性**(validity)'), ('starting on 6 May.', '从5月6日开始。')],
    '（validity：（票据、合同、证件等的）有效性、合法效力，\n在此处特指“正式生效、可被官方认可使用的状态”）']]),
 (3,
  [[[('**Engraved** on it was', '它的上面**雕刻**(engraved)着')],
    '（倒装句：Engraved on it 提前，\n主语是 a youthful likeness…；\nit 指 Penny Black）'],
   [[('a **youthful**', '维多利亚女王**年轻的**(youthful)'), ('**likeness** of Queen Victoria,', '**肖像**(likeness)，')]],
   [[('the **reigning**', '即这位**在位的**(reigning)'), ('**monarch**.', '**君主**(monarch)。')],
    '（the reigning monarch：同位语，补充说明 Queen Victoria）']]),
 (3,
  [[[('An **aggregate** of', '**总计**(aggregate)有'), ('68,808,000', '68,808,000枚'), ('were printed.', '被印制。')],
    '（aggregate：总数，合计，各项加起来的总量）']]),
 (3,
  [[[('The sheets', '这些整版邮票'), ('had no holes for **separation**,', '没有用于**分离**(separation)的孔，')]],
   [[('so', '所以'),
     ('each', '每枚'),
     ('stamp', '邮票'),
     ('was cut out **individually**', '都被**单独地**(individually)'),
     ('with **scissors**.', '用**剪刀**(scissors)剪下。')],
    '（was cut out：被动语态；cut out：剪下）\n（individually：单独地、逐个地（强调作为独立的个体，\n而不是作为一个整体一起处理））']]),
 (4,
  [[[('**Mailings**', '**邮寄量**(mailings)'), ('doubled,', '翻了一番，')]],
   [[('from about 80 million **items** in 1839', '从1839年的约8000万件邮寄**物品**(items)'),
     ('to over 169 million in 1840.', '增至1840年的超过1.69亿件。')],
    '（from A to B：从 A 增至 B）']]),
 (4, [[[('The design', '这一设计'), ('had a **drawback**.', '有个**缺点**(drawback)。')]]]),
 (4,
  [[[('Against black,', '在黑色底色上，'),
     ('the red', '红色'),
     ('**cancelling mark**', '**注销印记**(cancelling mark)'),
     ('was barely', '几乎不'),
     ('**noticeable**,', '**显眼**(noticeable)，'),
     ('lacking', '由于缺乏'),
     ('**contrast**,', '**反差**(contrast)，')],
    '（lacking contrast：现在分词短语，说明原因）'],
   [[('and the ink', '且墨水'), ('could be **erased**,', '能被**擦除**(erased)，')]],
   [[('leaving', '导致'),
     ('stamps', '邮票'),
     ('**vulnerable to**', '**容易被**(vulnerable to)'),
     ('**reuse**.', '**重复使用**(reuse)。')],
    '（be vulnerable to：指“易受……伤害/攻击/影响”，\n后面直接接造成威胁的名词（或 doing））']]),
 (4,
  [[[('In February 1841', '1841年2月，'), ('the Penny Red, cancelled in black ink,', '用黑色墨水盖销的“红便士”')],
    '（cancelled in black ink：过去分词短语，补充说明 Penny Red）'],
   [[('arrived', '问世，'),
     ('to **deter**', '旨在**防止**(deter)'),
     ('**tampering**', '**篡改**(tampering)'),
     ('and **fraud**.', '与**欺诈**(fraud)。')],
    '（to deter…：不定式作目的状语）\n（deter：通过增加难度或设置障碍，来“防止、阻止”某种不良行为发生）']]),
 (5,
  [[[('As the **initiator** of postage stamps,', '作为邮票的**首创者**(initiator)，'),
     ('Britain', '英国'),
     ('set', '开创了'),
     ('a **precedent**', '**先例**(precedent)，'),
     ('and earned', '并赢得'),
     ('an **exemption**.', '一项**豁免**(exemption)。')]]]),
 (5,
  [[[('Its stamps', '英国邮票'),
     ('are **nameless**,', '是**无名的**(nameless)，'),
     ('with no country **inscribed** on them.', '上面没有**刻印**(inscribed)国名。')],
    '（with no country inscribed on them：with 复合结构；\nIts 指 Britain）']]),
 (5,
  [[[('By', '根据'),
     ('international', '国际'),
     ('agreement,', '协议，'),
     ('\n', '\n'),
     ("the **sovereign**'s", '（英国的）**君主**(sovereign)'),
     ('head', '头像'),
     ('**suffices for**', '**足以用于**(suffices for)进行'),
     ('**identification**,', '**识别**(identification)，')]],
   [[('an **implicit**', '这是一种**隐含的**(implicit)'),
     ('**designation**', '**标识**(designation)，'),
     ('\n', '\n'),
     ('that other countries spell out in print.', '然而其他国家则需要把国名印在邮票上。')],
    '（英国邮票印个头像大家就知道是英国的，\n'
    '而其他国家必须把名字印出来才行。）\n'
    '（简述：▸旧制：英国邮费原按信纸数量和运输距离计算，通常由收信人付款，每封信的价格不一。\n'
    '▸改革：1840年1月起，希尔推动的改革让半盎司（约14克）以内的信在英国境内统一收一便士，由寄件人预付。\n'
    '▸邮票：同年5月，印有维多利亚女王头像、面值一便士的黑色邮票发行，\n'
    '▹称为“黑便士”；当年邮寄量由上年约8000万件增至1.69亿多件。\n'
    '▸改进：黑票上的红色邮戳不显眼，红墨又容易被洗掉，邮票可能被重复使用；1841年改发红便士并盖黑戳。\n'
    '▸特例：英国因首创邮票获国际特例，不必印国名，用君主头像就能识别国家；其他国家则要把国名印出。）']])]

out = {'no': '70',
 'title_en': 'The Stamp That Changed the Post',
 'title_zh': '一枚邮票改变通信',
 'title_fx': {'hl': ['Stamp', 'Post'], 'ghost': []},
 'sentences': [],
 '核对确认': {'合组': {'S2 the person receiving the correspondence, not the sender, settled it': '对齐不了：receiving the '
                                                                                           'correspondence '
                                                                                           '是后置定语修饰 '
                                                                                           'person，中文“收到信件的人”须提前；settled '
                                                                                           'it '
                                                                                           '用户译作“结清邮费”放在句末，整句沿用用户原话（待改清单第2条）',
                 'S3 fluctuated from one postal item to the next': '对齐不了：用户译文“波动，从一件邮政物品到下一件”（待改清单第3条），from '
                                                                   'one … to the next 是整体说法，拆开不通',
                 'S11 was cut out individually': '对齐不了：was cut out 被动，中文“都被……剪下”，cut out '
                                                 '的“剪下”在用户译文句末（用剪刀剪下），individually“单独地”夹在中间',
                 'S1 was levied according to the number of sheets in a letter': '对齐不了：同上，被动结构，方式状语“是根据……”提前、“征收”放到最后',
                 'S2 the person receiving the correspondence': '对齐不了：receiving the correspondence 是后置定语，修饰 '
                                                               'person，中文“收到信件的人”须提前',
                 'S1 was levied according to the number of sheets in a letter and the mileage of its carriage': '对齐不了：被动结构 '
                                                                                                                'was '
                                                                                                                'levied '
                                                                                                                'according '
                                                                                                                'to…，用户译文“是根据……来征收的”方式状语提前、“征收”放到最后；the '
                                                                                                                'mileage '
                                                                                                                'of '
                                                                                                                'its '
                                                                                                                'carriage '
                                                                                                                '中文“运输的里程”须倒过来',
                 'S6 now cost one penny to any destination in Britain': '对齐不了：地点状语 to any destination in '
                                                                        'Britain，中文“寄往英国境内任何目的地”须放到“只花费一便士”前',
                 'S6 was prepaid by whoever sent it': '对齐不了：被动结构，施事 whoever sent it 中文“由寄信的人”须放到动词“预付”前',
                 'S15 the Penny Red, cancelled in black ink': '对齐不了：cancelled in black ink 是后置定语，修饰 Penny '
                                                              'Red，中文“用黑色墨水盖销的”须提前',
                 'S16 As the initiator of postage stamps': '对齐不了：the initiator of postage stamps '
                                                           '中文“邮票的首创者”须倒过来，postage stamps 是一个名词“邮票”',
                 'S18 that other countries spell out in print': '对齐不了：定语从句 that other countries spell out in '
                                                                'print 修饰 '
                                                                'designation，用户译成独立分句“然而其他国家则需要把国名印在邮票上”（待改清单第14条），spell '
                                                                'out in print 中文补出“国名”并作“印在邮票上”，拆开不通'},
          '对齐': {'S12-2 from about 80 million items i': '时间状语 in 1839 修饰 items，中文“1839年的”须提前',
                 'S1-1 was levied according to the nu': '被动结构 was levied according '
                                                        'to…，用户译文“是根据……来征收的”方式状语提前、“征收”放到最后；the mileage of its '
                                                        'carriage 中文“运输的里程”须倒过来',
                 'S2-2 the person receiving the corre': 'receiving the correspondence 是后置定语，修饰 '
                                                        'person，中文“收到信件的人”须提前',
                 'S6-1 A letter of up to half an ounc': 'of up to half an ounce 是后置定语，修饰 '
                                                        'letter，中文“重量不超过半盎司的信”须提前',
                 'S6-1 now cost one penny to any dest': '地点状语 to any destination in '
                                                        'Britain，中文“寄往英国境内任何目的地”须放到“只花费一便士”前',
                 'S6-2 was prepaid by whoever sent it': '被动结构，施事 whoever sent it 中文“由寄信的人”须放到动词“预付”前',
                 'S11-1 had no holes for separation,': 'for separation 是后置定语，修饰 holes，中文“用于分离的孔”须提前',
                 'S12-2 from about 80 million items in': '时间状语 in 1839 修饰 items，中文“1839年的”须提前',
                 'S12-2 to over 169 million in 1840.': '时间状语 in 1840，中文“1840年的”须提前；over 169 million '
                                                       '中文“超过1.69亿件”',
                 'S15-1 the Penny Red, cancelled in bl': 'cancelled in black ink 是后置定语，修饰 Penny '
                                                         'Red，中文“用黑色墨水盖销的”须提前',
                 'S16-1 As the initiator of postage st': 'the initiator of postage stamps 是 of '
                                                         '结构，中文“邮票的首创者”须倒过来',
                 'S17-1 with no country inscribed on t': 'with 复合结构，地点 on them 中文“上面”须提前，inscribed 中文“刻印”在国名前',
                 'S18-2 that other countries spell out': '定语从句修饰 designation，用户译成独立分句“然而其他国家则需要把国名印在邮票上”，spell '
                                                         'out in print 中文补出“国名”，拆开不通'},
          '引号': {'S5-2 “”': '用户 2026-11-10 原话（70.docx '
                            '第4条）：“议会于1839年立法通过了这位改革倡导者的提议，并且在1840年1月10日”，后面“统一便士邮资”的引号是用户原话里加的',
                 'S15-1 “”': '用户 2026-11-10 原话（70.docx 第13条）：“1841年2月，用黑色墨水盖销的”，后面“红便士”的引号是用户原话里加的'},
          '即': {'S9-3 即': '用户 2026-11-10 原话（70.docx 第8条）：“the reigning monarch 即这位在位的君主。”“即”是用户原话'},
          '数字': {'S12-2 169': 'over 169 million 用户译作“超过1.69亿件”，1.69亿 = 169 million，数值一致；读法 one hundred and '
                              'sixty-nine million',
                 'S12-2 80': 'about 80 million 用户译作“约8000万件”，数值一致'},
          '牛津逗号': {'S15': '不是三项并列：the Penny Red, cancelled in black ink, arrived… '
                          '里两个逗号夹的是过去分词短语（插入语），tampering and fraud 只有两项',
                   'S16': '不是三项并列：As the initiator of postage stamps, 是状语，set a precedent and earned an '
                          'exemption 只有两项',
                   'S15 cancelled in black ink, arrived to deter tampering and': '不是三项并列：the Penny Red, '
                                                                                 'cancelled in black ink, '
                                                                                 'arrived… '
                                                                                 '里两个逗号夹的是过去分词短语（插入语），tampering '
                                                                                 'and fraud 只有两项',
                   'S16 initiator of postage stamps, Britain set a precedent and': '不是三项并列：As the initiator of '
                                                                                   'postage stamps, 是状语，set a '
                                                                                   'precedent and earned an '
                                                                                   'exemption 只有两项'},
          '是的': {'S17-1 是**无名的**': '沿用文章定稿“英国邮票是无名的”，are nameless 是系表结构，形容词 nameless 带“的”（T38），用户这次没改这句'},
          '词性': {'S6-1 destination 目的地': 'destination 是名词“目的地”，“地”是词的一部分，不是副词标记'},
          '中文重复': {'君主': '用户 2026-11-10 原话：monarch（70.docx 第8条“即这位在位的君主”）和 sovereign（第14条“(英国的) '
                         '君主头像”）都是用户原话定的“君主”，两处都照用'},
          '短语': {'S1 levied … of': '不是搭配：of 属于 the number of sheets（……的数量），levy 单独就是“征收”',
                 'S1 levied … to': '不是搭配：to 属于 according to（根据），levy 单独就是“征收”',
                 'S1 sheets … of': '不是搭配：of 属于 the mileage of its carriage，sheets 单独就是“纸张”',
                 'S2 payable … on': '不是搭配：on delivery 是时间状语（投递时），payable 单独是“应支付的”，用户原话第2条“在投递时应支付的”',
                 'S2 on … delivery': '不是搭配：on delivery 意为“投递时”，用户原话“在投递时”，delivery 单独就是“投递”，沿用文章定稿只标 delivery',
                 'S3 fluctuated … from': '不是搭配：from 属于 from one … to the next（从一件到下一件），fluctuate 单独就是“波动”',
                 'S3 fluctuated … to': '不是搭配：to 属于 from one … to the next，fluctuate 单独就是“波动”',
                 'S5 enacted … on': '不是搭配：on 属于 on 10 January 1840（时间状语），和 enacted 无关',
                 'S7 charge … with': '不是搭配：with 属于 replace A with B（以 B 取代 A），和 flat-rate charge 无关',
                 'S7 with … simplicity': '不是搭配：with 属于 replace A with B，simplicity 单独就是“简便”',
                 'S9 Engraved … of': '不是搭配：of 属于 a youthful likeness of Queen Victoria，engrave 单独就是“雕刻”',
                 'S9 Engraved … on': '不是搭配：on it 是地点（在它上面），engrave 单独就是“雕刻”，用户原话“它的上面雕刻着”',
                 'S9 likeness … of': '不是搭配：likeness of sb 是“某人的肖像”，of 只引出所属，用户原话“维多利亚女王年轻的肖像”',
                 'S11 with … scissors': '不是搭配：with 表工具（用剪刀），scissors 单独就是“剪刀”，用户原话“用剪刀剪下”',
                 'S2 payable on delivery': '不是搭配：本句 on delivery 作时间状语“在投递时”，delivery '
                                           '本身是重点词“投递”，用户原话“在投递时应支付的”逐词对应，payable 单独是“应支付的”',
                 'S14 erased … to': '不是搭配：to 属于 vulnerable to reuse，和 erased 无关',
                 'S16 initiator … of': '不是搭配：the initiator of sth 是“……的首创者”，of 只引出对象',
                 'S17 inscribed … on': '不是搭配：on them 是地点（在邮票上面），inscribe 单独就是“刻印”'},
          '停顿位置': {'S2 correspondence, / not @5.550': '2026-11-08 逐 2.5 ms 实测（S2 w）：correspondence 的 '
                                                      '/s/（-17～-22 dB、重心 5.5–6.2 kHz）到 5.385，5.395–5.545 是 /s/ '
                                                      '后的弱气声（-37～-48 dB、重心 2.0–2.9 kHz），5.545–5.550 低谷 -54 '
                                                      'dB，5.550 起 not 的 /n/ 浊音前导（低频 -0.1～-0.3 dB），5.60 起 /n/ '
                                                      '主体；插入点写在低谷过零点 5.55（交界），停顿在两词之间，离后词 +115 ms 是 /n/ '
                                                      '前导前的弱声，不是词'},
          '非人声': {'1.88–1.94s': {'配音指纹': '32091a72a354',
                                 '依据': '标题 w 1.485–1.550s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #1 孤立杂音）：标题 '
                                       'Post 句末 /t/ 除阻（/s/ 到 1.455，闭塞 1.465–1.485 降到 -60 dB，1.490 起 -30 dB、重心 '
                                       '2.3–2.9 kHz 的爆破，周期 ≤0.2）；词尾塞音除阻',
                                 '实测': {'最响dB': -30.7, '重心Hz': 2420, '周期': 0.11, '低频dB': -9.1}},
                  '4.62–4.64s': {'配音指纹': '32091a72a354',
                                 '依据': 'S1 w 1.615–1.630s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #2 噗声）：S1 '
                                       'British 词头 /b/ 浊音杠（重心 0.3–0.6 kHz、低频 -1～-3 dB、周期 0.2–0.5，1.67 起爆破接 '
                                       '/ɹ/）；词头的一部分',
                                 '实测': {'最响dB': -32.6, '重心Hz': 545, '周期': 0.0, '低频dB': -2.2}},
                  '11.62–11.63s': {'配音指纹': '32091a72a354',
                                   '依据': 'S2 w 0.020–0.035s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #3 噗声）：S2 '
                                         'The 词头 /ð/ 的浊音起音（周期 0.35–0.42、低频 -2 dB，0.055 起接元音）；词头的一部分',
                                   '实测': {'最响dB': -30.1, '重心Hz': 1478, '周期': 0.0, '低频dB': -2.7}},
                  '17.43–17.46s': {'配音指纹': '32091a72a354',
                                   '依据': 'S2 w 5.550–5.575s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #4 噗声）：S2 '
                                         'not 的 /n/ 浊音前导（低频 0～-1 dB、重心 1.2–2.0 kHz、周期 0.3–0.4，5.60 起 /n/ '
                                         '主体；前面的吸气已删）；词头的一部分',
                                   '实测': {'最响dB': -42.1, '重心Hz': 1584, '周期': 0.35, '低频dB': -0.3}},
                  '24.07–24.12s': {'配音指纹': '32091a72a354',
                                   '依据': 'S3 w 3.630–3.690s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #5 孤立杂音）：S3 '
                                         'next. 句末 /t/：词尾辅音核对.py 移植的合格除阻（重心 4.8 kHz、低频 -25 dB）；词尾塞音除阻',
                                   '实测': {'最响dB': -31.1, '重心Hz': 4839, '周期': 0.15, '低频dB': -25.4}},
                  '39.16–39.18s': {'配音指纹': '32091a72a354',
                                   '依据': 'S5 w 8.465–8.480s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #6 噗声）：S5 '
                                         'Uniform→Penny：Penny 的 /p/ 闭塞（-49～-62 dB，8.485 起 /p/ 爆破）；词头的一部分',
                                   '实测': {'最响dB': -52.2, '重心Hz': 2040, '周期': 0.0, '低频dB': -0.6}},
                  '40.38–40.49s': {'配音指纹': '32091a72a354',
                                   '依据': 'S5 w 9.685–9.795s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #7 呼吸声）：S5 '
                                         'began. 句末 /n/ 鼻音收尾（低频 -1～-12 dB、周期 0.1–0.44，衰减到 9.83 的 -75 dB）；词尾',
                                   '实测': {'最响dB': -35.0, '重心Hz': 1657, '周期': 0.21, '低频dB': -3.5}},
                  '42.27–42.28s': {'配音指纹': '32091a72a354',
                                   '依据': 'S6 w 0.775–0.790s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #8 孤立杂音）：S6 '
                                         'up 的 /p/ 除阻（-32 dB、重心 3.6–3.8 kHz、低频 -27 dB，无周期，0.825 起 to 的 '
                                         '/t/）；词尾塞音除阻',
                                   '实测': {'最响dB': -31.6, '重心Hz': 3334, '周期': 0.0, '低频dB': -16.9}},
                  '46.91–46.93s': {'配音指纹': '32091a72a354',
                                   '依据': 'S6 w 5.440–5.460s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #9 噗声）：S6 '
                                         'and 的 æ 浊音前导（周期 0.4、低频 0 dB，紧接起音；前面的吸气已删）；词头的一部分',
                                   '实测': {'最响dB': -47.5, '重心Hz': 2903, '周期': 0.44, '低频dB': -0.2}},
                  '53.38–53.47s': {'配音指纹': '32091a72a354',
                                   '依据': 'S7 w 2.800–2.880s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #10 呼吸声）：S7 '
                                         'variation 词尾 /n/ 的衰减（周期 0.3–0.6、低频 -2～-11 dB、重心 1.2–2.1 kHz），2.865 起 '
                                         'with 的 /w/；词尾的一部分',
                                   '实测': {'最响dB': -35.6, '重心Hz': 1689, '周期': 0.31, '低频dB': -5.4}},
                  '53.45–53.47s': {'配音指纹': '32091a72a354',
                                   '依据': 'S7 w 2.865–2.880s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #11 噗声）：S7 '
                                         'with 的 /w/ 浊音前导（重心 0.6–0.9 kHz、低频 -1～-3 dB、周期 0.2–0.5）；词头的一部分',
                                   '实测': {'最响dB': -35.6, '重心Hz': 928, '周期': 0.0, '低频dB': -2.5}},
                  '55.55–55.56s': {'配音指纹': '32091a72a354',
                                   '依据': 'S8 w 0.025–0.040s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #12 噗声）：S8 '
                                         'The 词头 /ð/ 的浊擦前导（低频 -2 dB，紧接 0.045 起音）；词头的一部分',
                                   '实测': {'最响dB': -36.3, '重心Hz': 3771, '周期': 0.0, '低频dB': -2.5}},
                  '79.64–79.66s': {'配音指纹': '32091a72a354',
                                   '依据': 'S11 w 2.795–2.810s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #13 '
                                         '噗声）：S11 so 词头 /s/ 前的弱声（-43～-59 dB、低频 0～-4 dB，2.815 起 /s/ 重心升到 4.6–6 '
                                         'kHz）；词头的一部分',
                                   '实测': {'最响dB': -42.9, '重心Hz': 2614, '周期': 0.0, '低频dB': -0.3}},
                  '82.75–82.84s': {'配音指纹': '32091a72a354',
                                   '依据': 'S11 w 5.900–5.990s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #14 '
                                         '呼吸声）：S11 scissors. 词内 ɚ→z 过渡（周期 0.1–0.4、低频 -1～-9 dB，5.97 起 /z/ 重心升到 '
                                         '4–5 kHz，词 5.488–6.155 内）；词的一部分',
                                   '实测': {'最响dB': -35.2, '重心Hz': 1808, '周期': 0.27, '低频dB': -3.2}},
                  '102.23–102.25s': {'配音指纹': '32091a72a354',
                                     '依据': 'S14 w 5.700–5.715s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #15 '
                                           '噗声）：S14 and 的 æ 浊音前导（低频 -1～-3 dB，前面的吸气已删，5.718 起音）；词头的一部分',
                                     '实测': {'最响dB': -47.8, '重心Hz': 2270, '周期': 0.0, '低频dB': -0.8}},
                  '114.88–114.95s': {'配音指纹': '32091a72a354',
                                     '依据': 'S15 w 7.300–7.380s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #16 '
                                           '呼吸声）：S15 fraud. 词尾 ɔː→d 浊音闭塞（周期 0.2–0.4、低频 -2～-12 dB，7.395 起 /d/ '
                                           '除阻，词 6.984–7.478 内）；词的一部分',
                                     '实测': {'最响dB': -35.3, '重心Hz': 2383, '周期': 0.23, '低频dB': -4.2}},
                  '121.51–121.59s': {'配音指纹': '32091a72a354',
                                     '依据': 'S16 w 5.250–5.330s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #17 '
                                           '呼吸声）：S16 exemption. 句末 /n/ 鼻音收尾（周期 0.2–0.45、低频 -1～-11 dB，衰减到 5.37 '
                                           '的 -100 dB 以下）；词尾',
                                     '实测': {'最响dB': -35.7, '重心Hz': 1446, '周期': 0.23, '低频dB': -2.5}},
                  '121.55–121.56s': {'配音指纹': '32091a72a354',
                                     '依据': 'S16 w 5.285–5.300s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #18 '
                                           '噗声）：S16 exemption. 句末 /n/ 鼻音收尾里的一下起伏（低频 -1～-5 dB，词 4.712–5.379 '
                                           '内）；词尾',
                                     '实测': {'最响dB': -37.6, '重心Hz': 1370, '周期': 0.0, '低频dB': -1.9}},
                  '124.40–124.42s': {'配音指纹': '32091a72a354',
                                     '依据': 'S17 w 1.690–1.710s：2026-11-10 逐 2.5 ms 实测（疑点清单 dossier_70 #19 '
                                           '噗声）：S17 with 的 /w/ 浊音前导（周期 0.3–0.5、低频 0～-1 dB，前面的吸气已删，1.72 '
                                           '起音）；词头的一部分',
                                     '实测': {'最响dB': -51.7, '重心Hz': 2743, '周期': 0.28, '低频dB': -0.2}}},
          '删除段': {'S1 raw 5.6702-6.0350': '2026-10-15 删除段对应 非人声区间 [[5.685, 6.015]]（w 秒）：自动切点.py '
                                          '用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < -10 dB、周期 < '
                                          "0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms 内最安静处的过零点；复核报 ['lost'] "
                                          '是删掉的呼吸声本身偏响（-34～-47 dB），不是词',
                  'S2 raw 5.4155-5.5655': {'类型': '紧贴两头的非人声',
                                           '配音指纹': '32091a72a354',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[5.395458, 5.545458, '紧贴两头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['lost', 'post', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 "
                                                 'dB），不是词'},
                  'S6 raw 5.0800-5.5016': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '32091a72a354',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[5.2, 5.441583, '紧贴词头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['post'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S8 raw 3.0612-3.3000': {'类型': '紧贴词尾的非人声',
                                           '配音指纹': '32091a72a354',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[3.05125, 3.29, '紧贴词尾']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['lost', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S12 raw 5.0415-5.2900': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '32091a72a354',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[5.021375, 5.255, '紧贴词尾']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S14 raw 5.5951-5.8712': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '32091a72a354',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[5.445, 5.70125, '紧贴词头']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost', 'post'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S15 raw 4.7350-5.0560': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '32091a72a354',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[4.78, 5.046, '紧贴词头']]（w 秒）：自动切点.py "
                                                  '用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < -10 dB、周期 < '
                                                  '0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms 内最安静处的过零点；复核报 '
                                                  "['lost'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S6 raw 3.9650-3.9749': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '32091a72a354',
                                           '依据': '2026-11-08 独立复核实测：any→destination 之间删掉的 9.9 ms 最响 -60.4 '
                                                 'dB（两侧 -63/-60 dB），是 destination 的 /d/ 闭塞里的静音，没有能听见的声音；复核报 '
                                                 'onset 5 ms 是这段闭塞静音，不是 /d/ 的除阻或元音'},
                  'S18 raw 5.0950-5.5600': '2026-11-08 逐 10 ms 实测 S18 w：identification, 的 /n/ 到 5.07（5.08–5.27 '
                                           '降到 -62～-66 dB），5.28–5.52 是 an 开口前的吸气（-41～-57 dB、重心 2.2–2.9 kHz、低频 '
                                           '-4～-16 dB），5.54 回到 -59 dB，5.555 起 an 的 æ；删除段 w 5.09–5.545 两头 '
                                           '-61/-60 dB，删掉的最响 -40 dB 是这段吸气，不是词'}},
 '结尾解说': '简述',
 '高亮按实际开口': True,
 'allow_clash': ['deter', 'reigning'],
 '高亮开口门槛': 40,
 '术语': {'Rowland Hill': '罗兰·希尔',
        'Parliament': '议会',
        'Uniform Penny Post': '统一便士邮资',
        'Britain': '英国',
        'British': '英国的',
        'Penny Black': '黑便士',
        'Queen Victoria': '维多利亚女王',
        'Penny Red': '红便士'},
 '停顿删除区间': {'S2': {'2': [5.4005, 5.5405]}},
 '非人声区间': {'S1': [[5.685, 6.015]],
           'S2': [[2.86, 3.03], [5.395458, 5.545458, '紧贴两头']],
           'S4': [[1.525, 1.755]],
           'S5': [[4.67, 4.81], [7.4, 7.65]],
           'S8': [[3.05125, 3.29, '紧贴词尾']],
           'S12': [[5.021375, 5.255, '紧贴词尾']],
           'S14': [[3.74, 4.05], [5.445, 5.70125, '紧贴词头']],
           'S15': [[4.78, 5.046, '紧贴词头']],
           'S6': [[5.2, 5.441583, '紧贴词头']]},
 '结尾句': {'S18': {'前段语速': 0.9,
                 '最后一段语速': 0.78,
                 '最后一段前停顿': 0.7,
                 '接点': [133380, 171780],
                 '依据': '全篇结尾句按 07 定下的标准（用户 2026-10-10 同意并要求所有视频统一）：前段 0.9、最后一段“an implicit designation that '
                       'other countries spell out in print.” 0.78、前面停 0.7 秒。接点由 结尾句接点.py 自动找：0.9 '
                       '那遍最后一个标点后最长静音（20 ms）的正中 5.558 s，0.78 那遍（20 ms）的正中 7.157 s，所在帧和两侧各 5 ms 都低于 -55 dB（程序以 '
                       '08 校准：与人工核实的接点落在同一段静音里）'}},
 '词尾除阻': {'S2': {'句末': [7.23, 't']},
          'S3': {'句末': [3.625, 't']},
          'S18': {'1': [1.665, 't']},
          'S6': {'句末': [8.060667, 't']}},
 '停顿处除阻': {'S14': {'1': [0.93, 0.935, 'k']}},
 '区间声音指纹': {'S1': '6666da07e195',
            'S2': 'e30b33421c85',
            'S3': 'b58e81b30a0d',
            'S4': '8b8d106021fc',
            'S5': 'b03db43a0c92',
            'S6': 'c80c9c53f48a',
            'S8': '2d9d9a9cff8c',
            'S12': '063b32e5146a',
            'S14': '63cff29fdb3e',
            'S15': '0563260166a6',
            'S18': '873ae1dc40f6'},
 '换行变更记录': [{'日期': '2026-11-10',
             'S2': '用户 2026-11-10 原话：“按照这个word文档里面的这个修改建议帮我修改这个视频，然后 4k 定稿，定稿，定稿。”（70.docx 第2条改译文，换行随之变）',
             'S5': '用户 2026-11-10 原话：“按照这个word文档里面的这个修改建议帮我修改这个视频，然后 4k 定稿，定稿，定稿。”（70.docx 第4条改译文，换行随之变）',
             'S3': '用户 2026-11-10 原话：“按照这个word文档里面的这个修改建议帮我修改这个视频，然后 4k 定稿，定稿，定稿。”（70.docx 第3条加 item '
                   '小字、改译文，换行随之变）',
             'S18': '用户 2026-11-10 原话：“按照这个word文档里面的这个修改建议帮我修改这个视频，然后 4k 定稿，定稿，定稿。”（70.docx '
                    '第14、15条改译文、换小字、改简述，换行随之变）',
             'S9': '用户 2026-11-10 原话（70.docx，看 S9 截图）：“下面这一部分他自己要占据一行，上面的就是你看着办。the reigning monarch '
                   '即这位在位的君主。”（用户原话：“下面这一部分他自己要占据一行，上面的就是你看着办。”）'},
            {'日期': '2026-11-14',
             'S2': '用户 2026-11-10 原话：“按照这个word文档里面的这个修改建议帮我修改这个视频，然后 4k 定稿，定稿，定稿。”（70.docx 第2条改译文，换行随之变）',
             'S5': '用户 2026-11-10 原话：“按照这个word文档里面的这个修改建议帮我修改这个视频，然后 4k 定稿，定稿，定稿。”（70.docx 第4条改译文，换行随之变）',
             'S3': '用户 2026-11-10 原话：“按照这个word文档里面的这个修改建议帮我修改这个视频，然后 4k 定稿，定稿，定稿。”（70.docx 第3条加 item '
                   '小字、改译文，换行随之变）',
             'S18': '用户 2026-11-10 原话：“按照这个word文档里面的这个修改建议帮我修改这个视频，然后 4k 定稿，定稿，定稿。”（70.docx '
                    '第14、15条改译文、换小字、改简述，换行随之变）',
             'S9': '用户 2026-11-10 原话（70.docx，看 S9 截图）：“下面这一部分他自己要占据一行，上面的就是你看着办。the reigning monarch '
                   '即这位在位的君主。”（用户原话：“下面这一部分他自己要占据一行，上面的就是你看着办。”）'}],
 '分段增益dB': {'S14': {'1': -3.0}},
 '换行变更已获同意': {'S18': '用户原话：“第50篇这个地方需要排版一下，第50篇这个地方需要排版一下。然后把这个 '
                     '然后把这个这这我办这个第50篇好像没有插图，没有插画。然后然然然后然后认认真真的去定稿，4k定稿，4k定稿。”'}}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
