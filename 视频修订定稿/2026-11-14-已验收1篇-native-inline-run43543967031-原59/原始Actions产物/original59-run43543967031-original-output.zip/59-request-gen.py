#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('A **layer**', '一**层**(layer)'),
     ('of **ozone**', '**臭氧**(ozone)'),
     ('**shields** Earth **from**', '**为**(shields from)地球**遮挡了**(shields from)'),
     ("much of the sun's", '太阳的大部分'),
     ('**ultraviolet**', '**紫外**(ultraviolet)'),
     ('**radiation**.', '**辐射**(radiation)。')],
    '（shield A from B：为 A 遮挡 B，\n保护 A 不受 B 的伤害）']]),
 (1,
  [[[('In June 1974', '1974年6月，'),
     ('Mario Molina and Sherwood Rowland,', '马里奥·莫利纳和舍伍德·罗兰，'),
     ('chemists', '两位化学家，'),
     ('in California,', '在加州工作，')],
    '（chemists in California：同位语，补充说明两人）'],
   [[('warned in Nature', '在《自然》杂志上撰文警告，'),
     ('of a **menace**', '有一种**威胁**(menace)'),
     ('in fridges', '藏在冰箱'),
     ('and **spray** cans.', '和**喷雾**(spray)罐里。')],
    '（warn of…：警告……；\nin fridges and spray cans：后置定语，修饰 menace）']]),
 (1,
  [[[('Chlorofluorocarbons (CFCs)', '氯氟烃（CFCs）'),
     ('are so **inert**', '如此**惰性**(inert)，'),
     ('that they', '以至于它们'),
     ('drift **intact**', '能**完好无损地**(intact)飘'),
     ('into the stratosphere,', '入到平流层中，')]],
   [[('high in the **atmosphere**,', '也就是高层**大气**(atmosphere)中，')]],
   [[('where they can', '在那里，它们可能'),
     ('**liberate**', '**释放**(liberate)出'),
     ('**chlorine**,', '**氯**(chlorine)，')]],
   [[('a **catalyst**', '氯是一种**催化剂**(catalyst)，'),
     ('that destroys ozone **molecule** after molecule.', '会把臭氧**分子**(molecule)一个接一个地破坏掉。')]]]),
 (1,
  [[[('The pair', '两人'),
     ('foresaw', '预料到的，是'),
     ('**gradual**', '一场**渐进式的**(gradual)'),
     ('**erosion**.', '**侵蚀**(erosion)。')]]]),
 (2,
  [[[('The **alarm**,', '**警报**(alarm)'),
     ('when it sounded,', '真的拉响时，'),
     ('was **abrupt**.', '却来得十分**突然**(abrupt)。')],
    '（when it sounded：插入的时间状语从句；\nsound：（警报）响起）']]),
 (2,
  [[[('In May 1985', '1985年5月，'),
     ('Joseph Farman', '约瑟夫·法曼'),
     ('and colleagues at the British **Antarctic** Survey', '和英国**南极**(Antarctic)调查局的同事'),
     ('reported that', '报告称，')],
    '（at the British Antarctic Survey：后置定语，修饰 colleagues）'],
   [[('**ozone** over Halley Bay,', '哈雷湾上空的**臭氧**(ozone)，'),
     ('their', '那是他们的'),
     ('Antarctic', '南极'),
     ('station,', '考察站，'),
     ('had **plummeted** each southern spring since the mid-1970s.',
      '自20世纪70年代中期起，每到南半球春季就**骤降**(plummeted)。')],
    '（their Antarctic station：同位语，补充说明 Halley Bay；\nhad plummeted：过去完成时，表示到报告时为止一直在骤降）']]),
 (2,
  [[[('Their', '他们那台'),
     ('**humble**', '**不起眼的**(humble)'),
     ('Dobson', '多布森'),
     ('spectrophotometer', '分光光度计，'),
     ('**gauged** ozone from the ground.', '从地面**测量**(gauged)臭氧。')],
    '（spectrophotometer：分光光度计，测量光谱的仪器）']]),
 (2,
  [[[('The staff', '工作人员'),
     ('were **persistent**,', '**持之以恒**(persistent)，'),
     ('reading it', '读数时遵循'),
     ('in a **painstaking**', '一套**一丝不苟的**(painstaking)'),
     ('**routine**', '**例行**(routine)规程，'),
     ('of **manual**', '全靠**人工**(manual)'),
     ('**observation**.', '**观测**(observation)。')],
    '（reading it…：现在分词短语作伴随状语，it 指分光光度计；\na routine of…：……的例行规程）']]),
 (3,
  [[[('Yet', '然而，'),
     ("NASA's", '美国国家航空航天局（NASA）的'),
     ('Nimbus-7', '雨云7号'),
     ('**satellite**,', '**卫星**(satellite)，')]],
   [[('a **sophisticated** eye', '这只**精密的**(sophisticated)眼睛'), ('**in orbit**,', '**在轨道上运行**(in orbit)，')],
    '（a sophisticated eye in orbit：同位语，\n补充说明卫星）'],
   [[('had recorded', '也记录到了'), ('the same', '同样的'), ('lows.', '低值。')], '（lows：名词复数，低值）']]),
 (3,
  [[[('Its software', '它的软件'),
     ('**flagged** them **as**', '**把**(flagged as)这些读数**标记为**(flagged as)'),
     ('**dubious**,', '**可疑**(dubious)，')],
    '（flag A as B：把 A 标记为 B）'],
   [[('since', '因为'),
     ('ozone that low', '这么低的臭氧'),
     ('had never been', '此前从没有'),
     ('reliably measured.', '被可靠地测到过。')],
    '（that low：that 作副词，这么低，\nozone that low 即这么低的臭氧）']]),
 (3,
  [[[('NASA says', '据NASA的说法，'),
     ('it was still', '它还在'),
     ('**verifying** them', '**核实**(verifying)这些读数，'),
     ('when Farman published.', '就在法曼发表论文的时候。')],
    '（NASA says…：注明是 NASA 一方的说法；\nwhen Farman published：时间状语从句）']]),
 (3,
  [[[('The **sensor**', '**传感器**(sensor)'),
     ('had worked;', '并没有出问题；'),
     ('**expectation**', '**预期**(expectation)'),
     ('had not.', '却出了问题。')],
    '（had not：省略了 worked，\n即 expectation had not worked）']]),
 (4,
  [[[('**Remarkably**,', '**引人注目的是**(Remarkably)，'),
     ('the response', '各国的反应'),
     ('was **swift**.', '十分**迅速**(swift)。')]]]),
 (4,
  [[[('In September 1987', '1987年9月，'),
     ('**diplomats**', '**外交官**(diplomats)们'),
     ('signed', '签署了'),
     ('the Montreal **Protocol**,', '《蒙特利尔**议定书**(Protocol)》，')]],
   [[('a **binding**', '这是一项具有**约束力的**(binding)'),
     ('**accord**', '**协定**(accord)，'),
     ('to **curb** CFCs.', '用来**限制**(curb)CFCs。')],
    '（a binding accord…：同位语，补充说明议定书；\nto curb CFCs：不定式作后置定语，修饰 accord）']]),
 (4,
  [[[('**Amendments**', '此后的**修正案**(Amendments)'), ('**tightened** it:', '又**收紧了**(tightened)它的管控：')]],
   [[('in June 1990', '1990年6月，'),
     ('**affluent**', '**富裕**(affluent)'),
     ('countries', '国家'),
     ('**pledged** to', '**承诺**(pledged)'),
     ('**phase out** CFCs by 2000.', '在2000年前**逐步淘汰**(phase out)CFCs。')],
    '（pledge to do：承诺做……；\nphase out：逐步淘汰）']]),
 (4,
  [[[('In September 2009', '2009年9月，'),
     ('the Protocol', '该议定书'),
     ('and its parent Vienna Convention', '与其所依据的《维也纳公约》一道，')],
    '（its parent Vienna Convention：\n议定书所依据的母公约《维也纳公约》）'],
   [[('became', '成为'),
     ("the UN's first **treaties** to win **universal** **ratification**.",
      '联合国首批获得**普遍**(universal)**批准**(ratification)的**条约**(treaties)。')],
    '（to win…：不定式作后置定语，修饰 treaties）']]),
 (5,
  [[[('In January 2023', '2023年1月，'),
     ('a UN-backed **assessment**', '一份由联合国支持的**评估**(assessment)报告'),
     ('**forecast**', '**预测**(forecast)，')],
    '（UN-backed：由联合国支持的；\nforecast：过去式与原形同形）'],
   [[('**recovery**', '臭氧层将**恢复**(recovery)'), ('to 1980 levels', '到1980年的水平：')],
    '（recovery to 1980 levels：恢复到1980年的水平）'],
   [[('around 2066', '约2066年'),
     ('over **Antarctica**,', '在**南极**(Antarctica)上空，'),
     ('2045', '2045年'),
     ('over the **Arctic**,', '在**北极**(Arctic)上空，'),
     ('and 2040', '其他地区'),
     ('elsewhere.', '则在2040年。')]]]),
 (5, [[[('**Healing**', '臭氧层的**愈合**(Healing)'), ('will take', '还需要'), ('decades.', '数十年。')]]]),
 (5,
  [[[("The sky's", '天空得以'),
     ('**rescue**', '**拯救**(rescue)，'),
     ('began with', '始于'),
     ('**diligent** observers', '一群**勤勉的**(diligent)观测者，')]],
   [[('who trusted that', '他们相信，'),
     ('a **baffling** number', '一个**令人费解的**(baffling)数字'),
     ('was no **glitch**,', '并不是**小故障**(glitch)，'),
     ('and published it.', '于是把它发表了出来。')],
    '（who…：定语从句，修饰 observers；\n'
    'was no glitch：并不是小故障；\n'
    'and published it：与 trusted 并列，it 指那个数字）\n'
    '（简述：▸预警：臭氧层能挡住大量紫外线。1974年，化学家警告：冰箱和喷罐中使用的氯氟烃会飘到高空，释放氯，持续破坏臭氧。▸发现：1985年，南极地面观测人员报告，哈雷湾臭氧自70年代中期起，每逢南半球春季便骤降。▸误判：卫星也测到同样低值，软件却因数值太罕见而标为可疑；NASA称当时尚在核实。仪器没有失灵，人的预期才出了错。▸合作：各国1987年签署《蒙特利尔议定书》，限制氯氟烃；1990年富国承诺2000年前淘汰，议定书2009年获普遍批准。▸恢复：2023年评估预测，臭氧恢复至1980年水平还需时间：其他地区约2040年、北极约2045年、南极约2066年。）']])]

out = {'no': '59',
 'title_en': 'Saving the Sky',
 'title_zh': '拯救天空',
 'title_fx': {'hl': ['Saving', 'Sky'], 'ghost': []},
 'sentences': [],
 '核对确认': {'非人声': {'4.84–4.87s': {'配音指纹': 'ae7bdd90e6e1',
                                 '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S1 w '
                                       '2.415–2.44：Earth 的 /θ/ 收尾（-49～-53 dB）到 from 的 /f/，2.435 起重心升到 5–6.8 '
                                       'kHz 是 /f/ 擦音，中间没有低谷，是两词交界的擦音过渡（词的一部分）',
                                 '实测': {'最响dB': -48.6, '重心Hz': 2893, '周期': 0.31, '低频dB': -0.3}},
                  '10.74–10.83s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S2 w '
                                         '2.075–2.16（1974 与 Mario 之间的吸气已切掉 1.934–2.075）：-39～-52 dB、低频占 '
                                         '-0.5～-1.4 dB、周期 0.37–0.56 的浊音，2.16 起 /m/（-21→-9 dB），连续无低谷，是 Mario 的 '
                                         '/m/ 浊音预发声（词的一部分）',
                                   '实测': {'最响dB': -40.9, '重心Hz': 1829, '周期': 0.25, '低频dB': -0.3}},
                  '10.76–10.81s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S2 w '
                                         '2.085–2.14：同上一条，低频占 -0.5～-2.5 dB、周期 0.37–0.56，是 Mario 的 /m/ '
                                         '浊音预发声（词的一部分）',
                                   '实测': {'最响dB': -40.9, '重心Hz': 1647, '周期': 0.4, '低频dB': -0.2}},
                  '13.13–13.21s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S2 w '
                                         '4.46–4.545：Rowland 的 /n/ 收尾（-33～-46 dB、低频占 -2～-6 dB、周期 0.2–0.47、重心 '
                                         '1.2–1.8 kHz），4.55 一下 -52 dB 闭塞，4.56 /d/ 除阻（-24.8 dB），是 Rowland 的一部分',
                                   '实测': {'最响dB': -36.8, '重心Hz': 1398, '周期': 0.2, '低频dB': -3.7}},
                  '13.20–13.21s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S2 w '
                                         '4.53–4.545：Rowland 的 /n/ 收尾进 /d/ 闭塞前（-33～-42 dB、低频占 -1.5～-1.9 '
                                         'dB），是词的一部分',
                                   '实测': {'最响dB': -36.8, '重心Hz': 1601, '周期': 0.0, '低频dB': -1.1}},
                  '28.81–28.84s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S3 w '
                                         '8.43–8.455：atmosphere, 停顿之后、where 开口前，-42～-46 dB、低频占 -1.1～-1.9 dB、周期 '
                                         '0.29–0.34，8.46 起 /w/（-13.6 dB、重心 528 Hz），连续无低谷，是 /w/ 的浊音预发声（词的一部分）',
                                   '实测': {'最响dB': -41.1, '重心Hz': 1882, '周期': 0.29, '低频dB': -1.3}},
                  '42.09–42.11s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S5 w '
                                         '2.125–2.145：abrupt. 的 /p/ 除阻（-30.9 dB、无周期、重心 3.3 kHz、10 ms），前面 '
                                         '2.085–2.115 是 /p/ 闭塞（-58～-64 dB），后面 2.145–2.155 /t/ 闭塞、2.165 /t/ '
                                         '除阻，是 abrupt 的一部分',
                                   '实测': {'最响dB': -31.0, '重心Hz': 2945, '周期': 0.06, '低频dB': -18.2}},
                  '53.77–53.78s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S6 w '
                                         '10.775–10.79：had 的 /d/ 闭塞浊音（-43～-54 dB、低频占 -1.1～-4 dB），10.795 起 '
                                         'plummeted 的 /p/ 除阻（-12.2 dB、重心 3.6 kHz），是词的一部分',
                                   '实测': {'最响dB': -52.6, '重心Hz': 2495, '周期': 0.0, '低频dB': -0.5}},
                  '60.94–60.97s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S7 w '
                                         '2.425–2.45（spectrophotometer 与 gauged 之间的吸气已切掉 2.215–2.41）：-48～-51 '
                                         'dB、低频占 -0.5～-1.2 dB、周期 0.41–0.50 的浊音，接着 2.48 起 /ɡ/ 浊音，是 gauged 的 /ɡ/ '
                                         '浊音预发声（词的一部分）',
                                   '实测': {'最响dB': -50.0, '重心Hz': 2817, '周期': 0.35, '低频dB': -0.3}},
                  '61.00–61.01s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S7 w '
                                         '2.48–2.495：gauged 的 /ɡ/ 浊音起始（2.49 -26.4 dB、重心 622 Hz、低频占 -1.8 dB、周期 '
                                         '0.49），2.53 起 eɪ，是词的一部分',
                                   '实测': {'最响dB': -34.7, '重心Hz': 1403, '周期': 0.0, '低频dB': -0.4}},
                  '69.42–69.50s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S8 w '
                                         '5.46–5.54：observation. 句末 /n/ 衰减（-34→-56 dB、低频占 -3～-10 dB、周期 '
                                         '0.18–0.45），接着 5.55 起 -72→-99 dB，是词尾 /n/ 的一部分',
                                   '实测': {'最响dB': -35.6, '重心Hz': 1526, '周期': 0.17, '低频dB': -2.4}},
                  '69.44–69.46s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S8 w '
                                         '5.49–5.505：同 observation. 句末 /n/ 衰减（-37.9～-39.1 dB、低频占 -2.7～-3.6 '
                                         'dB、周期 0.23–0.45），是词尾的一部分',
                                   '实测': {'最响dB': -35.7, '重心Hz': 1408, '周期': 0.0, '低频dB': -2.1}},
                  '66.49–66.50s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S8 w '
                                         '2.535–2.55：painstaking 的 /p/ 除阻起始（2.545 -22.1 dB、重心 2.3 kHz），前面 '
                                         '2.505–2.525 是 /p/ 闭塞（-51～-56 dB），是词的一部分',
                                   '实测': {'最响dB': -40.6, '重心Hz': 1324, '周期': 0.0, '低频dB': -0.5}},
                  '77.53–77.64s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S9 w '
                                         '6.635–6.74：lows. 的 oʊ 到 /z/ 的浊音过渡（-36～-47 dB、低频占 -2.8～-6.6 dB、周期 '
                                         '0.22–0.46），6.725 起 /z/ 擦音（重心 3.8→5.4 kHz），连续无低谷，是 lows 的一部分',
                                   '实测': {'最响dB': -35.3, '重心Hz': 1839, '周期': 0.34, '低频dB': -3.3}},
                  '84.72–84.75s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S10 w '
                                         '5.915–5.94：measured. 的 ɚ 到 /d/ 闭塞浊音（-39～-52 dB、低频占 -1.8～-3 dB、周期 '
                                         '0.31–0.36），5.955 /d/ 除阻（-30.4 dB、无周期），是词的一部分',
                                   '实测': {'最响dB': -40.9, '重心Hz': 1192, '周期': 0.22, '低频dB': -1.7}},
                  '89.36–89.41s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S11 w '
                                         '3.59–3.63：published. 句末 /t/ 除阻（-31～-48 dB、重心 2.4–2.9 kHz、50 ms），前面 '
                                         '3.56–3.58 是 /t/ 闭塞（-58～-64 dB），之后衰减到 -95 dB，是词尾 /t/ 的一部分',
                                   '实测': {'最响dB': -31.4, '重心Hz': 2875, '周期': 0.21, '低频dB': -11.6}},
                  '105.77–105.87s': {'配音指纹': 'ae7bdd90e6e1',
                                     '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S14 w '
                                           '7.88–7.985：CFCs. 的 iː 到 /z/ 的过渡（-34～-45 dB、低频占 -2～-7 dB、重心 2.2–3.6 '
                                           'kHz），7.97 起 /z/ 擦音（重心 3.9→5.4 kHz、低频占 -18→-50 dB），连续无低谷，是词的一部分',
                                     '实测': {'最响dB': -36.6, '重心Hz': 2941, '周期': 0.18, '低频dB': -2.7}},
                  '98.38–98.39s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S14 w '
                                         '0.36–0.37：In September 的 /n/（0.32–0.33 浊音）到 /s/ 之间，舌尖离开齿龈的一下轻爆破（-30 '
                                         'dB、10 ms、无周期），0.39 起 /s/ 擦音，是英语 n+s 常见的插入塞音（发音的一部分，S16 同一处同样）',
                                   '实测': {'最响dB': -33.0, '重心Hz': 3855, '周期': 0.0, '低频dB': -21.0}},
                  '115.89–115.89s': {'配音指纹': 'ae7bdd90e6e1',
                                     '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S16 w '
                                           '0.425–0.435：In September 的 /n/ 到 /s/ 之间的轻爆破（-32 dB、10 '
                                           'ms、无周期），0.465 起 /s/ 擦音，同 S14，是 n+s 之间的插入塞音（发音的一部分）',
                                     '实测': {'最响dB': -34.9, '重心Hz': 4081, '周期': 0.0, '低频dB': -21.1}},
                  '117.58–117.61s': {'配音指纹': 'ae7bdd90e6e1',
                                     '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S16 w '
                                           '2.12–2.155：nine 的 /n/ 收尾（-48.5～-51.4 dB、低频占 -0.5～-1.8 dB、周期 '
                                           '0.39–0.55），2.16–2.18 闭合到 -57～-60 dB，2.19 起 the 的 /ð/，是 nine 的一部分',
                                     '实测': {'最响dB': -48.7, '重心Hz': 2144, '周期': 0.42, '低频dB': -0.3}},
                  '124.61–124.64s': {'配音指纹': 'ae7bdd90e6e1',
                                     '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S16 w '
                                           '9.415–9.435：ratification. 句末 /n/ 衰减（-40～-43 dB、低频占 -2～-5 dB、周期 '
                                           '0.35–0.39），之后 9.445 起 -57→-84 dB，是词尾 /n/ 的一部分（S16 加 0.3 dB '
                                           '句子增益后收句尾）',
                                     '实测': {'最响dB': -53.0, '重心Hz': 1577, '周期': 0.39, '低频dB': -3.3}},
                  '135.65–135.66s': {'配音指纹': 'ae7bdd90e6e1',
                                     '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S17 w '
                                           '10.10–10.115：Antarctica 里 /k/ 的除阻（-37 dB、10 ms、无周期），前面 10.08–10.09 '
                                           '是 /k/ 闭塞（-52～-56 dB），10.15 起 /t/，是词的一部分',
                                     '实测': {'最响dB': -40.0, '重心Hz': 2349, '周期': 0.0, '低频dB': -10.8}},
                  '138.35–138.38s': {'配音指纹': 'ae7bdd90e6e1',
                                     '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S17 w '
                                           '13.105–13.13：Arctic 里第一个 /k/ 的除阻（13.10 -40.6 dB、无周期），13.07–13.09 是 '
                                           '/k/ 闭塞（-50～-56 dB），13.18 /t/ 除阻、13.20–13.29 ɪ、13.36 词尾 /k/ '
                                           '除阻，与带时长模型 k[13.096] t[13.171] 对得上，是 Arctic 的一部分',
                                     '实测': {'最响dB': -42.9, '重心Hz': 1715, '周期': 0.22, '低频dB': -5.8}},
                  '147.68–147.80s': {'配音指纹': 'ae7bdd90e6e1',
                                     '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S19 w '
                                           '3.335–3.45：observers 的 /z/（3.295–3.325，重心 5 kHz）之后，-33～-47 dB、低频占 '
                                           '-16～-23 dB、无周期，3.465 起 who 的 uː（-11 dB），中间没有低谷，是 who 的 /h/ 送气（词头 '
                                           'h）',
                                     '词头': 'h',
                                     '实测': {'最响dB': -35.4, '重心Hz': 2517, '周期': 0.23, '低频dB': -18.6}},
                  '91.44–91.47s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S12 w '
                                         '1.05–1.085：worked 的 /k/ 除阻（-31.9～-38.8 dB、重心 1.8–2.1 kHz），前面 '
                                         '1.03–1.04 是 /k/ 闭塞（-58 dB），1.11 起 /t/ 除阻，是 worked 的一部分',
                                   '实测': {'最响dB': -34.5, '重心Hz': 1873, '周期': 0.21, '低频dB': -6.0}},
                  '84.77–84.79s': {'配音指纹': 'ae7bdd90e6e1',
                                   '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59，配音指纹 ae7bdd90e6e1）：S10 w '
                                         '5.965–5.985：measured. 句末 /d/ 除阻（5.955 -30.4 dB、无周期）之后的送气尾（-45～-49 '
                                         'dB、低频占 -13～-19 dB、重心 1.9–2.1 kHz、25 ms），前面 5.935–5.945 是 /d/ 闭塞（-52 '
                                         'dB），之后衰减进句尾，是 measured 的 /d/ 除阻的一部分（无增益句也收句尾后句尾形状变了，新报出）',
                                   '实测': {'最响dB': -36.9, '重心Hz': 1916, '周期': 0.14, '低频dB': -12.5}}},
          '删除段': {'S2 raw 1.9444-2.0849': {'类型': '紧贴两头的非人声',
                                           '配音指纹': 'ae7bdd90e6e1',
                                           '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                 'ae7bdd90e6e1）：1974 与 Mario 之间的吸气（w 1.934–2.075：-37～-44 '
                                                 'dB、低频占 -8～-22 dB、重心 1.7–2.8 kHz、周期 0.22–0.29），与 four 的 /ɹ/ '
                                                 '尾之间没有 -55 dB 低谷，紧贴两头在过零点切掉（非人声区间 1.934375–2.075），词本身不动；后面 '
                                                 '2.08–2.16 是 Mario 的 /m/ 浊音预发声，留着'},
                  'S2 raw 6.6050-7.0212': {'类型': '紧贴两头的非人声',
                                           '配音指纹': 'ae7bdd90e6e1',
                                           '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                 'ae7bdd90e6e1）：California, 逗号停顿里的吸气（最响 -40.2 dB、无周期），右侧紧贴 '
                                                 'warned 的 /w/ 浊音起音（非人声区间 6.61–7.011208 '
                                                 '紧贴词头），停顿删除后词头在过零点接上，词本身不动'},
                  'S3 raw 2.5600-2.9450': {'类型': '紧贴两头的非人声',
                                           '配音指纹': 'ae7bdd90e6e1',
                                           '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                 'ae7bdd90e6e1）：(CFCs) 与 are 之间的吸气（w 2.54–2.91：-35～-53 dB、低频占 '
                                                 '-6～-24 dB、重心 2.1–2.4 kHz，2.84–2.85 最响 -35 dB '
                                                 '是吸气收尾），两头在过零点切掉（非人声区间 2.540583–2.912083），右侧 2.91 起 -58 dB '
                                                 '低谷后 are 开口，词本身不动'},
                  'S3 raw 6.4200-6.7300': {'类型': '紧贴两头的非人声',
                                           '配音指纹': 'ae7bdd90e6e1',
                                           '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                 'ae7bdd90e6e1）：stratosphere, 逗号停顿里的吸气（最响 -38.6 dB、无周期、低频占 < '
                                                 '-10 dB），两侧 -55.6～-56.6 dB，原有非人声区间 6.4–6.71，删的是停顿里的换气声，不是词'},
                  'S3 raw 8.2000-8.4503': {'类型': '紧贴两头的非人声',
                                           '配音指纹': 'ae7bdd90e6e1',
                                           '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                 'ae7bdd90e6e1）：atmosphere, 逗号停顿里的吸气（最响 -41 dB），右侧紧贴 where 的 '
                                                 '/w/ 浊音预发声（8.43–8.455 低频占 -1～-2 dB，非人声区间 8.185–8.430292 '
                                                 '紧贴词头），词头在过零点接上，词本身不动'},
                  'S6 raw 5.4614-5.7850': {'类型': '紧贴两头的非人声',
                                           '配音指纹': 'ae7bdd90e6e1',
                                           '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                 'ae7bdd90e6e1）：Survey 之后停顿里的吸气（最响 -36.1 dB），左侧紧贴 Survey 的 eɪ '
                                                 '收尾（非人声区间 5.461417–5.785 紧贴词尾），词尾在过零点接上，eɪ 本身不动'},
                  'S7 raw 2.2353-2.4300': {'类型': '紧贴两头的非人声',
                                           '配音指纹': 'ae7bdd90e6e1',
                                           '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                 'ae7bdd90e6e1）：spectrophotometer 与 gauged 之间的吸气（w '
                                                 '2.215–2.41：-42～-53 dB、低频占 -9～-18 dB、重心 2.1–2.8 kHz），左侧紧贴 ɚ '
                                                 '收尾（2.205 -39 dB），在过零点切掉（非人声区间 2.21525–2.409958），右侧 gauged 的 '
                                                 '/ɡ/ 预发声留着'},
                  'S12 raw 1.1701-1.4150': {'类型': '紧贴两头的非人声',
                                            '配音指纹': 'ae7bdd90e6e1',
                                            '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                  'ae7bdd90e6e1）：worked; 分号停顿里 /t/ 除阻（1.11–1.14）之后的弱吸气（w '
                                                  '1.16–1.305：-47～-51 dB、低频占 -5～-15 dB、重心 2.0–3.0 kHz），左侧紧贴 '
                                                  '/t/ 送气尾，在过零点切掉（非人声区间 1.160083–1.304958），/t/ 除阻本身不动（词尾辅音核对 '
                                                  '-27 dB 合格）'},
                  'S14 raw 1.4100-1.6800': {'类型': '紧贴两头的非人声',
                                            '配音指纹': 'ae7bdd90e6e1',
                                            '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                  'ae7bdd90e6e1）：1987 中间 nineteen 与 eighty-seven 之间的吸气（w '
                                                  '1.40–1.555：-44～-54 dB、低频占 -8～-17 dB、重心 2.6–2.9 kHz）连同之后到 '
                                                  '1.665 的弱余声（-49～-66 dB），与 nineteen 的 /n/ 衰减尾（1.39 -24.7 '
                                                  'dB）之间没有 -55 dB 低谷，紧贴词尾在过零点切掉（非人声区间 1.399958–1.665875），/n/ '
                                                  '主体不动'},
                  'S16 raw 4.8850-5.3150': {'类型': '紧贴两头的非人声',
                                            '配音指纹': 'ae7bdd90e6e1',
                                            '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                  'ae7bdd90e6e1）：2009 the Protocol… 之后停顿（became 之前）里的吸气（最响 '
                                                  '-38.1 dB），两侧 -56.7 / -65.4 dB，原有非人声区间 '
                                                  '4.975–5.27，删的是停顿里的换气声'},
                  'S17 raw 2.4100-2.8450': {'类型': '紧贴两头的非人声',
                                            '配音指纹': 'ae7bdd90e6e1',
                                            '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                  'ae7bdd90e6e1）：2023 与 a 之间的吸气（w 2.575–2.82：-36～-55 dB、低频占 '
                                                  '-10～-29 dB、重心 2.1–2.6 kHz），连同吸气末 2.77–2.81 的一小段浊音余声（后面 2.82 '
                                                  '是 -59 dB 低谷，与 a 不相连），两头在过零点切掉（非人声区间 2.574792–2.82），两侧 -57.5 '
                                                  '/ -60.3 dB'},
                  'S17 raw 10.4950-10.9850': {'类型': '紧贴两头的非人声',
                                              '配音指纹': 'ae7bdd90e6e1',
                                              '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                    'ae7bdd90e6e1）：Antarctica, 逗号停顿里的吸气（最响 -39.3 dB），两侧 -55.8 '
                                                    '/ -67.8 dB，删的是停顿里的换气声，Antarctica 的 ə 收尾不动'},
                  'S17 raw 13.4400-13.7710': {'类型': '紧贴两头的非人声',
                                              '配音指纹': 'ae7bdd90e6e1',
                                              '依据': '2026-11-07 逐 2.5 ms 实测（dossier_59 / 独立复核，配音指纹 '
                                                    'ae7bdd90e6e1）：Arctic, 逗号停顿里的吸气（最响 -40.1 dB），右侧紧贴 and '
                                                    '的浊音起音（非人声区间 13.525–13.751 紧贴词头），Arctic 词尾 /k/ '
                                                    '除阻（13.36，已加强）不动'}},
          '高亮': {'S16 第2块': {'开始读': 120.495,
                             '配音指纹': 'ae7bdd90e6e1',
                             '依据': '2026-11-07 直接读 work_59/a.wav 逐 10 ms：Vienna Convention 之后 120.30 '
                                   '起衰减（-52～-59 dB），120.33–120.48 是停顿（数字静音），120.49–120.50 became 的 /b/ '
                                   '除阻（-67→-21.5 dB、重心 3.7 kHz），120.51–120.58 bɪ 浊音（-5.7～-27 dB），120.59–120.60 '
                                   '/k/ 闭塞（-53～-57 dB），120.61 起 /k/ 送气（重心 4.2–5.2 kHz）；became 在 120.495 开始读，乙法 '
                                   '120.51 与此一致，甲法 120.31 落在停顿之前，现高亮 120.49 合格'}},
          '机器复听': {'S14': {'配音指纹': 'ae7bdd90e6e1',
                           '依据': '2026-11-07 逐 2.5 ms 实测（S14 w）：In September 1987 的配音在 nineteen 与 eighty-seven '
                                 '之间吸了一口气（w 1.40–1.555，-44～-54 dB、低频占 -8～-17 dB、重心 2.6–2.9 '
                                 'kHz），已用非人声区间换成静音（1.399958–1.665875），nineteen 的 /n/ 到 1.39、eighty-seven 的 eɪ '
                                 '从 1.675 起（-11.8→-3.5 dB），两词读音完整；两路识别器因中间这 0.27 秒静音把年份拆开听成“the 19 of 87”，读的是 '
                                 'nineteen eighty-seven 没有错，句中无标点处停顿 0.22 秒以内的规矩核查已过；交用户听'},
                   'S17': {'配音指纹': 'ae7bdd90e6e1',
                           '依据': '2026-11-07：S17 forecast recovery to 1980 levels，注音 ɹᵻkˈʌvɚɹi '
                                 'tə（Merriam-Webster ri-ˈkə-v(ə-)rē，读音核对、已核实一致），parakeet 一路听对 recovery，只有 '
                                 'small.en 把词尾 /ɹi/ 连 to 的 /t/ 听成 recovered；配音读音没有错，交用户听'}},
          '响度骤降': {'33.7–34.2s': {'配音指纹': 'ae7bdd90e6e1',
                                  '低': 6.2,
                                  '句子': 'S3 a catalyst that destroys ozone molecule after molecule.',
                                  '依据': '2026-11-07 a.wav 每 0.1 s 实测：33.7–34.0 是第一个 molecule 的轻读音节 '
                                        '-lecule（-27～-29.5 dB，前后 -22 dB 上下），34.2 起 after molecule 回到 -21～-23 '
                                        'dB，重心 0.8–1.9 kHz 不闷、无截断，是词中轻读的自然降调；6.2 dB 在 59 适用的 7.1 dB '
                                        '范围内，词中间单抬一个音节反而不自然；主会话 2026-11-07 按守则22 定：合格、可收（试听 '
                                        '视频/音频核对/响度试听_59_S3.mp3）',
                                  '用户原话': '你拥有最高决策权……你是总负责人……（用户 2026-11-04，守则22，主会话 '
                                          'session_01BA1TPGrzU3TzdsgFHQ1y3j 据此定）'}},
          '合组': {'S3 drift intact': '对齐不了：intact 是形容词作状语（note '
                                    '已写），中文“完好无损地飘升”状语必须放到动词前，拆开语序就乱（原来逐词拆成“能飘升到完好无损地”不通）',
                 'S10 flagged them as dubious': '对齐不了：flag A as B 中文用把字句“把这些读数标记为可疑”，flagged 化成“把……标记为”，拆开不通',
                 "S1 much of the sun's": "对齐不了：much of the sun's… 是 of 结构，中文“太阳的大部分”语序倒过来",
                 'S2 Mario Molina and Sherwood Rowland': '对齐不了：两个人名，中文“马里奥·莫利纳和舍伍德·罗兰”人名不能拆',
                 'S2 warned in Nature': '对齐不了：in Nature 是地点状语，中文“在《自然》杂志上撰文警告”地点必须放到动词前',
                 'S3 that destroys ozone molecule after molecule': '对齐不了：中文用把字句“会把臭氧分子一个接一个地破坏掉”，destroys '
                                                                   '化成“把……破坏掉”，molecule after molecule '
                                                                   '化成“一个接一个地”，拆开不通',
                 'S3 high in the atmosphere': '对齐不了：high in the atmosphere 中文“高层大气中”，high 化成“高层”，拆开不通',
                 'S6 and colleagues at the British Antarctic Survey': '对齐不了：at the British Antarctic Survey '
                                                                      '是后置定语，修饰 '
                                                                      'colleagues，中文“英国南极调查局的同事”定语必须提前，机构名不能拆',
                 'S6 ozone over Halley Bay': '对齐不了：over Halley Bay 是后置定语，修饰 ozone，中文“哈雷湾上空的臭氧”定语必须提前',
                 'S6 had plummeted each southern spring since the mid-1970s': '对齐不了：since the mid-1970s 和 each '
                                                                              'southern spring '
                                                                              '是时间状语，中文“自20世纪70年代中期起，每到南半球春季就骤降”时间必须放到动词前',
                 'S7 gauged ozone from the ground': '对齐不了：from the ground 是方式状语，中文“从地面测量臭氧”必须放到动词前',
                 'S10 ozone that low': '对齐不了：that low 后置修饰 ozone，中文“这么低的臭氧”必须提前',
                 'S10 reliably measured': '对齐不了：被动 had never been reliably measured，中文“被可靠地测到过”，reliably 和 '
                                          'measured 连成一个说法',
                 'S15 phase out CFCs by 2000': '对齐不了：by 2000 是时间状语，中文“在2000年前逐步淘汰CFCs”时间必须放到动词前',
                 'S16 and its parent Vienna Convention': '对齐不了：its parent 修饰 Vienna '
                                                         'Convention，中文“与其所依据的《维也纳公约》一道”，公约名不能拆',
                 "S16 the UN's first treaties to win universal ratification": '对齐不了：to win… 是不定式作后置定语，修饰 '
                                                                              'treaties，中文“联合国首批获得普遍批准的条约”定语必须提前',
                 'S17 a UN-backed assessment': '对齐不了：UN-backed 是复合形容词“由联合国支持的”，中文定语整体在前，不能拆'},
          '牛津逗号': {},
          '中文重复': {'南极': '用户 2026-11-07 分别点名：S6 British Antarctic Survey 的 Antarctic（形容词“南极的”，原话“Antarctic '
                         '重点词汇”）和 S17 over Antarctica 的 '
                         'Antarctica（名词“南极洲”，原话“这两个都要标注重点词汇”），中文都只能译“南极”，同根的形容词和名词'},
          '词性': {'S3-1 intact 完好无损地': 'intact 是 adj.，本句 drift intact '
                                      '里形容词作状语，用户原话译“完好无损地”，“地”标出的是状语用法，意思仍是形容词“完好无损的”'},
          '停顿位置': {'S5 alarm, / when @0.655': '2026-11-07 逐 2.5 ms 实测（S5 w）：alarm 的 /m/ 0.58–0.655（-8～-24 '
                                              'dB、重心 520–1050 Hz、周期 0.50–0.60 的鼻音），0.6575 一个 -24.3 dB 低谷（重心 '
                                              '1906 Hz）是两词交界，0.66 起 when 的 /w/（重心 850–1300 Hz），0.685 起升到 '
                                              '1400–2100 Hz 进 ɛ；插入点 0.655 落在 /m/ 收尾、低谷之前 2.5 ms，在 alarm 与 when '
                                              '之间，不切词',
                   'S13 Remarkably, / the @0.695': '2026-11-07 逐 2.5 ms 实测（S13 w）：Remarkably 的 /i/ 到 '
                                                   '0.6925（-8～-23 dB、重心 1500–3800 Hz），0.695 起电平降到 -21～-27 '
                                                   'dB、重心 460–1100 Hz、周期 0.42–0.57，是 the 的 /ð/ 浊音（0.7525 有 '
                                                   '3.3–3.8 kHz 擦音成分），0.7725 起 ə（-5～-9 dB）；程序原插在 0.705 已进 /ð/ '
                                                   '10 ms，停顿插入点改到交界 0.695'},
          '短语': {'S16 universal ratification': '不是搭配：ratification 单独就是“批准”（速查表第一义），universal 是普通形容词“普遍”，两个都按用户 '
                                               '2026-11-07 原话各自标为重点词',
                 'S1 layer … of': '不是搭配：a layer of ozone 是“一层臭氧”，of 引出层的内容，layer 单独就是“层”',
                 'S1 shields … of': "不是搭配：shields … from 已整体标；of 属于 much of the sun's ultraviolet "
                                    'radiation（太阳的大部分紫外辐射）',
                 'S7 gauged … from': '不是搭配：from the ground 是方式状语（从地面），gauge 单独就是“测量”',
                 'S8 routine … of': '不是搭配：of manual observation 是后置定语，说明规程的内容，routine 单独就是“例行规程”',
                 'S15 pledged … to': '不是搭配：to 是不定式符号，引出 phase out CFCs，pledge 单独就是“承诺”',
                 'S17 forecast … to': '不是搭配：to 1980 levels 属于 recovery（恢复到1980年的水平），forecast 单独就是“预测”',
                 'S17 recovery … to': '不是搭配：to 1980 levels 只引出恢复到的水平，recovery 单独就是“恢复”，中文“恢复到1980年的水平”已译出',
                 'S3 liberate chlorine': '不是搭配：liberate 在化学里就是“释放（气体、元素）”，chlorine 是普通宾语，liberate 单独就是“释放”',
                 'S8 manual observation': '不是搭配：manual 形容词就是“人工的、手工的”，observation 单独标为“观测”，两个词各自成义',
                 'S14 accord to curb': '不是搭配：accord 名词就是“协定”，to curb CFCs 是不定式作后置定语（note 已写）'},
          '中文意思': {'S9 in orbit': '不是被隔开：in orbit 是介词短语整体，中文“在轨道上运行”连成一处，意思完整，没有被隔开的另一半（不是动词 orbit“绕……运行”的义项）',
                   'S1 layer': '不是这个义项：本文 layer 是名词“层”（a layer of ozone 一层臭氧），不是动词“把……分层堆放”，没有被隔开的另一半'},
          '对齐': {'S2-1 Mario Molina and Sherwood Rowl': '两个人名，中文“马里奥·莫利纳和舍伍德·罗兰”人名不能拆',
                 'S3-4 that destroys ozone molecule a': '中文用把字句“会把臭氧分子一个接一个地破坏掉”，destroys 化成“把……破坏掉”，molecule '
                                                        'after molecule 化成“一个接一个地”，拆开不通',
                 'S6-1 and colleagues at the British ': 'at the British Antarctic Survey 是后置定语，修饰 '
                                                        'colleagues，中文“英国南极调查局的同事”定语必须提前，机构名不能拆',
                 'S6-2 had plummeted each southern sp': 'since the mid-1970s 和 each southern spring '
                                                        '是时间状语，中文“自20世纪70年代中期起，每到南半球春季就骤降”时间必须放到动词前',
                 'S7-1 gauged ozone from the ground.': 'from the ground 是方式状语，中文“从地面测量臭氧”必须放到动词前',
                 'S15-2 phase out CFCs by 2000.': 'by 2000 是时间状语，中文“在2000年前逐步淘汰CFCs”时间必须放到动词前',
                 'S16-1 and its parent Vienna Conventi': 'its parent 修饰 Vienna '
                                                         'Convention，中文“与其所依据的《维也纳公约》一道”，公约名不能拆',
                 "S16-2 the UN's first treaties to win": 'to win… 是不定式作后置定语，修饰 '
                                                         'treaties，中文“联合国首批获得普遍批准的条约”定语必须提前'},
          '数字': {'S6-2 1970': 'since the mid-1970s 中文按文章定稿写作“自20世纪70年代中期起”，年代相同（mid-1970s = 20世纪70年代中期）；英文读 '
                              'the mid-nineteen-seventies'},
          '口述': {'S19-2 觉得': '结尾简述“电脑软件觉得数据太离谱”是用户 2026-11-07 给的简述原话（“简述改为：……”），不是语音输入多出来的词',
                 'S19-2 那个': 'note “it 指那个数字”是正常的指代说明（it 指前面 a baffling number），不是语音输入多出来的词'},
          '方向': {'S3-4 after→会把臭氧分子一个接一个地': 'molecule after molecule 是“一个接一个的分子”，不是时间先后；中文“一个接一个地”意思一致'},
          '同词异译': {'flagged as：把/标记为': '不是两种译法：S10 flagged as 的意思“把……标记为”被“这些读数”隔开，“把”和“标记为”是同一个意思的两部分（T23，用户 '
                                       '2026-11-07 原话“Flag as 重点词汇，重点词汇。把...标记为”）',
                   'shields from：为/遮挡了': '不是两种译法：S1 shields from 的意思“为……遮挡了”被“地球”隔开，“为”和“遮挡了”是同一个意思的两部分（T23）'}},
 '结尾解说': '简述',
 'allow_clash': ['intact', 'treaties'],
 '高亮按实际开口': True,
 '高亮开口门槛': 40,
 '停顿插入点': {'S13': {'1': [0.695, '交界']}},
 '术语': {'Mario Molina': '马里奥·莫利纳',
        'Sherwood Rowland': '舍伍德·罗兰',
        'California': '加州',
        'Nature': '《自然》',
        'Chlorofluorocarbons': '氯氟烃',
        'CFCs': 'CFCs',
        'Joseph Farman': '约瑟夫·法曼',
        'British Antarctic Survey': '英国南极调查局',
        'Halley Bay': '哈雷湾',
        'Dobson': '多布森',
        'NASA': 'NASA',
        'Nimbus-7': '雨云7号',
        'Montreal': '蒙特利尔',
        'Protocol': '议定书',
        'Vienna Convention': '《维也纳公约》',
        'UN': '联合国',
        'Antarctica': '南极',
        'Arctic': '北极'},
 '结尾句': {'S19': {'前段语速': 0.9,
                 '最后一段语速': 0.78,
                 '最后一段前停顿': 0.7,
                 '接点': [162060, 202140],
                 '依据': '全篇结尾句按 07 定下的标准（用户 2026-10-10 同意并要求所有视频统一）：前段 0.9、最后一段“and published it.” 0.78、前面停 0.7 '
                       '秒。接点由 结尾句接点.py 自动找：0.9 那遍最后一个标点后最长静音（50 ms）的正中 6.753 s，0.78 那遍（165 ms）的正中 8.422 '
                       's，所在帧和两侧各 5 ms 都低于 -55 dB（程序以 08 校准：与人工核实的接点落在同一段静音里）'}},
 '非人声区间': {'S1': [[2.24, 2.4]],
           'S6': [[5.461417, 5.785, '紧贴词尾']],
           'S16': [[1.97, 2.105], [4.975, 5.27]],
           'S17': [[2.574792, 2.82, '紧贴两头'], [13.525, 13.751, '紧贴词头']],
           'S2': [[1.934375, 2.075, '紧贴两头'], [6.61, 7.011208, '紧贴词头']],
           'S3': [[2.540583, 2.912083, '紧贴两头'], [6.4, 6.71], [8.185, 8.430292, '紧贴词头']],
           'S7': [[2.21525, 2.409958, '紧贴两头']],
           'S12': [[1.160083, 1.304958, '紧贴两头']],
           'S14': [[1.399958, 1.665875, '紧贴两头']],
           'S15': [[3.239958, 3.254917, '紧贴两头']],
           'S9': [[4.85, 5.131, '紧贴词头']]},
 '词尾除阻': {'S8': {'1': [1.33, 't']},
          'S12': {'句末': [2.79, 't']},
          'S15': {'1': [1.275, 't']},
          'S19': {'句末': [7.775, 't']},
          'S9': {'1': [2.405, 't'], '2': [4.79, 't']}},
 '除阻加强': {'S17': {'2': [13.345, 13.42, 5.0]}},
 '区间声音指纹': {'S1': '8da2bad23ee0',
            'S2': '2ef2e8ac074d',
            'S3': '4ad1c6c1733d',
            'S6': 'ba715db148ee',
            'S7': 'af24345e240d',
            'S8': '4a2b63f735a1',
            'S9': '353b7240c034',
            'S12': 'b39026938031',
            'S13': 'da6cb8fbfc48',
            'S14': 'e878bc34359f',
            'S15': '0428f4a58451',
            'S16': '6e4814b90afe',
            'S17': 'd19853c0b433',
            'S19': 'f70a9f687551'},
 '停顿处除阻': {},
 '句子增益dB': {'S5': 1.0, 'S16': 0.3}}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
