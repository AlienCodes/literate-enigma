# EN: The Truth About One Marshmallow
# ZH: 一颗棉花糖的真相

## 英文
Picture a **nursery school** on **Stanford**'s **campus** in the late 1960s and early 1970s. A child of about four or five sits **in solitude** before one treat, facing a **blunt** **bargain**: eat it now, or **resist** **temptation** for about 15 minutes and **earn** two. **Impulsive** children often **surrender** **instantly**; **resolute** ones **hold out**.

**Follow-ups** made the test **legendary**. A 1990 study in Developmental **Psychology**  found that, as **adolescents**, longer waiters tended to **attain** higher scores on the SAT, a US **college-entrance exam**.  A **trivial** **snack** became an **emblem** of **virtue**, and **restraint** at four was **glorified** as a **predictor** of **destiny**.

Yet the **foundation** was **precarious**. Only **a few dozen** children entered the SAT analysis, **predominantly** the sons and daughters of Stanford **faculty** and **postgraduate** students. Such a **homogeneous**, **privileged** group could **scarcely** represent **ordinary** families, and **prosperous** homes may **foster** patience and academic success **alike**.

A study published in Psychological Science in May 2018 ran a **conceptual** **replication**: the same idea, a new sample, **modified** methods. More than 900 **youngsters** from **diverse** backgrounds were **assessed** at four and a half and again at 15. The raw **link** was roughly half as strong as the original finding. **Adjusting for** family background and early **cognitive** ability shrank it by about two thirds, leaving most estimates **statistically** **insignificant**.

The test is not **worthless**; it may still **reflect** something **substantive**. Research published in Cognition in January 2013 adds **context**: children whose trust an adult had just **betrayed** waited **markedly** less than **peers** dealing with a reliable adult. How long a child **perseveres** **depends** partly **on** how **trustworthy** the adults around them seem.

## 中文

想象一下一所**幼儿园**(nursery school)，位于**斯坦福大学**(Stanford)**校园**(campus)里，时间是20世纪60年代末至70年代初。一个大约四五岁的孩子**独自**(in solitude)坐在一份零食前，面对一桩**直截了当的**(blunt)**交易**(bargain)：现在就吃，或者**抵挡**(resist)**诱惑**(temptation)约15分钟，就能**挣得**(earn)两份。**冲动的**(Impulsive)孩子往往**立刻**(instantly)**缴械投降**(surrender)；**意志坚定的**(resolute)孩子则**坚持抵抗，拒不妥协**(hold out)。

**后续研究**(Follow-ups)让这项测验**名声大噪**(legendary)（被传为经典）。1990年《发展**心理学**(Psychology)》上的一项研究发现，到了**青少年**(adolescents)时期，等得更久的孩子往往在SAT中**取得**(attain)更高分数，（也就是）美国的**高考**(college-entrance exam)（大学录取考试）。一份**微不足道的**(trivial)**零食**(snack)成了**美德**(virtue)的**象征**(emblem)，而四岁时的**克制**(restraint)被**美化**(glorified)为**命运**(destiny)的**预测指标**(predictor)。

然而，这种**根据**(foundation)（该研究结论的根基）**并不牢靠**(precarious)（站不住脚）。只有**几十个**(a few dozen)孩子进入了SAT分析，**主要**(predominantly)是斯坦福**教师**(faculty)（全体教员）和**研究生**(postgraduate)的子女。如此**同质的**(homogeneous)、**优越的**(privileged)群体**几乎不**(scarcely)能代表**普通的**(ordinary)家庭，而且**富裕的**(prosperous)家庭可能**既能培养**(foster)耐心也能促成学业成就（**二者兼顾**(alike)）。

2018年5月发表于《心理科学》的一项研究做了一次**概念性的**(conceptual)（科研）**重复实验**(replication)：同样的思路，新的样本，**调整过的**(modified)方法。900多名来自**多种不同的**(diverse)背景的**儿童或青少年**(youngsters)在四岁半时接受**评估**(assessed)，15岁时再测一次。这个未经加工的**关联性**(link)，大约只有原来研究结果关联性强度的一半。（关联性：【面对棉花糖等得更久】与【SAT分数更高】之间有没有关系）**调整**(Adjusting for)家庭背景和早期**认知**(cognitive)能力（这些实验变量），缩小了关联性大约三分之二，使得大多数估计值在**统计上**(statistically)（完全）**微不足道**(insignificant)。（即缩小了【等得更久】与【SAT分数更高】之间的相关性：100% → 约 33%，下降了约 2/3）

这项测验并非**毫无价值**(worthless)；它或许仍能**反映**(reflect)某些**实质性的**(substantive)东西。2013年1月发表于《认知》的研究补充了（一些）**背景**(context)：刚被成年人**辜负**(betrayed)信任的孩子，等待的时间**明显**(markedly)短于与守信的成年人相处的**同龄人**(peers)。孩子能**坚持**(perseveres)多久，部分**取决于**(depends on)身边的大人看起来有多**可信**(trustworthy)。

（简述：▸实验：四五岁孩子面前放一份零食，可以马上吃，也可以独自等约15分钟换两份。研究者记录等待时间，后来再追踪这些孩子。▸走红：早期追踪发现，等得久的孩子后来在美国大学入学考试SAT中成绩较高，于是这个测试被宣传成未来成功的预测器。▸局限：早期SAT分析只有数十名孩子，多来自斯坦福大学教职工和研究生家庭。家庭条件可能同时帮助孩子培养耐心、取得好成绩，不能把成绩全归功于自制力。▸复核：2018年研究追踪900多名不同背景儿童，先发现等待与成绩的关联只有早期的一半；再考虑家庭条件和原有理解、学习能力，关联又减弱约三分之二。结果削弱了原来的推论，却不等于两者毫无关系。▸信任：2013年实验发现，刚遇到不守信大人的孩子等得更短。等待也受周围环境和成人是否可信影响，不能凭一次测试断定孩子的命运。）

## 速查表
| 词 | 释义 | 段 |
|---|---|---|
| nursery school | 本文：幼儿园；n. 幼儿园，托儿所（nursery school；a day nursery）；育婴室 | 1 |
| Stanford | 本文：斯坦福大学；n. 斯坦福（美国大学名称的简称；Stanford University 斯坦福大学） | 1 |
| campus | 本文：校园；n. 校园（on campus；a university campus） | 1 |
| in solitude | 本文：独自；n. 独处，孤独（in solitude；peace and solitude） | 1 |
| blunt | 本文：直截了当的；adj. 直截了当的，生硬的（a blunt question/refusal）；钝的 | 1 |
| bargain | 本文：交易；n. 交易，协议（strike/make a bargain）；便宜货；v. 讨价还价 | 1 |
| resist | 本文：抵挡；v. 抵制，抵挡（resist temptation/pressure；can't resist doing） | 1 |
| temptation | 本文：诱惑；n. 诱惑（resist/give in to temptation） | 1 |
| earn | 本文：挣得；v. 挣得，赢得（earn money/respect/a reward） | 1 |
| Impulsive | 本文：冲动的；adj. 冲动的（impulsive behaviour/buying） | 1 |
| instantly | 本文：立刻；adv. 立即，马上（be instantly recognisable） | 1 |
| surrender | 本文：缴械投降；v. 投降，屈服（surrender to temptation/the enemy）；n. 投降 | 1 |
| resolute | 本文：意志坚定的；adj. 坚决的，意志坚定的（a resolute refusal；resolute in doing） | 1 |
| hold out | 本文：坚持抵抗，拒不妥协；phr. 坚持，不屈服（hold out against pressure）；维持，够用 | 1 |
| Follow-ups | 本文：后续研究；n. (follow-up) 后续研究，追踪（a follow-up study/visit） | 2 |
| legendary | 本文：名声大噪；adj. 传奇的，非常著名的（a legendary figure/performance） | 2 |
| Psychology | 本文：心理学；n. 心理学（developmental psychology 发展心理学；study psychology 学习心理学） | 2 |
| college-entrance exam | 本文：高考；n. 大学入学考试（a college-entrance exam；take a college-entrance exam 参加大学入学考试） | 2 |
| adolescents | 本文：青少年；n. (adolescent) 青少年（troubled adolescents）；adj. 青春期的 | 2 |
| attain | 本文：取得；v. 获得，达到（attain a goal/level/success） | 2 |
| trivial | 本文：微不足道的；adj. 微不足道的，琐碎的（a trivial matter/detail） | 2 |
| snack | 本文：零食；n. 零食，小吃（a light snack；snack food）；v. 吃零食 | 2 |
| virtue | 本文：美德；n. 美德；优点（a moral virtue；by virtue of 凭借） | 2 |
| emblem | 本文：象征；n. 象征，标志（an emblem of power/peace） | 2 |
| restraint | 本文：克制；n. 克制，约束（show/exercise restraint；without restraint） | 2 |
| glorified | 本文：美化；v. (glorify) 美化，颂扬（glorify war/violence）；glorified adj. 美其名曰的 | 2 |
| destiny | 本文：命运；n. 命运，天命（control one's own destiny） | 2 |
| predictor | 本文：预测指标；n. 预测指标，预测因素（a strong/reliable predictor of） | 2 |
| foundation | 本文：根据；n. 基础，根基（lay the foundation(s) for；without foundation 毫无根据）；基金会 | 3 |
| precarious | 本文：并不牢靠；adj. 不稳固的，岌岌可危的（a precarious position/balance） | 3 |
| a few dozen | 本文：几十个；phr. 几十个（a few dozen people） | 3 |
| predominantly | 本文：主要；adv. 主要地，占多数地（a predominantly female/rural group） | 3 |
| faculty | 本文：教师；n. （大学）教师，全体教员（faculty members/staff）；能力，官能（mental faculties） | 3 |
| postgraduate | 本文：研究生；adj./n. 研究生（的）（a postgraduate student/course） | 3 |
| homogeneous | 本文：同质的；adj. 同质的，同类的（a homogeneous group/population） | 3 |
| privileged | 本文：优越的；adj. 有特权的，优越的（a privileged background/few） | 3 |
| scarcely | 本文：几乎不；adv. 几乎不，很难（can scarcely believe；scarcely…when 一……就） | 3 |
| ordinary | 本文：普通的；adj. 普通的，平常的（ordinary people/life；out of the ordinary 不寻常） | 3 |
| prosperous | 本文：富裕的；adj. 富裕的，繁荣的（a prosperous family/economy） | 3 |
| foster | 本文：既能培养；v. 培养，促进（foster talent/understanding）；收养；adj. 寄养的 | 3 |
| alike | 本文：二者兼顾；adv. 同样地，两者都（A and B alike） | 3 |
| conceptual | 本文：概念性的；adj. 概念上的（a conceptual framework/replication） | 4 |
| replication | 本文：重复实验；n. 复制，（研究）重复验证（replication of results/a study） | 4 |
| modified | 本文：调整过的；v. (modify) 修改，调整（modify a plan/method）；adj. 改良的（genetically modified） | 4 |
| diverse | 本文：多种不同的；adj. 多样的，形形色色的（a diverse population/range of；diverse backgrounds） | 4 |
| youngsters | 本文：儿童或青少年；n. (youngster) 少年儿童，年轻人（local youngsters） | 4 |
| assessed | 本文：评估；v. (assess) 评估，评定（assess the impact/a student） | 4 |
| link | 本文：关联性；n. 联系，关联（a link between A and B） | 4 |
| Adjusting for | 本文：调整；v. (adjust) 调整；（统计）校正（adjust for inflation/age；adjust to 适应） | 4 |
| cognitive | 本文：认知；adj. 认知的（cognitive ability/development/skills） | 4 |
| statistically | 本文：统计上；adv. 统计上（statistically significant/reliable） | 4 |
| insignificant | 本文：微不足道；adj. 不显著的；微不足道的（statistically insignificant；an insignificant amount） | 4 |
| worthless | 本文：毫无价值；adj. 毫无价值的（completely/virtually worthless） | 5 |
| reflect | 本文：反映；v. 反映，体现（reflect reality/a trend）；反射；reflect on 思考 | 5 |
| substantive | 本文：实质性的；adj. 实质性的，真实的（substantive changes/issues） | 5 |
| context | 本文：背景；n. 背景，来龙去脉；语境（in context；in the context of） | 5 |
| betrayed | 本文：辜负；v. (betray) 背叛，辜负（betray sb's trust 辜负信任；betray a secret 泄露秘密） | 5 |
| markedly | 本文：明显；adv. 明显地，显著地（differ markedly；markedly better/less） | 5 |
| peers | 本文：同龄人；n. (peer) 同龄人，同辈（peer pressure；compared with one's peers） | 5 |
| perseveres | 本文：坚持；v. (persevere) 坚持不懈（persevere in/with sth） | 5 |
| depends on | 本文：取决于；v. (depend on) 取决于，依赖（depend on the weather） | 5 |
| trustworthy | 本文：可信；adj. 值得信赖的，可靠的（a trustworthy friend/source） | 5 |

## 史实与来源
- 【T1/T2】20世纪60年代末至70年代初，斯坦福校园内幼儿园；约四五岁（文献口径3.5–5.5岁）；一份零食即吃，或独自等约15分钟（部分版本至20分钟）得两份。原实验零食不止棉花糖一种，正文写 one treat，不写"总是棉花糖"。属跨年时段，不标月。https://en.wikipedia.org/wiki/Stanford_marshmallow_experiment ；https://www.simplypsychology.org/?p=11458
- 【T3】追踪研究：1988年一篇在 Journal of Personality and Social Psychology（非 Developmental Psychology），正文只写 follow-ups，不点期刊；1990年 Developmental Psychology 26(6) 报告等待时长与 SAT 相关（正文以 tended to 对冲，写相关不写因果）。**1990年不写月份**：26(6) 期号对应 November 1990，但月份未在来源中直接核实，故只写年份。r≈0.42 不写。https://www.smith.edu/news/peake-on-marshmallow-test-studies/ ；https://scholarworks.smith.edu/psy_facpubs/79
- 【T4】进入 SAT 分析者仅约35–90人（口径不一），正文写 only a few dozen，不写数字；样本多为斯坦福教职员与研究生子女。"富裕家庭可能同时培养耐心与成绩"为混杂因素推断，正文以 may 对冲。来源同上。
- 【T5/T6】2018年5月（online 25 May 2018），Psychological Science：概念复制，NICHD 早期儿童照护与青少年发展研究中918名儿童（正文写 more than 900），4.5岁测等待、15岁测学业成绩。**缩小分两步**：①未控制时，双变量相关约为原研究一半（roughly half as strong）；②再控制家庭背景与早期认知能力后，相关缩小约三分之二，多数不显著（mostly statistically insignificant）。两步不得混写为"控制后减半"或"完全消失"。https://journals.sagepub.com/doi/10.1177/0956797618761661 ；https://neurosciencenews.com/marshmallow-test-delayed-gratification-9137/ ；https://conversableeconomist.com/2018/06/04/the-not-so-triumphant-return-of-the-marshmallow-test/
- 【T8】2013年1月（Cognition 126(1)，印刷版；online October 2012）：孩子亲身经历实验者失信（被许诺的更好材料未兑现）后，等待时间明显短于亲身经历守信者；正文写 children whose trust an adult had just betrayed，即孩子本人被失信，而非旁观。结尾据此只写"坚持多久部分取决于成人看起来是否可信"（depends partly on），不推出"坚持的孩子多已学会信任成人"之类泛化结论；"约4倍"不写。https://pmc.ncbi.nlm.nih.gov/articles/PMC3730121/ ；https://www.psychologytoday.com/us/blog/brain-babble/201210/kids-willpower-influenced-others-reliability
- 【不用 2020/2024】2020年 Psychological Science 用同一 NICHD 数据的预注册再分析（按原方法部分相关仍显著）及2020年原 Bing 样本中年追踪，月份未核，且写入需展开反方论证，超出篇幅；正文以 "may still reflect something substantive" 概括"缩小≠归零"。2024年 Child Development 26岁追踪月份未核，且正文不写成人结局；常见"2020年追至26–30岁"说法与事实不符。https://pmc.ncbi.nlm.nih.gov/articles/PMC7197218 ；https://anderson-review.ucla.edu/new-study-disavows-marshmallow-tests-predictive-powers/ ；https://psypost.org/an-iconic-psychology-test-just-took-a-massive-hit-to-its-credibility
- 【说明】正文不写人名、论文名与直接引语；体重、离婚率等轶事结论不写。
