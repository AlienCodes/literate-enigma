#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('In January 2018,', '2018年1月，'),
     ('Cape Town', '开普敦'),
     ('**issued**', '**发出了**(issued)'),
     ('a', '一则'),
     ('**stark**', '**严峻的**(stark)'),
     ('**alert**:', '**警报**(alert)，')]],
   [[('Day Zero', '称零日'), ('could arrive in April.', '可能在4月到来。')],
    '（Day Zero could arrive in April：冒号后补充说明 alert 的内容）\n'
    '（2018年初，南非开普敦发出了恐怖的警告：到了4月份，\n'
    '全城的水库可能就要彻底干涸，也就是“零日”要来了\n'
    '（届时全城将断水，只能排队领水）。）']]),
 (1,
  [[[('The term', '这个词'),
     ('**denoted**', '**指的是**(denoted)'),
     ('a', '一道'),
     ('**grim**', '**严酷的**(grim)'),
     ('**threshold**,', '**门槛**(threshold)：')]],
   [[('reached when', '即当'),
     ("water in the city's **reservoirs**,", '该市**水库**(reservoirs)的存水'),
     ('as a **percentage** of **capacity**,', '按占水库**容量**(capacity)的**百分比**(percentage)'),
     ('fell to', '降至'),
     ('13.5 per cent.', '13.5%时达到的门槛。')],
    '（reached when…：过去分词短语作后置定语，修饰 threshold；\nas a percentage of capacity：插入语）']]),
 (1,
  [[[('Most', '大部分'), ('**taps**', '**水龙头**(taps)'), ('would then', '届时将'), ('be shut,', '被关闭，')]],
   [[('and **residents**', '**居民**(residents)'),
     ('would **queue** at', '要到'),
     ('about 200', '约200个'),
     ('**designated**', '**指定的**(designated)'),
     ('collection points.', '取水点**排队**(queue)取水。')]]]),
 (2, [[[('The **prospect**', '这一**前景**(prospect)'), ('was', '是'), ('**genuine**.', '**真实存在的**(genuine)。')]]]),
 (2,
  [[[('Three **consecutive** years', '**连续**(consecutive)三年'),
     ('of **meagre** rainfall,', '**贫乏的**(meagre)降雨，'),
     ('from 2015 to 2017,', '从2015到2017年，')]],
   [[('had **diminished**', '**减少了**(diminished)'), ('the reservoirs', '水库的蓄水，')]],
   [[('serving', '这些水库给'),
     ('a', '一个'),
     ('**metropolitan area**', '**大都市区**(metropolitan area)供水，'),
     ('of about four million people.', '大约400万人口。')],
    '（serving…：现在分词短语作后置定语，修饰 reservoirs）']]),
 (2,
  [[[('By early 2018', '到2018年初，'),
     ('the **dams**', '**水库**(dams)'),
     ('were', '只剩'),
     ('**roughly**', '**约**(roughly)'),
     ('a fifth full.', '五分之一的蓄水。')]]]),
 (2,
  [[[('The **countdown**', '**倒计时**(countdown)'),
     ('turned', '把'),
     ('a', '一场'),
     ('**chronic**', '**长期的**(chronic)'),
     ('**shortage**', '**短缺**(shortage)')]],
   [[('into', '变成了'),
     ('an', '一个'),
     ('**imminent**', '**迫在眉睫的**(imminent)'),
     ('**deadline**.', '**最后期限**(deadline)。')],
    '（turn A into B：把 A 变成 B）']]),
 (3,
  [[[('The city', '该市'),
     ('paired', '把'),
     ('**mandatory**', '**强制性的**(mandatory)'),
     ('**restrictions**', '**限制措施**(restrictions)')]],
   [[('with', '与'),
     ('**unprecedented**', '**前所未有的**(unprecedented)'),
     ('**transparency**.', '**透明度**(transparency)结合起来。')],
    '（pair A with B：把 A 与 B 结合起来）\n'
    '（因为马上要全城断水，硬管怕老百姓暴乱，只能连哄带吓。\n'
    '强制手段：每人每天限用50升水，\n'
    '超额收十倍水费，不听话直接上门装限流器。\n'
    '透明度：每天公布水库真实水位和“断水倒计时”，\n'
    '吓得老百姓自己乖乖拼命省水。）']]),
 (3,
  [[[('From 1 February 2018,', '自2018年2月1日起，'),
     ('each', '每'),
     ('person', '人'),
     ('was **allotted**', '被**分配**(allotted)'),
     ('50 **litres** a day.', '每天50**升**(litres)水。')]]]),
 (3,
  [[[('**Officials**', '**官员们**(Officials)'),
     ('**disclosed**', '**公布**(disclosed)'),
     ('dam', '水库'),
     ('levels', '水位'),
     ('and', '和'),
     ('**household**', '**家庭**(household)'),
     ('**consumption**;', '**消耗量**(consumption)；')]],
   [[('the published', '公开的'),
     ('**tallies**', '**统计数字**(tallies)'),
     ('made', '让'),
     ('**thrift**', '**节俭**(thrift)成效'),
     ('**visible**', '**一目了然**(visible)，')],
    '（make A visible：使 A 一目了然）'],
   [[('and let', '也让'),
     ('neighbours', '邻里之间得以'),
     ('**benchmark**', '**对标**(benchmark)'),
     ('their use.', '他们的用水量。')],
    '（let sb do：让某人做……；\nlet 的主语仍是 the published tallies）']]),
 (3,
  [[[('Daily use', '日常的用水量'), ('was more than **halved**,', '**减少了一半**(halved)以上，')],
    '（more than halved：减半还不止）'],
   [[('from about 1.2 billion litres in 2015', '从2015年的约12亿升'),
     ('to about 500 million by early 2018.', '降至2018年初的约5亿升。')],
    '（from A to B：从 A 降到 B；\n500 million 后承前省略了 litres）']]),
 (4, [[[('Other forces', '其他力量也'), ('**intervened**.', '**介入了**(intervened)。')]]]),
 (4,
  [[[('In February 2018,', '2018年2月，'),
     ('**upstream**', '**上游的**(upstream)'),
     ('farmers', '农民'),
     ('released water from their **irrigation** dams;', '从他们的**灌溉**(irrigation)水坝中放出了水；')],
    '（release A from B：从 B 中放出 A）'],
   [[('with farms', '加上农场'),
     ('drawing', '用水'),
     ('less,', '减少，'),
     ('Day Zero', '零日'),
     ('was **postponed**', '被**推迟**(postponed)'),
     ('to July.', '到7月。')],
    '（with farms drawing less：with 复合结构作状语，\n表示伴随的原因）']]),
 (4,
  [[[('In March 2018,', '2018年3月，'),
     ('officials', '官员们'),
     ('judged', '判断'),
     ('Day Zero', '零日'),
     ('**unlikely**', '**不太可能**(unlikely)'),
     ('that year.', '在当年发生。')],
    '（judge A unlikely：判断 A 不太可能发生）\n（到了2018年3月，\n官方终于松了一口气，对外宣布：\n今年这“零日”（彻底断水）应该是不会发生了。）']]),
 (4,
  [[[('Winter rains', '冬雨'),
     ('**subsequently**', '**随后**(subsequently)'),
     ('**replenished**', '**重新装满了**(replenished)'),
     ('the **reservoirs**,', '各**水库**(reservoirs)，')]],
   [[('which were about half full by July.', '到7月时水库已约半满。')], '（which were…：非限制性定语从句，修饰 the reservoirs）']]),
 (4,
  [[[('The 50-litre', '50升的'),
     ('limit', '限额'),
     ('was **eased** in October 2018.', '于2018年10月**放宽**(eased)。')]]]),
 (5,
  [[[('The **burden**, critics argued,', '批评者认为，**负担**(burden)'),
     ('fell', '分配得'),
     ('**unevenly**.', '**并不均衡**(unevenly)。')],
    '（critics argued：插入语）']]),
 (5,
  [[[('**Townships**,', '**城镇区**(Townships)，'),
     ('poor areas **segregated** by race under **apartheid**,',
      '在**种族隔离制度**(apartheid)下按种族被**隔离**(segregated)出来的贫困地区，')],
    '（poor areas segregated…：同位语，补充说明 Townships；\nsegregated by race：过去分词短语作后置定语，修饰 areas）'],
   [[('had long', '长期以来就'),
     ('**made do with** **scant** water,', '**靠**(made do with)**很少的**(scant)水**勉强对付**(made do with)，')],
    '（make do with + 名词，意思是“靠……勉强凑合/将就着用”。）'],
   [[('yet', '然而'),
     ('**steeper**', '**更高的**(steeper)'),
     ('**tariffs**', '**水价**(tariffs)'),
     ('**squeezed** them hardest.', '最大程度地**压榨了**(squeezed)他们。')],
    '（them 指 Townships）']]),
 (5,
  [[[('Others', '另一些人则'),
     ('blamed', '责备'),
     ('**alarmist**', '**危言耸听的**(alarmist)'),
     ('warnings', '警告，'),
     ('for', '因为这些警告造成了'),
     ('tourist', '游客'),
     ('**cancellations**.', '**取消行程**(cancellations)。')],
    '（blame A for B：把 B 归咎于 A）']]),
 (5,
  [[[('Households,', '家庭、'),
     ('farmers,', '农民'),
     ('and rain', '和雨水'),
     ('kept', '让'),
     ('the collection points', '取水点'),
     ('**idle**,', '一直**闲置**(idle)，')],
    '（keep A idle：因为省水成功没断水，\n取水点没用上，一直闲置）'],
   [[('but', '但'),
     ('the **sacrifice**', '这份**牺牲**(sacrifice)'),
     ('weighed heaviest', '最沉重地落在了'),
     ('on those with the least to give.', '那些最没有能力付出的人身上。')],
    '（weigh on：压在……身上；\n'
    'with the least to give：后置定语，修饰 those）\n'
    '（简述：▸危机：连续三年少雨使南非开普敦水库告急。2018年初，当局警告，四月可能迎来大范围停水的“零日”。\n'
    '▸门槛：零日指蓄水降至总容量的13.5%，届时大部分水龙头关闭，居民必须到指定地点领水。\n'
    '▸节水：全市日用水量由2015年约12亿升降至2018年初约5亿升；2月起每人每日限用50升，并公开水位及用量。\n'
    '▸转机：居民节水、上游农民放水，以及农场减少取水，使零日一再推迟；随后冬雨补充水库，避免了当年大范围停水。\n'
    '▸负担：贫困社区原本用水就少，却最难承受上涨水价。批评者指出，危机虽被避开，节水代价并没有被公平分担。）']])]

out = {'no': '64',
 'title_en': 'The Day Zero That Never Came',
 'title_zh': '没有到来的零日',
 'title_fx': {'hl': ['Zero', 'Never'], 'ghost': []},
 'sentences': [],
 '核对确认': {'合组': {"S2 water in the city's reservoirs": "对齐不了：in the city's reservoirs 是后置定语，修饰 "
                                                      'water，中文“该市水库的存水”必须提前',
                 'S2 13.5 per cent': '对齐不了：per cent 就是“%”，拆开不通；句末“时达到的门槛”对应前面的 reached when（threshold, reached '
                                     'when…），中文定语“……时达到的”只能放到条件后面（用户 2026-11-08 定的译文）',
                 'S2 as a percentage of capacity': '对齐不了：of capacity 是 of 结构作后置定语，修饰 '
                                                   'percentage，中文“占水库容量的百分比”必须提前；两个重点词中文先后与英文相反（用户 2026-11-08 '
                                                   '定的译文）',
                 'S3 collection points': '对齐不了：collection points 是一个名词“取水点”；queue at '
                                         '中文“到……排队取水”，“排队取水”必须放到地点后面',
                 'S6 a fifth full': '对齐不了：a fifth full 是整体说法“五分之一满”，中文“五分之一的蓄水”拆开不通',
                 'S9 50 litres a day': '对齐不了：a day 中文“每天”必须放到数量前面',
                 'S13 released water from their irrigation dams': '对齐不了：release A from B 中文“从 B 中放出 '
                                                                  'A”，动词和宾语必须放到最后',
                 'S17 The burden, critics argued': '对齐不了：critics argued 是插入语，中文“批评者认为”必须放到句首，否则不通顺',
                 'S18 poor areas segregated by race under apartheid': '对齐不了：segregated by race under apartheid '
                                                                      '是过去分词短语作后置定语，修饰 '
                                                                      'areas，中文“在种族隔离制度下按种族被隔离出来的贫困地区”定语必须提前；两个重点词中文先后与英文相反',
                 'S18 made do with scant water': '对齐不了：make do with 是固定说法“靠……勉强对付”，被宾语隔开，中文只能整组',
                 'S20 the collection points': '对齐不了：collection points 是一个名词“取水点”，拆开不通',
                 'S20 weighed heaviest': '对齐不了：weigh heaviest on 中文“最沉重地落在……身上”，副词必须放到动词前面',
                 'S20 on those with the least to give': '对齐不了：with the least to give 是后置定语，修饰 '
                                                        'those，中文“那些最没有能力付出的人”必须提前',
                 'S5 of meagre rainfall': '对齐不了：meagre rainfall 中文“贫乏的降雨”，of 结构“三年的贫乏降雨”中文只能整组（用户 2026-11-08 '
                                          '定的译文）',
                 'S18 squeezed them hardest': '对齐不了：hardest 中文“最大程度地”必须放到动词前面，them 中文“他们”放到动词后面（用户 2026-11-08 '
                                              '定的译文）'},
          '对齐': {'S2-2 as a percentage of capacity,': 'of capacity 是 of 结构作后置定语，修饰 percentage，中文“占库容的百分比”必须提前',
                 "S2-2 water in the city's reservoirs": "in the city's reservoirs 是后置定语，修饰 "
                                                        'water，中文“该市水库的存水”必须提前',
                 'S2-2 as a percentage of capacit': 'of capacity 是 of 结构作后置定语，修饰 percentage，中文“占水库容量的百分比”必须提前',
                 'S5-3 of about four million people.': 'of about four million people 是 of 结构作后置定语，修饰 '
                                                       'area，中文“约400万人口”放在后面已顺着英文',
                 'S11-2 from about 1.2 billion litres ': 'in 2015 是后置的时间成分，中文“2015年的约12亿升”必须提前',
                 'S11-2 to about 500 million by early ': 'by early 2018 是后置的时间成分，中文“2018年初的约5亿升”必须提前',
                 'S13-1 released water from their irri': 'release A from B 中文“从 B 中放出 A”，动词和宾语必须放到最后',
                 'S15-2 which were about half full by ': '非限制性定语从句，by July 中文“到7月时”必须放到句首',
                 'S16-1 was eased in October 2018.': 'in October 2018 是后置的时间状语，中文时间必须放到动词前面（于2018年10月……）',
                 'S18-1 poor areas segregated by race ': '过去分词短语作后置定语，修饰 areas，中文定语必须提前',
                 'S18-2 made do with scant water,': 'make do with 是固定说法“靠……勉强对付”，被宾语隔开，只能整组',
                 'S20-2 on those with the least to giv': 'with the least to give 是后置定语，修饰 '
                                                         'those，中文“那些最没有能力付出的人”必须提前'},
          '方向': {'S11-1 more→减半有余，': 'more than halved 是“减半还不止”，中文“减半有余”的“有余”就是 more than，方向一致',
                 'S11-1 more→减少了一半以上，': 'more than halved 是“减半还不止”，中文“减少了一半以上”的“以上”就是 more than，方向一致（用户 '
                                        '2026-11-08 定的译文）'},
          '数字': {'S11-2 500': '500 million 即5亿（5×10⁸），中文按文章定稿写“约5亿升”，数值正确；英文读 five hundred million'},
          '是的': {'S4-1 是**真实存在的**': '文章定稿原文“这一前景是真实存在的”；genuine 是形容词作表语，“是……的”对应 was genuine，去掉“是”不通顺'},
          '短语': {'S2 reservoirs … of': '不是搭配：of 属于 a percentage of capacity，和 reservoirs 无关',
                 'S2 percentage … of': '不是搭配：as a percentage of capacity 是“占库容的百分比”，of capacity '
                                       '只是限定，percentage 单独就是“百分比”，速查表即此用法',
                 'S5 diminished … of': '不是搭配：of 属于 an area of about four million people，和 diminished 无关',
                 'S11 halved … from': '不是搭配：from…to… 只表示数值变化的起止，halve 单独就是“减半”',
                 'S11 halved … to': '不是搭配：from…to… 只表示数值变化的起止，halve 单独就是“减半”',
                 'S13 postponed … to': '不是搭配：to July 只表示推迟到的时间（被推迟到7月），postpone 单独就是“推迟”',
                 'S18 segregated … by': '不是搭配：by race 只表示隔离的依据（按种族），segregate 单独就是“隔离”',
                 'S18 segregated … with': '不是搭配：with 属于 made do with，和 segregated 无关',
                 'S18 under … apartheid': '不是搭配：under 只表示“在……制度下”，apartheid 单独就是“种族隔离制度”（速查表第一个意思）',
                 'S20 sacrifice … on': '不是搭配：on 属于 weighed heaviest on（压在……身上），和 sacrifice 无关',
                 'S20 sacrifice … to': '不是搭配：to 属于 the least to give，和 sacrifice 无关',
                 'S20 sacrifice … with': '不是搭配：with 属于 those with the least to give，和 sacrifice 无关',
                 'S2 The term denoted': '不是搭配：denote 速查表第一个意思就是“表示，指代”，“指的是”即此义',
                 'S5 meagre rainfall': '不是搭配：meagre 速查表第一个意思就是“少量的，不足的”，“降雨稀少”即此义',
                 'S8 mandatory restrictions': '不是搭配：mandatory 速查表第一个意思就是“强制的”，“强制性的”即此义',
                 'S18 under apartheid': '不是搭配：apartheid 速查表第一个意思就是“种族隔离制度”，under 只表示“在……下”',
                 'S2 capacity … to': '不是搭配：to 属于 fell to（降至），和 capacity 无关'},
          '停顿位置': {'S3 shut, / and @1.780': '2026-11-07 逐 2.5 ms 实测（S3 w）：shut 的 /t/ 除阻 1.70–1.76（-55～-62 '
                                            'dB、重心 2.2–3.5 kHz），1.76–1.90 静音（-62～-73 dB），1.90 起是吸气（低频 -9～-23 '
                                            'dB 无周期，被删静音和 非人声区间 去掉），2.157 起 and 的元音（-18 dB）；停顿 1.780 落在 /t/ '
                                            '之后的静音里，在两词之间',
                   'S17 argued, / fell @1.590': '2026-11-07 逐 2.5 ms 实测（S17 w）：argued 的 /d/ 浊音杠到 1.59（重心 '
                                                '0.3–0.4 kHz、周期 0.44–0.54），1.5925 是 -37 dB 低谷（重心 1.7 '
                                                'kHz），1.5975 起 fell 的 /f/（重心 5.3–7.5 kHz、低频 -20～-51 dB）；停顿 '
                                                '1.590 正落在 /d/ 与 /f/ 交界',
                   'S20 Households, / farmers, @0.950': '2026-11-07 逐 10 ms 实测（S20 w）：Households 的 /z/ 衰减到 '
                                                        '0.91（-39 dB），0.915–0.965 低谷（-45～-49 dB），0.97 起 '
                                                        'farmers 的 /f/ 渐强（-41→-25 dB），1.095 起元音；停顿 0.950 '
                                                        '落在两词之间的低谷',
                   'S20 farmers, / and @1.670': '2026-11-07 逐 2.5 ms 实测（S20 w）：farmers 的 /z/ 到 1.665（重心 4–5.4 '
                                                'kHz），1.670 是 -27 dB 低谷（重心 3 kHz），1.675 起 and 的 æ（周期 0.5、-10.9 '
                                                'dB）；停顿插入点 1.66975 在两词交界'},
          '删除段': {'S1 raw 1.9841-2.2300': {'类型': '紧贴词尾的非人声',
                                           '配音指纹': '15344c1da0c6',
                                           '依据': '2026-11-07：2018, 后停顿里的吸气：自动切点 非人声区间 S1 [1.974083, 2.125, '
                                                 '紧贴词尾]（程序可定），eighteen 的 n 衰减和吸气之间没有 -55 dB '
                                                 '低谷，起点切在过零点、词本身不动；删掉的最响 -40.4 dB'},
                  'S3 raw 1.8050-2.1516': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '15344c1da0c6',
                                           '依据': '2026-11-07：逐 2.5 ms 实测（S3 w）：shut 的 /t/ 除阻到 1.76，1.76–1.90 '
                                                 '静音，1.90–2.12 是吸气（-38～-60 dB、低频 -9～-23 dB、无周期），一直连到 and '
                                                 '前的浊音起始，中间没有 -55 dB 低谷；自动切点 非人声区间 [1.945, 2.121583, '
                                                 '紧贴词头]，终点切在过零点，and 的元音（2.157 起）不动'},
                  'S7 raw 2.1625-2.3271': {'类型': '紧贴词尾的非人声',
                                           '配音指纹': '15344c1da0c6',
                                           '依据': '2026-11-07：逐 2.5 ms 实测（S7 w）：shortage 的 /dʒ/ 衰减到 2.1425（-55 '
                                                 'dB，没有更低的低谷），2.145–2.305 是吸气（-42～-55 dB、低频 -11～-26 dB、重心 '
                                                 '2.5–3.9 kHz，160 ms，shortage into 之间无标点）；非人声区间 [2.1425, '
                                                 '2.307125, 紧贴词尾]，起点在过零点'},
                  'S10 raw 6.4250-6.7384': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '15344c1da0c6',
                                            '依据': '2026-11-07：visible 和 and 之间的吸气：自动切点 非人声区间 S10 [6.445, '
                                                  '6.728458, 紧贴词头]（程序可定），吸气与 and 的起音之间没有 -55 dB '
                                                  '低谷，终点切在过零点、词本身不动；删掉的最响 -38.9 dB'},
                  'S11 raw 6.4228-6.7900': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '15344c1da0c6',
                                            '依据': '2026-11-07：2015 后的吸气：自动切点 非人声区间 S11 [6.412833, 6.76, '
                                                  '紧贴词尾]（程序可定），fifteen 的 n 衰减和吸气之间没有 -55 dB '
                                                  '低谷，起点切在过零点、词本身不动；删掉的最响 -37.1 dB'},
                  'S13 raw 1.9550-2.1750': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '15344c1da0c6',
                                            '依据': '2026-11-07：2018, 后停顿里的吸气：自动切点 非人声区间 S13 [1.935, 2.153625, '
                                                  '紧贴词头]（程序可定），两侧 -56.9 / -59.7 dB；删掉的最响 -37.9 dB 是吸气'},
                  'S16 raw 1.1900-1.4500': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '15344c1da0c6',
                                            '依据': '2026-11-07：limit 后的吸气：自动切点 非人声区间 S16 [1.26, 1.42]，删到 was 的 '
                                                  '/w/ 浊音起始前（1.43–1.45 -49～-57 dB、低频占比 -0.6 dB、周期 0.28–0.35，已在 '
                                                  '核对确认.非人声 写为词头），中间没有 -55 dB 低谷；删掉的最响 -46.2 dB'},
                  'S16 raw 3.7200-3.7299': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '15344c1da0c6',
                                            '依据': '2026-11-07：句末 2018. 之后 10 ms 的残尾（最响 -55.1 '
                                                  'dB，已在听不见的边上），eighteen 的 n 衰减到这里没有更低的低谷；删掉的不到 -55 dB，词本身不动'},
                  'S20 raw 4.0451-4.5700': {'类型': '紧贴两头的非人声',
                                            '配音指纹': '15344c1da0c6',
                                            '依据': '2026-11-07：逐 10 ms 实测（S20 w）：idle, 的 l 衰减到 4.29（-55 '
                                                  'dB），4.30–4.465 是吸气（-45～-56 dB、低频 -11～-30 dB、重心 2.0–2.6 '
                                                  'kHz），4.475–4.515 一团低频杂音（-35～-49 dB），4.52–4.55 静音，4.555 起 '
                                                  'but；非人声区间 [4.300583, 4.536708] 换成静音后，停顿补成标准长度'}},
          '非人声': {'5.66–5.67s': {'配音指纹': '15344c1da0c6',
                                 '依据': 'S1 w 2.48–2.495s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：Cape 的 '
                                       '/k/ 先爆出一下（15 ms，-27 dB、重心 4 kHz、无周期），闭塞 30 ms（-61～-69 dB）后 2.53 '
                                       '再爆出送气（重心 4–6 kHz）接 eɪ；/k/ 的两次除阻，词头的一部分',
                                 '实测': {'最响dB': -30.3, '重心Hz': 3965, '周期': 0.0, '低频dB': -23.0}},
                  '18.77–18.79s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S2 w 7.41–7.425s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：fell '
                                         '的 /f/ 起始（-53 dB 弱噪声，7.425 起连续增强到 -44 dB、重心 4.3–6.1 kHz），与 /f/ '
                                         '之间没有低谷；词头的一部分',
                                   '实测': {'最响dB': -53.0, '重心Hz': 3412, '周期': 0.0, '低频dB': -1.2}},
                  '21.30–21.36s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S2 w 9.94–9.995s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：句末 '
                                         'cent. 的 /t/ 除阻：9.92–9.935 闭塞 -64～-69 dB，9.94 爆出（-31 dB、重心 2.7–3.7 '
                                         'kHz），55 ms 衰减到 -60 dB；词尾塞音除阻',
                                   '词尾': 't',
                                   '实测': {'最响dB': -30.5, '重心Hz': 3538, '周期': 0.13, '低频dB': -10.0}},
                  '24.52–24.54s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S3 w 2.12–2.14s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 '
                                         'w）：紧接在非人声区间（1.945–2.1216，程序判紧贴词头）之后，-47～-54 dB、低频占比 -0.2～-2 dB、周期 '
                                         '0.4，2.14–2.155 增强到 -40 dB，2.157 接 and 的元音；and 元音前的浊音起始，词头的一部分',
                                   '实测': {'最响dB': -47.1, '重心Hz': 2618, '周期': 0.41, '低频dB': -0.3}},
                  '35.95–35.96s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S5 w 3.04–3.055s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：from '
                                         '的 /f/ 起始（-51 dB，3.055 起连续增强到 -41 dB、重心 3.9–5.5 kHz），与 /f/ '
                                         '之间没有低谷；词头的一部分',
                                   '实测': {'最响dB': -51.4, '重心Hz': 2394, '周期': 0.0, '低频dB': -0.2}},
                  '53.19–53.22s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S7 w 2.31–2.34s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：into '
                                         '前的浊音起始：-48～-53 dB、低频占比 -1.3～-1.8 dB、周期 0.2–0.46，2.3475 起增强到 -36→-16 '
                                         'dB 接 ɪ，与元音之间没有低谷；前面吸气已用非人声区间去掉；词头的一部分',
                                   '实测': {'最响dB': -47.3, '重心Hz': 2908, '周期': 0.4, '低频dB': -1.5}},
                  '60.63–60.72s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S8 w 4.815–4.895s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：句末 '
                                         'transparency. 的 i 清化收尾：元音 4.78（-20 dB）后 -31～-48 dB 连续衰减到 4.885 -54 '
                                         'dB，中间没有 -55 dB 低谷，重心 2.7–4 kHz 同 i 的高共振峰，低频 -2～-15 dB；词尾的一部分',
                                   '实测': {'最响dB': -35.7, '重心Hz': 3332, '周期': 0.25, '低频dB': -3.1}},
                  '60.66–60.68s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S8 w 4.845–4.86s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：同上 '
                                         'transparency. 的 i 清化收尾中间一段（-36～-40 dB），在连续衰减里；词尾的一部分',
                                   '实测': {'最响dB': -38.0, '重心Hz': 3763, '周期': 0.0, '低频dB': -2.2}},
                  '78.33–78.34s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S11 w 0.015–0.03s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：句首 '
                                         'Daily 的 /d/ 浊音杠起始：0.015 -52.7 → 0.025 -33.5 dB（重心 435 Hz、周期 '
                                         '0.43），0.035 起 -25 dB 重心 316 Hz，一直连到 eɪ；词头的一部分',
                                   '实测': {'最响dB': -31.8, '重心Hz': 817, '周期': 0.0, '低频dB': -2.0}},
                  '80.18–80.30s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S11 w 1.865–1.98s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 '
                                         'w）：halved 词内：1.85–1.91 /v/ 浊音（-31～-39 dB、重心 1.4–2.2 kHz、周期 '
                                         '0.2–0.4），1.92–1.965 /v/ 清化擦音（重心 4.8–5.1 kHz），1.97 /d/ 除阻（-35.7 '
                                         'dB），1.98 起 -56 dB；都是 halved 的一部分',
                                   '实测': {'最响dB': -35.1, '重心Hz': 3968, '周期': 0.15, '低频dB': -2.9}},
                  '80.21–80.23s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S11 w 1.895–1.92s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 '
                                         'w）：halved 的 /v/ 浊音段（-38～-45 dB、周期 0.45、重心 1.4–1.8 kHz）；词的一部分',
                                   '实测': {'最响dB': -38.5, '重心Hz': 1874, '周期': 0.45, '低频dB': -0.7}},
                  '88.51–88.61s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S11 w 10.385–10.49s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：句末 '
                                         'eighteen. 的 n 鼻音收尾：-30～-40 dB（周期 0.3–0.51、重心 0.95–2 kHz），10.44 一下 '
                                         '-57.5 dB 小凹，之后 45 ms 仍是周期 0.35–0.51 的浊音余振（-45～-56 dB），衰减到 -66 '
                                         'dB；词尾的一部分',
                                   '实测': {'最响dB': -35.1, '重心Hz': 1982, '周期': 0.27, '低频dB': -5.1}},
                  '98.16–98.17s': {'配音指纹': '15344c1da0c6',
                                   '依据': 'S13 w 5.685–5.70s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：dams '
                                         '的 /d/ 浊音杠起始：irrigation 的 n 衰减到 5.685（-54 dB），5.695 起 -34 dB（重心 0.8–1 '
                                         'kHz、周期 0.37–0.42）连到 æ；词头的一部分',
                                   '实测': {'最响dB': -36.4, '重心Hz': 1199, '周期': 0.0, '低频dB': -2.2}},
                  '103.38–103.47s': {'配音指纹': '15344c1da0c6',
                                     '依据': 'S13 w 10.89–10.985s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 '
                                           'w）：句末 July. 的 aɪ 气声收尾：10.875–10.885 -35 dB 起 -37～-51 dB 连续衰减到 '
                                           '10.985 -60 dB，中间没有低谷，低频 -4～-11 dB；词尾的一部分',
                                     '实测': {'最响dB': -35.7, '重心Hz': 2819, '周期': 0.22, '低频dB': -5.5}},
                  '114.41–114.44s': {'配音指纹': '15344c1da0c6',
                                     '依据': 'S15 w 3.685–3.72s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 '
                                           'w）：which 的 /w/ 浊音起始：-49～-52 dB、低频占比 -0.6～-1.6 dB、周期 0.32–0.37，3.73 '
                                           '起 -38 dB（重心 1.4 kHz）接 ɪ，与词之间没有低谷；词头的一部分',
                                     '实测': {'最响dB': -49.7, '重心Hz': 2716, '周期': 0.36, '低频dB': -0.6}},
                  '118.92–118.94s': {'配音指纹': '15344c1da0c6',
                                     '依据': 'S16 w 1.43–1.45s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：was '
                                           '的 /w/ 浊音起始：-51～-57 dB、低频占比 -0.6～-0.8 dB、周期 0.28–0.35，1.46 起 -49.8 '
                                           'dB 渐强接元音；词头的一部分',
                                     '实测': {'最响dB': -49.4, '重心Hz': 2328, '周期': 0.25, '低频dB': -0.3}},
                  '136.69–136.75s': {'配音指纹': '15344c1da0c6',
                                     '依据': 'S18 w 9.16–9.215s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_64，S 句 w）：句末 '
                                           'hardest. 的 /t/ 除阻：9.14–9.15 闭塞 -67～-69 dB，9.16 爆出（-35.7 dB、重心 '
                                           '2.4–3.6 kHz），55 ms 衰减到 -75 dB；程序已对这段做除阻加强；词尾塞音除阻',
                                     '词尾': 't',
                                     '实测': {'最响dB': -33.6, '重心Hz': 3218, '周期': 0.18, '低频dB': -12.5}}},
          '机器复听': {'S3': {'配音指纹': '15344c1da0c6',
                          '依据': '2026-11-07 逐 10 ms 实测（S3 w）：queue 的 /kj/ 3.06–3.11（送气重心 5.5 kHz），uː '
                                '3.11–3.27（重心 1.8→0.75 kHz），3.31 起 æ（重心 1.5 kHz、周期 0.5），at 的 /t/ 与 about '
                                '连读成闪音（3.46–3.47 一下 -17～-20 dB 小凹），美式 æɾ əbaʊt；识别器把连读的 at 听成 air / qr，读音没错'},
                   'S9': {'配音指纹': '15344c1da0c6',
                          '依据': '2026-11-07：litres 配音 lˈiːɾɚz（已核实读音：美式 t 闪音化），和 leaders /liːdɚz/ 只差闪音 ɾ 与 '
                                'd，识别器拼成 leaders；读音按已核实读音，非读错'},
                   'S10': {'配音指纹': '15344c1da0c6',
                           '依据': '2026-11-07：disclosed dam 两个 /d/ 相邻，disclosed 的词尾 /d/ 与 dam 的 /d/ '
                                 '连成一个长闭塞（英语正常连读），识别器只听出 disclose；tallies 配音 tˈælɪz，small.en 听对，parakeet 拼成 '
                                 'talas；读音没错'},
                   'S11': {'配音指纹': '15344c1da0c6',
                           '依据': '2026-11-07：litres 配音 lˈiːɾɚz（已核实读音：美式 t 闪音化），识别器拼成 leaders（同 '
                                 'S9）；读音按已核实读音，非读错'}},
          '们': {'S10-1 **官员们**': '用户 2026-11-08 原话把 Officials 标成重点词，画面原译“官员们”，复数 officials 译“官员们”通顺'},
          '即': {'S2-2 即': '用户 2026-11-08 原话定的译文“即当该市水库的存水……时达到的门槛”，用“即”引出对 threshold 的说明'},
          '中文重复': {'水库': 'dams 和 reservoirs 本文都指开普敦的蓄水水库（南非英语把水库叫 dams），画面原译都是“水库”；用户 2026-11-08 只要求把 dams '
                         '标成重点词、没给新译文，已发中文不改（守则4），建议改“水坝”已提给用户'},
          '同词异译': {'made do with：勉强对付/靠': '用户本轮明确made do '
                                          'with整体重点，对应中文靠与勉强对付两个分离片段。两处表达同一个靠现有少量资源凑合使用的意思，中间保留scant '
                                          'water对象，按同一个key显示。'}},
 '结尾解说': '简述',
 '高亮按实际开口': True,
 '高亮开口门槛': 40,
 '术语': {'Cape Town': '开普敦', 'Day Zero': '零日'},
 '停顿插入点': {'S20': {'2': 1.66975}},
 '非人声区间': {'S1': [[1.974083, 2.125, '紧贴词尾']],
           'S3': [[1.945, 2.121583, '紧贴词头']],
           'S5': [[2.86, 3.03]],
           'S8': [[2.44, 2.69], [2.71, 2.725]],
           'S10': [[6.445, 6.728458, '紧贴词头']],
           'S11': [[6.412833, 6.76, '紧贴词尾']],
           'S13': [[1.935, 2.153625, '紧贴词头']],
           'S18': [[3.77, 4.075]],
           'S16': [[1.26, 1.42]],
           'S6': [[1.695, 1.960708]],
           'S7': [[2.1425, 2.307125, '紧贴词尾']],
           'S20': [[4.300583, 4.536708]]},
 '段内渐变dB': {'S16': {'1': [-2.0, 3.0]}, 'S14': {'2': [0.0, 2.0]}},
 'allow_clash': ['capacity',
                 'dams',
                 'roughly',
                 'litres',
                 'taps',
                 'queue',
                 'metropolitan area',
                 'deadline',
                 'reservoirs',
                 'made do with'],
 '结尾句': {'S20': {'前段语速': 0.9,
                 '最后一段语速': 0.78,
                 '最后一段前停顿': 0.7,
                 '接点': [99660, 130260],
                 '依据': '全篇结尾句按 07 定下的标准（用户 2026-10-10 同意并要求所有视频统一）：前段 0.9、最后一段“but the sacrifice weighed '
                       'heaviest on those with the least to give.” 0.78、前面停 0.7 秒。接点由 结尾句接点.py 自动找：0.9 '
                       '那遍最后一个标点后最长静音（225 ms）的正中 4.152 s，0.78 那遍（345 ms）的正中 5.428 s，所在帧和两侧各 5 ms 都低于 -55 '
                       'dB（程序以 08 校准：与人工核实的接点落在同一段静音里）'}},
 '词尾除阻': {'S3': {'1': [1.705, 't']}, 'S18': {'2': [3.755, 't']}},
 '除阻加强': {'S18': {'句末': [9.16, 9.215, 5.0]}},
 '区间声音指纹': {'S1': '644e5e1ebfa2',
            'S3': '237a600527d7',
            'S5': '8b4777acfe22',
            'S6': 'f05082d44886',
            'S7': '77af1c0ec0ed',
            'S8': '72a23c55e9d8',
            'S10': 'f8de2f5a5367',
            'S11': '0b7e4020d940',
            'S13': 'd8c48eecedfe',
            'S16': '0214a8574a5f',
            'S18': '77a56041e6cc',
            'S20': '81eb6326ab8a'},
 '连线': ['reached', '达到的门槛'],
 '正常分栏连线': True,
 '重点词颜色': {'scant': '#38BDF8'}}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
