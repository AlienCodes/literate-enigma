#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('In 1925', '1925年，'),
     ('six', '六名'),
     ('**scrap-metal**', '经营**废金属**(scrap-metal)的'),
     ('**traders**', '**商人**(traders)'),
     ('met **secretly** at the Hôtel de Crillon in Paris.', '在巴黎的克里雍酒店**秘密地**(secretly)会面了。')],
    '（at the Hôtel de Crillon in Paris：地点状语，中文提到动词前）']]),
 (1,
  [[[('A **deputy**', '邮电部的一位**副的**(deputy)'),
     ('**director-general** of the Ministry of Posts and Telegraphs', '**总负责人**(director-general)'),
     ('shared the **momentous** news, **confidentially**,',
      '向他们**私下地**(confidentially)分享了一个**重大的**(momentous)消息，')],
    '（of the Ministry…：介词短语作后置定语；\nconfidentially：插入的副词，修饰 shared）'],
   [[('that the Eiffel Tower was to be sold for **scrap**.', '埃菲尔铁塔将作为**废铁**(scrap)出售。')],
    '（that…：同位语从句，说明 news 的内容；\nbe to be done：将要被……）']]),
 (1,
  [[[('He', '他'),
     ('invited', '请他们'),
     ('**tenders**', '**投标**(tenders)，'),
     ('and made', '并让'),
     ('each dealer', '每位商人'),
     ('**solemnly**', '**郑重地**(solemnly)'),
     ('**vow**', '**发誓**(vow)'),
     ('**secrecy**,', '要**保密**(secrecy)，')],
    '（make sb do：让某人做……；vow secrecy：发誓保密）'],
   [[('**ostensibly**', '**表面上**(ostensibly)'),
     ('to spare', '是为了避免引起'),
     ('the **public indignation**.', '**公愤**(public indignation)。')],
    '（to spare…：不定式表目的；spare sb sth：使某人免受……）']]),
 (2, [[[('The **pretext**', '这个**借口**(pretext)'), ('was not', '并不'), ('**absurd**.', '**荒唐**(absurd)。')]]]),
 (2,
  [[[('Built', '这座'),
     ("for the 1889 World's Fair,", '为1889年世博会而建的'),
     ('the **monument**', '**纪念建筑**(monument)，')],
    '（Built for…：过去分词短语，补充说明 the monument）'],
   [[('had **originally**', '**原本**(originally)就'),
     ('been **destined**', '**注定**(destined)'),
     ('to **come down** after twenty years.', '要在二十年后**拆除**(come down)。')],
    '（be destined to do：注定要……；come down：被拆除）']]),
 (2,
  [[[('The **high-ranking**', '那位**位高权重的**(high-ranking)'),
     ('deputy', '副总长'),
     ('was', '正是'),
     ('Victor Lustig,', '维克多·卢斯蒂格，')]],
   [[('a **crook**', '一个**骗子**(crook)，'),
     ('whose', '他的那些'),
     ('**ministerial**', '**部长的**(ministerial)'),
     ('**stationery**', '**信笺**(stationery)'),
     ('was a **forgery**.', '都是**伪造品**(forgery)。')],
    '（a crook：同位语，说明 Victor Lustig；\nwhose…：定语从句，修饰 crook）']]),
 (2,
  [[[('He had read', '他曾读到过'),
     ('a newspaper article', '报纸上的一篇文章，'),
     ('in which', '文中'),
     ('the authorities', '当局'),
     ('**lamented**', '**哀叹**(lamented)')],
    '（in which…：定语从句，修饰 article）'],
   [[("the **hefty cost** of the tower's **upkeep**.", '铁塔**维护**(upkeep)的**高昂费用**(hefty cost)。')],
    '（hefty：（数目，数量）相当大的）']]),
 (3,
  [[[('André Poisson,', '安德烈·普瓦松，'),
     ('a **businessman**', '一个**生意人**(businessman)，'),
     ('**impatient**', '**迫不及待地**(impatient)'),
     ('to **gain a foothold** in Paris,', '想在巴黎**拥有一席之地**(gain a foothold)，'),
     ('won.', '中标了。')],
    '（a businessman…：同位语，说明 André Poisson；\nimpatient to do：急于做……，形容词短语作后置定语；\ngain a foothold：站稳脚跟）']]),
 (3,
  [[[('Lustig', '卢斯蒂格'),
     ('**intimated**', '**暗示**(intimated)，'),
     ('that his modest', '他那份微薄的'),
     ('**civil-service**', '**公务员**(civil-service)'),
     ('**remuneration**', '**薪酬**(remuneration)'),
     ('needed', '需要'),
     ('**supplementing**,', '**补贴**(supplementing)，')],
    '（that…：宾语从句；need doing：需要被……，主动形式表被动）'],
   [[('and Poisson', '普瓦松然后'),
     ('paid', '付了'),
     ('an **additional**', '一笔**额外的**(additional)'),
     ('**bribe**.', '**贿赂**(bribe)。')]]]),
 (3,
  [[[('Lustig', '卢斯蒂格'), ('left for Vienna with the **takings**.', '带着这笔**进账**(takings)去了维也纳。')],
    '（leave for：动身前往）']]),
 (4,
  [[[('**Fleeced**', '被**骗走**(Fleeced)钱财，'),
     ('and too **ashamed**', '又实在太**丢人**(ashamed)、'),
     ('to go to the police,', '**没脸**(ashamed)去报警，')],
    '（Fleeced and too ashamed…：过去分词与形容词并列作状语；\ntoo…to…：太……而不能……；go to the police：报警）'],
   [[('Poisson', '普瓦松'), ('swallowed the loss **quietly**.', '只能**默默地**(quietly)咽下这笔损失。')]]]),
 (4,
  [[[('Not a **whisper** of the **deceit**', '关于这场**骗局**(deceit)的半点**风声**(whisper)'),
     ('appeared in print.', '报纸上没有出现。')],
    '（Not a…：一点……都没有；in print：见报，在报刊上）']]),
 (5,
  [[[('About a month later', '大约一个月后，'),
     ('Lustig', '卢斯蒂格'),
     ('**had the gall to**', '**厚颜无耻地去**(had the gall to)'),
     ('**reappear**', '**再一次出现**(reappear)，')],
    '（have the gall to do：竟厚着脸皮做……）'],
   [[('with an **encore**', '对新的一批商人**重演**(encore)'),
     ('of his', '他那套'),
     ('**script** for new dealers.', '**剧本**(script)。')],
    '（an encore of…：……的重演）']]),
 (5,
  [[[('This time', '这一次，'),
     ('the winner', '那位中标者'),
     ('**grew distrustful**', '**起了疑心**(grew distrustful)，'),
     ('and went to the police.', '报了警。')],
    '（distrustful of：怀疑…，对…不相信，认为…靠不住）\n（常与 of 连用，表示对……不信任或怀疑）']]),
 (5,
  [[[('The **affair**', '这桩**事件**(affair)'),
     ('made the papers,', '上了报纸，'),
     ('and Lustig', '卢斯蒂格'),
     ('made his **getaway**.', '**逃之夭夭**(getaway)。')],
    "（make the papers：上报纸；\nmake one's getaway：逃走）"]]),
 (5,
  [[[('The **much-repeated**', '那个**被反复提及的**(much-repeated)'),
     ('second sale', '第二次出售，'),
     ('is', '只是'),
     ('a **fairy tale**.', '个**童话**(fairy tale)。')]]]),
 (6,
  [[[('Later', '后来，'),
     ('arrested in the United States', '卢斯蒂格在美国被捕，'),
     ('for making', '因为制造'),
     ('**fake** money,', '**假**(fake)币，')],
    '（Later arrested…：过去分词短语作状语，主语是 Lustig）'],
   [[('Lustig', '他'),
     ('broke out of **detention**,', '在**关押**(detention)（期间）越狱，'),
     ('was **recaptured** 27 days later', '27天后又被**抓回**(recaptured)，'),
     ('and **served time** on the **penal** island of Alcatraz.',
      '并在恶魔岛这座“**刑罚**(penal)之岛”上**服刑**(served time)。')],
    '（broke out of、was recaptured、served time：三个并列谓语；\nbreak out of：从……逃出；serve time：服刑）']]),
 (6, [[[('He died of pneumonia in 1947.', '1947年，他死于肺炎。')]]]),
 (7,
  [[[("Of Lustig's two marks,", '卢斯蒂格的两个目标中，'),
     ('the one who paid', '付了钱的那个'),
     ('**kept mum**', '**守口如瓶**(kept mum)，')]],
   [[('and the one who kept his money', '保住了钱的那个则'), ('went to the police.', '去报了警。')],
    '（Of…：在……之中；marks：行骗对象；keep mum：闭口不言）\n'
    '（简述：▸冒充：1925年，卢斯蒂格伪造公文、冒充邮电部官员，邀六名废金属商秘密投标，谎称埃菲尔铁塔要卖废铁。▸借口：铁塔原拟在世博会20年后拆除，维护费又高；卢斯蒂格利用这些真背景，并以免引公愤为由要求保密。▸得手：急于在巴黎立足的普瓦松付了购塔款和贿赂，受骗后却羞于报警，让卢斯蒂格带钱逃走。▸再骗：约一月后，卢斯蒂格重演骗局，新买家起疑报警且未付款；所谓第二次卖成铁塔的故事并不成立。▸下场：卢斯蒂格后来在美国因造假币被捕，越狱27天后再落网，在恶魔岛监狱服刑，1947年死于肺炎。）']])]

out = {'no': '21',
 'title_en': 'The Man Who Sold the Eiffel Tower Twice',
 'title_zh': '两次卖掉埃菲尔铁塔的骗子',
 'title_fx': {'hl': ['Eiffel', 'Twice'], 'ghost': []},
 'sentences': [],
 '核对确认': {'对齐': {'S1-1 met secretly at the Hôtel de C': '地点状语 at the Hôtel de Crillon in Paris '
                                                        '中文必须提到动词前（在巴黎的克里雍酒店秘密地会面了），拆开中文不通',
                 'S2-1 A deputy director-general of t': 'of 结构：of the Ministry of Posts and Telegraphs '
                                                        '中文必须提前（邮电部的一位副的总负责人）',
                 'S2-1 shared the momentous news, con': '插入的 confidentially 中文要提到动词前（向他们私下地分享了），拆开语序不通',
                 'S2-2 that the Eiffel Tower was to b': '被动不定式 was to be sold for scrap 中文“将作为废铁出售”里 for scrap '
                                                        '提到动词前，拆开不通',
                 "S5-1 for the 1889 World's Fair,": '一个介词短语意群（为……而建的），中文“为1889年世博会而建的”拆开不成词',
                 'S5-2 to come down after twenty year': '时间状语 after twenty years 中文提到动词前（要在二十年后拆除）',
                 "S7-2 the hefty cost of the tower's ": "of 结构：of the tower's upkeep 中文提前（铁塔维护的高昂费用）",
                 'S8-1 to gain a foothold in Paris,': '地点状语 in Paris 中文提到动词前（想在巴黎拥有一席之地）',
                 'S10-1 left for Vienna with the takin': '伴随状语 with the takings 中文提到动词前（带着这笔进账去了维也纳）',
                 'S11-1 to go to the police,': 'go to the police 是固定说法（报警），没脸去报警 不能拆',
                 'S12-1 Not a whisper of the deceit': 'of 结构：of the deceit 中文提前（关于这场骗局的半点风声）',
                 'S13-2 with an encore of his script f': '介词短语 for new dealers 中文提前（对新的一批商人重演他那套剧本），拆开不通',
                 'S14-1 and went to the police.': 'went to the police 是固定说法（报了警），不能拆',
                 'S17-1 arrested in the United States': '地点状语 in the United States 中文提到动词前（卢斯蒂格在美国被捕）',
                 'S17-2 was recaptured 27 days later': '时间状语 27 days later 中文提到动词前（27天后又被抓回）',
                 'S17-2 and served time on the penal i': '地点状语 on the penal island of Alcatraz '
                                                         '中文提到动词前（并在恶魔岛这座“刑罚之岛”上服刑）',
                 'S18-1 He died of pneumonia in 1947.': '时间状语 in 1947 中文提到句首（1947年，他死于肺炎）',
                 'S19-2 and the one who kept his money': '定语从句 who kept his money 中文提到名词前（保住了钱的那个则）',
                 'S2-1 director-general of the Minist': 'of 结构后置定语：“of the Ministry of Posts and '
                                                        'Telegraphs”的中文“邮电部的”必须提前到句首（中文语序倒过来），只能放在前一组；deputy、director-general '
                                                        '两个重点词各在自己的英文正下方（T34 拆开后）'},
          '词性': {'S8-1 impatient 迫不及待地': 'impatient 是 adj.，中文“迫不及待地”作状语修饰后面的“想”（迫不及待地想在巴黎拥有一席之地），用户 2026-10-22 '
                                         '定的译文（待改清单第6条），状语用“地”'},
          '同词异译': {'ashamed：丢人/没脸': '不是两种译法：用户 2026-10-22 原话“又实在太丢人、没脸去报警”，ashamed 的意思分在“丢人”“没脸”两处，按 T23 '
                                    '意思标全，两处标同一个英文（待改清单第9条）'},
          '引号': {'S17-2 “”': '用户 2026-10-22 原话“并在恶魔岛这座“刑罚之岛”上服刑”自带引号，照用户原话保留（待改清单第17条）'},
          '已告诉用户被去掉的重点词': '2026-10-22 已在会话中把 secretly（与03 secretion 同根撞词，从21去掉）原样告诉用户，并说明69的 confidential '
                          '改回普通词',
          '们': {'S2-1 **(director-general)向他们**': '们不在加粗里，是代词“他们”（指六名商人），沿用文章定稿“向他们私下分享”；被报出只因紧跟在 '
                                                  '**总负责人**(director-general) 后面'},
          '短语': {'S2 director-general … of': 'of the Ministry of Posts and Telegraphs '
                                             '是普通后置定语（邮电部的），director-general 本身就是“总长”，不是短语型用法',
                 'S5 destined … to': 'to 是不定式符号（to come down），不是介词；destined 本身就是“注定的”，中文“注定要……”已把意思说全',
                 'S8 impatient … to': 'to 是不定式符号（to gain a foothold），不是介词；impatient 本身就是“急切的”，中文“迫不及待地想……”已说全',
                 'S8 foothold … in': 'in Paris 是普通地点状语（在巴黎），gain a foothold 的意思靠 foothold 本身（立足点），介词随地点换（in '
                                     'the market），不是短语型用法',
                 'S12 whisper … of': 'of the deceit 是普通的 of 结构（关于这场骗局的），whisper 本身就是“风声”，不是短语型用法',
                 'S13 gall … to': 'to 是不定式符号（to reappear），不是介词；gall 本身就是“厚颜”，中文“厚着脸皮”已说全（have the gall to do '
                                  '写在 note）',
                 'S13 encore … of': 'of his script 是普通的 of 结构（他那套剧本的重演），encore 本身就是“重演”，不是短语型用法',
                 'S17 fake money': 'fake 本身就是“假的，伪造的”（速查表释义），文章定稿中文“假冒的”就是这个意思，money '
                                   '是普通名词“货币”，意思不靠搭配整体产生，不是习语'},
          '非人声': {'21.68–21.73s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S2 w 10.860–10.900s，孤立杂音）：scrap 句末 /p/ 除阻：前面闭塞静音 '
                                         '-61 dB，短于 60 ms，是词的一部分'},
                  '24.89–24.93s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S3 w 2.190–2.230s，噗声）：dealer 词头 /d/ 的起始浊音：重心 '
                                         '0.5–0.7 kHz、周期 0.5，紧接 dealer，是词的一部分'},
                  '33.93–33.97s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S5 w 0.020–0.055s，噗声）：Built 词头 /b/ 的起始浊音：重心 0.3–0.4 '
                                         'kHz、周期 0.45–0.5，紧接元音，是词的一部分'},
                  '41.45–41.47s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S5 w 7.575–7.595s，噗声）：years 里 /ɹ/ 的嘎裂收尾：从元音 -17 dB '
                                         '连续衰减而来，只在一帧 -55 dB，随后接 /z/，是词的一部分'},
                  '45.34–45.38s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S6 w 2.690–2.780s，呼吸声）：Lustig 词尾 /ɡ/ '
                                         '除阻后的送气：紧接浊除阻，重心 3.6–4.2 kHz，衰减到 -58 dB，是词的一部分'},
                  '45.34–45.44s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S6 w 2.690–2.780s，呼吸声）：Lustig 词尾 /ɡ/ '
                                         '除阻后的送气：紧接浊除阻，重心 3.6–4.2 kHz，衰减到 -58 dB，是词的一部分'},
                  '46.30–46.40s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S6 w 3.660–3.750s，呼吸声）：crook 词尾 /k/ 的送气：从 -30 dB '
                                         '连续衰减到 -54 dB，中间无低谷，是词的一部分'},
                  '56.18–56.19s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S7 w 6.180–6.190s，孤立杂音）：upkeep 里 up 的 /p/ 除阻：前后都是 '
                                         '-67 dB 闭塞静音，只有 10 ms，是词的一部分'},
                  '56.51–56.53s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S7 w 6.505–6.530s，孤立杂音）：upkeep 句末 /p/ 除阻：前面闭塞静音 -61 '
                                         'dB，短于 30 ms，是词的一部分'},
                  '69.50–69.52s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S9 w 5.120–5.135s，噗声）：supplementing 词尾 /ŋ/ 鼻音收尾：重心 '
                                         '1.0–1.3 kHz、周期 0.47，与前面连着，是词的一部分'},
                  '69.53–69.55s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S9 w 5.145–5.160s，噗声）：supplementing 词尾 /ŋ/ '
                                         '鼻音收尾的最后部分：重心 1.1–1.9 kHz，与前面连着，是词的一部分'},
                  '72.19–72.28s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S9 w 7.880–7.970s，呼吸声）：bribe 的 /aɪ/ 气声收尾进入 /b/ 闭塞：从 '
                                         '-35 dB 连续衰减，无 -55 dB 低谷，是词的一部分'},
                  '72.32–72.36s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S9 w 8.005–8.045s，孤立杂音）：bribe 句末 /b/ 除阻：前面闭塞静音 -58 '
                                         'dB，短于 50 ms，是词的一部分'},
                  '82.00–82.02s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S11 w 5.115–5.135s，噗声）：quietly 词尾 /i/ 的收尾：周期 '
                                         '0.35–0.4，与元音连着，是词的一部分'},
                  '90.17–90.20s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S13 w 3.300–3.330s，噗声）：reappear 的 /ɹ/ 收尾接 with 的 '
                                         '/w/：周期 0.39，紧接 with 开口（-12 dB），是词的一部分'},
                  '91.64–91.66s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S13 w 4.765–4.780s，孤立杂音）：script 词尾 /p/ 或 /t/ 除阻：前后 '
                                         '-58 dB 闭塞静音，15 ms，是词的一部分'},
                  '92.47–92.56s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S13 w 5.595–5.685s，呼吸声）：dealers 的 /ɚ/ 收尾接 /z/：连续，随后 '
                                         '5.68 起重心 4.3–4.9 kHz 的 /z/，是词的一部分'},
                  '98.83–98.84s': {'配音指纹': '560e332deeef',
                                   '依据': '2026-10-22 逐段看声音（S15 w 0.850–0.865s，噗声）：papers 词头 /p/ 除阻前的微弱声音（-50 '
                                         'dB 一帧），紧接 /p/ 爆破，是词的一部分'},
                  '112.22–112.24s': {'配音指纹': '560e332deeef',
                                     '依据': '2026-10-22 逐段看声音（S17 w 5.835–5.850s，噗声）：detention 词尾 /ən/ 的嘎裂收尾：重心 '
                                           '0.8–1.1 kHz、周期 0.33–0.43，是词的一部分'},
                  '118.10–118.19s': {'配音指纹': '560e332deeef',
                                     '依据': '2026-10-22 逐段看声音（S17 w 11.760–11.775s，噗声）：Alcatraz 的 /æ/ '
                                           '收尾的一部分（同上），无低谷断开，是词的一部分'},
                  '118.13–118.14s': {'配音指纹': '560e332deeef',
                                     '依据': '2026-10-22 逐段看声音（S17 w 11.760–11.775s，噗声）：Alcatraz 的 /æ/ '
                                           '收尾的一部分（同上），无低谷断开，是词的一部分'}},
          '除阻加强放宽': {'S7 句末': '用户 2026-10-22 同意：S7 句末 upkeep. 的 /p/ 除阻全频 -41.2 dB，6 dB 上限不够；先同意 +8 dB（实测 '
                              '-33.2，仍差 0.2），再同意这一处加到 +9 dB'},
          '删除段': {'S2 raw 4.1626-4.4800': {'类型': '紧贴词尾的非人声',
                                           '配音指纹': '560e332deeef',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[4.152625, 4.452, '紧贴词尾']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S3 raw 4.2900-4.7250': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '560e332deeef',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[4.445, 4.688667, '紧贴词头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['lost'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S9 raw 5.1800-5.6407': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '560e332deeef',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[5.355, 5.630792, '紧贴词头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['post'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S13 raw 3.1915-3.3550': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '560e332deeef',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[3.1315, 3.295, '紧贴词尾']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S14 raw 2.0471-2.3011': {'类型': '紧贴两头的非人声',
                                            '配音指纹': '560e332deeef',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[2.037083, 2.291125, '紧贴两头']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['post', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S16 raw 1.6411-1.8850': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '560e332deeef',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[1.641, 1.795, '紧贴词尾']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S19 raw 4.2714-4.5196': {'类型': '紧贴两头的非人声',
                                            '配音指纹': '560e332deeef',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[4.191333, 4.439583, '紧贴两头']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost', 'post', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 "
                                                  'dB），不是词'}},
          '用户指定重点词': {'scrap': {'依据': '用户2026-11-13本轮明确点名that the Eiffel Tower was to be sold for '
                                      'scrap.中的scrap/废铁为重点。保留scrap；旧21检查可能与03 scraped误撞，全70另有68 '
                                      'scrapped，不再因撞词删除用户指定项。',
                                '指令转述': '用户本轮明确要求将that the Eiffel Tower was to be sold for '
                                        'scrap.中的scrap与中文废铁标为重点。',
                                '逐字引语状态': '由root转述；已确认点名词为scrap/废铁，不把整理后的指令冒充完整逐字原话。'}}},
 '结尾解说': '简述',
 '高亮按实际开口': True,
 '高亮开口门槛': 40,
 '术语': {'Hôtel de Crillon': '克里雍酒店',
        'Paris': '巴黎',
        'Ministry of Posts and Telegraphs': '邮电部',
        'Eiffel Tower': '埃菲尔铁塔',
        "World's Fair": '世博会',
        'Victor Lustig': '维克多·卢斯蒂格',
        'André Poisson': '安德烈·普瓦松',
        'Vienna': '维也纳',
        'United States': '美国',
        'Alcatraz': '恶魔岛',
        'pneumonia': '肺炎'},
 '结尾句': {'S19': {'前段语速': 0.9,
                 '最后一段语速': 0.78,
                 '最后一段前停顿': 0.7,
                 '接点': [48900, 60300],
                 '依据': '全篇结尾句按 07 定下的标准（用户 2026-10-10 同意并要求所有视频统一）：前段 0.9、最后一段“the one who paid kept mum and '
                       'the one who kept his money went to the police.” 0.78、前面停 0.7 秒。接点由 结尾句接点.py 自动找：0.9 '
                       '那遍最后一个标点后最长静音（30 ms）的正中 2.038 s，0.78 那遍（140 ms）的正中 2.513 s，所在帧和两侧各 5 ms 都低于 -55 dB（程序以 '
                       "08 校准：与人工核实的接点落在同一段静音里）；2026-10-22 前段 Of Lustig's two marks, 比全片响 2.0 LU、与最后一段差 3.3 "
                       'LU（标准 ≤2.5），前段增益 -1.0 dB（同 10 S17；在用户 2026-10-21 同意的 ±1 dB 以内）',
                 '前段增益dB': -1.0}},
 '非人声区间': {'S1': [[1.69, 1.835]],
           'S7': [[1.97, 2.195]],
           'S9': [[5.355, 5.630792, '紧贴词头']],
           'S13': [[3.1315, 3.295, '紧贴词尾']],
           'S3': [[4.445, 4.688667, '紧贴词头']],
           'S19': [[4.191333, 4.439583, '紧贴两头']],
           'S2': [[4.152625, 4.452, '紧贴词尾']],
           'S18': [[1.348, 1.445708]],
           'S14': [[2.037083, 2.291125, '紧贴两头']],
           'S16': [[1.641, 1.795, '紧贴词尾']]},
 '除阻加强': {'S7': {'句末': [6.505,
                        6.535,
                        9.0,
                        '用户 2026-10-22 同意：S7 句末 upkeep. 的 /p/ 除阻全频 -41.2 dB，6 dB 上限不够；先同意 +8 dB（实测 -33.2，仍差 '
                        '0.2），再同意这一处加到 +9 dB']}},
 '换行变更记录': [{'日期': '2026-10-22',
             'S17': '用户 2026-10-22 在会话中选“拆成两组”：S17 第一组 Later arrested in the United States / for making fake '
                    'money,（原来折行后末行只剩 money,，L3）'},
            {'日期': '2026-10-23',
             'S3': '用户 2026-10-23 原话：“如果要是ok的话，尽可能的就是英文上下和它的汉译尽量能够就是位置对齐……”（待改清单第25条，按 01–03 粗细重新分组）',
             'S8': '用户 2026-10-23 原话：“如果要是ok的话，尽可能的就是英文上下和它的汉译尽量能够就是位置对齐……”（待改清单第25条，按 01–03 粗细重新分组）',
             'S9': '用户 2026-10-23 原话：“如果要是ok的话，尽可能的就是英文上下和它的汉译尽量能够就是位置对齐……”（待改清单第25条，按 01–03 粗细重新分组）',
             'S2': '用户 2026-10-23 '
                   '原话：“这个避免它还是没有完美的对应到这个avert的下面……才智也没有非常非常就是非常精准的放到这个intellect的下面……你认认真真的处理一下这件事儿，立一道闸好不好？”（T34：同序的重点词拆开，中文字不改）',
             'S13': '用户 2026-10-23 '
                    '原话：“这个避免它还是没有完美的对应到这个avert的下面……才智也没有非常非常就是非常精准的放到这个intellect的下面……你认认真真的处理一下这件事儿，立一道闸好不好？”（T34：同序的重点词拆开，中文字不改）'}],
 'allow_clash': ['scrap']}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
