#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('In the', '在'),
     ('**fierce heat**', '**酷热**(fierce heat)'),
     ('of', '的'),
     ('summer 1858,', '1858年夏天，'),
     ('the curtains of the new **Houses of Parliament**', '新落成的**议会大厦**(Houses of Parliament)里的窗帘'),
     ('hung', '垂挂着，'),
     ('heavy with', '沉甸甸地浸湿了'),
     ('chloride of **lime**,', '氯化**石灰**(lime)，')],
    '（hang heavy with…：沉甸甸地浸满……；\nchloride of lime：氯化石灰，即漂白粉）'],
   [[('a **bleach**', '这是一种**漂白剂**(bleach)，'),
     ('to make', '用来让'),
     ('the air', '空气'),
     ('**tolerable**.', '变得**可以忍受**(tolerable)。')],
    '（a bleach…：同位语，补充说明 chloride of lime；\nmake + 宾语 + 形容词：使……变得……）']]),
 (1,
  [[[('The Thames', '泰晤士河'),
     ('**festered**,', '正在**溃烂发臭**(festered)，'),
     ('and', '并且'),
     ('MPs', '议员们'),
     ('**contemplated**', '**考虑**(contemplated)过'),
     ('moving out.', '搬离这里。')],
    '（contemplate doing…：考虑做……；\n'
    'MP：议员，即 Member of Parliament）\n'
    '（contemplate 指深入、反复权衡的“仔细考虑”，\n'
    '或陷入“沉思/凝视”\n'
    '（比普通的 think 更有深度和画面感））']]),
 (2,
  [[[('The river', '这条河'), ('had become', '已经成了'), ("London's", '伦敦的'), ('**lavatory**.', '**厕所**(lavatory)。')],
    '（lavatory 是一个非常正式、偏书面、且带有英式英语色彩的词\n'
    '（美式英语在飞机上也常写这个，\n'
    '因为航空业的标识要求全球标准化）。\n'
    '• Lavatory：正式、文雅（飞机上天天见，外刊讽刺文里最爱用）。\n'
    '• Toilet：最直白、最常用（英式日常通用）。\n'
    '• Restroom / Washroom：美式英语中的公共洗手间\n'
    '（商场、餐厅）。\n'
    '• Bathroom：美国家庭里的卫生间（或者美式公共场合的委婉语）。\n'
    '• Loo：英国人的超级口语（比如 "I\'m going to the loo"）。）']]),
 (2,
  [[[('**Antiquated**', '**老旧的**(Antiquated)'),
     ('sewers', '下水道'),
     ('and', '和'),
     ('**outlets**', '**排污口**(outlets)'),
     ('**discharged**', '**排放**(discharged)'),
     ('the **untreated**', '**未经处理的**(untreated)'),
     ('**sewage**', '**污水**(sewage)，'),
     ('of', '它们来自'),
     ('some three million', '约三百万'),
     ('city **dwellers**', '城市**居民**(dwellers)，'),
     ('into', '排入'),
     ('its **currents**,', '河的**水流**(currents)中，')],
    '（discharge A into B：把 A 排放到 B 中；\nsome three million：约三百万，some 表示“大约”；\ncity dweller：城市居民）'],
   [[('where', '在那里，'),
     ('the **excrement**', '**粪便**(excrement)'),
     ('**stewed**', '**处于/闷在炎热的空气中**(stewed)'),
     ('and', '并'),
     ('**decayed**.', '**腐败**(decayed)。')],
    '（where…：非限制性定语从句，where 指 its currents；\nstew：炖，这里指在闷热中闷着、沤着）']]),
 (2,
  [[[('The **vile**', '**令人恶心的**(vile)'),
     ('**fumes**', '**刺鼻气体**(fumes)'),
     ('grew so', '变得如此'),
     ('**overpowering**', '**极其强烈的/令人难以忍受**(overpowering)，'),
     ('that', '以至于'),
     ('the **episode**', '**这段时期**(episode)'),
     ('earned', '赢得了'),
     ('a name,', '一个名字，'),
     ('the Great **Stink**.', '大**恶臭**(Stink)。')],
    '（so…that…：如此……以至于……；\nthe Great Stink：同位语，补充说明 a name）']]),
 (3,
  [[[('**Disgust**', '这股**厌恶**(Disgust)'), ('found', '找到了'), ('a voice', '代言人，'), ('on 15 July,', '是在7月15日，')],
    '（find a voice：找到表达的出口，这里指有了代言人）'],
   [[('when', '当时'),
     ('the **Chancellor of the Exchequer**,', '**财政大臣**(Chancellor of the Exchequer)'),
     ('Benjamin Disraeli,', '本杰明·迪斯雷利'),
     ('**denounced**', '**公开抨击**(denounced as)'),
     ('the river', '这条河'),
     ('**as**', '**是**(denounced as)'),
     ('a **hellish** pool', '一潭**地狱般的**(hellish)池水，'),
     ('of **unbearable** horrors.', '满是**令人无法忍受的**(unbearable)恐怖。')],
    '（the Chancellor of the Exchequer：英国财政大臣；\n'
    'Benjamin Disraeli：同位语，补充说明 the Chancellor；\n'
    'denounce A as B：痛斥 A 是 B）']]),
 (3,
  [[[('A **bill** funding new sewers', '一项为新下水道拨款的**法案**(bill)'),
     ('was **fast-tracked**', '**被快速推进/被加速审批**(fast-tracked)，'),
     ('into law', '成为法律，'),
     ('in about 18 days.', '只用了约18天。')],
    '（funding new sewers：现在分词短语作后置定语，修饰 a bill；\nfast-track A into law：加快把 A 变成法律）']]),
 (4,
  [[[('The engineer', '工程师'),
     ('Joseph Bazalgette', '约瑟夫·巴泽尔杰特'),
     ('**masterminded**', '**主持策划了**(masterminded)'),
     ('the response.', '这次应对。')],
    '（mastermind：策划，主持）']]),
 (4,
  [[[('His', '他修建的'),
     ('82 miles of', '82英里'),
     ('**stout**', '**坚固的**(stout)'),
     ('**intercepting sewers**', '**截流下水道**(intercepting sewers)'),
     ('caught', '截住了'),
     ('the flow', '污水，'),
     ('**short of**', '**在到达**(short of)'),
     ('the river', '河流**之前**(short of)，')],
    '（82 miles of…：82英里长的……；\nintercepting sewer：截流下水道；\nshort of…：在到达……之前）'],
   [[('and **diverted** it', '并把它**改道**(diverted)'),
     ('east,', '向东，'),
     ('**downstream** of the city.', '送往城市**下游**(downstream)。')],
    '（divert：使改道；downstream of…：在……的下游）']]),
 (4,
  [[[('With', '有'),
     ('some', '约'),
     ('1,100 miles of', '1,100英里的'),
     ('street', '街道'),
     ('sewers', '下水道'),
     ('as **tributaries**,', '作为**支流**(tributaries)，')],
    '（with A as B：以 A 作为 B，with 复合结构作状语）'],
   [[('the **infrastructure**', '整套**基础设施**(infrastructure)'),
     ('took', '用了'),
     ('318 million', '三亿一千八百万'),
     ('**bricks**.', '**砖块**(bricks)。')],
    '（take：这里指耗用，需要）']]),
 (4,
  [[[('Having calculated', '先算出'),
     ('an **adequate**', '**足够的**(adequate)'),
     ('**calibre**', '**内径/粗细**(calibre)，'),
     ('for', '用于'),
     ('each', '每条'),
     ('pipe,', '管道，'),
     ('he', '他'),
     ('**doubled** it.', '再把它**加倍**(doubled)。')],
    '（Having calculated…：现在分词完成式作状语，\n表示动作先于 doubled 发生）']]),
 (4,
  [[[('The **backbone**', '系统的**主干**(backbone)'),
     ('lies **buried**', '就**埋藏**(buried)在'),
     ('**underneath** the **newly** built Victoria, Albert, and Chelsea Embankments.',
      '**新近**(newly)修成的维多利亚、阿尔伯特和切尔西河堤**之下**(underneath)。')],
    '（lie buried：埋藏着，lie + 过去分词表示处于某种状态；\nEmbankment：河堤，泰晤士河沿岸的堤岸大道）']]),
 (4,
  [[[('**Substantially** complete by 1875,', '到1875年**基本上**(Substantially)已经完工，'),
     ('much of the network', '这套管网的大部分'),
     ('is **in use** today.', '至今仍**在使用**(in use)。')],
    '（Substantially complete by 1875：形容词短语作状语，\n逻辑主语是 the network；in use：在使用中）']]),
 (5,
  [[[('Yet', '然而，'),
     ('that **sanitation**', '这套**卫生设施/下水道设施**(sanitation)'),
     ('**rested on**', '**建立在**(rested on)'),
     ('a **fallacy**.', '一个**谬误**(fallacy)**之上**(rested on)。')],
    '（rest on…：建立在……之上，以……为基础）']]),
 (5,
  [[[('The **predominant**', '当时**占主导地位的**(predominant)'),
     ('**belief**,', '**看法**(belief)'),
     ('miasma,', '是瘴气说，'),
     ('blamed disease on', '把疾病归咎于'),
     ('**foul air**', '**污浊的空气**(foul air)'),
     ('and **vapours**,', '和臭水的**蒸汽**(vapours)，')],
    '（miasma：瘴气说，同位语，补充说明 belief；\nblame A on B：把 A 归咎于 B）'],
   [[('so', '所以'),
     ('the sewers', '下水道'),
     ('were intended', '修建的目的'),
     ('**principally**', '**主要**(principally)'),
     ('to **suppress**', '是为了**压住**(suppress)'),
     ('the smell.', '臭味。')],
    '（be intended to do：目的是做……，打算用来……）']]),
 (5,
  [[[('They', '它们'),
     ('worked', '奏效，'),
     ('for', '却是出于'),
     ('an **unintended** reason,', '一个**意料之外的**(unintended)原因，')],
    '（work：这里指奏效，起作用）'],
   [[('guarding', '那就是守住了'), ('the **purity** of the water Londoners drank.', '伦敦人饮用水的**洁净**(purity)。')],
    '（guarding…：现在分词短语，解释 reason；\nthe water Londoners drank：省略 that 的定语从句）']]),
 (6,
  [[[('Cholera', '霍乱'),
     ('**resurfaced**', '**再次出现**(resurfaced)'),
     ('in 1866', '于1866年，'),
     ('and killed', '夺去了'),
     ('about 5,600 people', '约5,600人的生命，'),
     ('in the East End,', '在伦敦东区，')],
    '（the East End：伦敦东区）'],
   [[('the one **locality** not yet connected.', '那是唯一下水道尚未接入的**地区**(locality)。')],
    '（the one locality…：同位语，补充说明 the East End；\nnot yet connected：过去分词短语作后置定语）']]),
 (7,
  [[[('A **remedy** **aimed at** the nose', '一项**针对**(aimed at)鼻子的**解决办法**(remedy)'),
     ('\n', ''),
     ('protected', ' 却 保护了'),
     ('the **gut**.', '**肠道**(gut)。')],
    '（aimed at…：过去分词短语作后置定语，\n'
    '修饰 remedy；\n'
    'the gut：肠胃，与 the nose 对比）\n'
    '（简述：▸危机：1858年酷暑，伦敦把未经处理的污水排进泰晤士河，臭到议员都想搬走，这场“大恶臭”推动了下水道建设。▸行动：拨款法案约18天获通过，工程师巴泽尔杰特主持修建新管网，并把算出的管径再加倍。▸工程：新管道在污水入河前先截住它，再送到城市下游，减少城市饮用水被污水污染。▸误判：当时人们以为臭气本身会致病，主要想靠下水道除臭；工程真正保护健康的原因，却是改善了饮用水。▸结果：1866年，尚未接入管网的东区约5600人死于霍乱。管网到1875年基本完工，大部分至今仍使用，形成了“本想管臭味，实际护住肠胃”的反差。）']])]

out = {'no': '30',
 'title_en': "The Stink That Built London's Sewers",
 'title_zh': '大恶臭逼出了下水道',
 'title_fx': {'hl': ['Stink', 'Sewers'], 'ghost': []},
 'sentences': [],
 '核对确认': {'非人声': {'20.64–20.76s': {'配音指纹': '93a277750d35',
                                   '依据': '2026-10-29 30（S3 w 1.060–1.185s，呼吸声）：气声收尾：become 的 /m/ 收尾（w '
                                         '0.98–1.06 浊音 -24→-46 连续衰减到 -61），中间没有 -55 dB 低谷断开，连着词；整段 -60 dB 左右（逐 '
                                         '5 ms 实测）',
                                   '实测': {'最响dB': -35.7, '重心Hz': 2122, '周期': 0.25, '低频dB': -8.5}},
                  '25.25–25.29s': {'配音指纹': '93a277750d35',
                                   '依据': '2026-10-29 30（S4 w 2.145–2.180s，噗声）：词头浊音起始：discharged 的 /d/ 浊音杠（重心 '
                                         '0.2–0.8 kHz、低频重），接在 outlets 的 /s/（6 kHz）后的闭塞静音之后、/d/ 除阻（w 2.215，2.7 '
                                         'kHz）之前（逐 5 ms 实测）',
                                   '实测': {'最响dB': -33.1, '重心Hz': 866, '周期': 0.63, '低频dB': -0.6}},
                  '27.80–27.92s': {'配音指纹': '93a277750d35',
                                   '依据': '2026-10-29 30（S4 w 4.695–4.815s，呼吸声）：擦音起始：of 的 /v/（w 4.62–4.69 浊音）转入 '
                                         'some 的 /s/，重心从 2 kHz 一路升到 6.5 kHz 接上 /s/（w 4.815 起 7.5–8 kHz），连着词（逐 '
                                         '5 ms 实测）',
                                   '实测': {'最响dB': -36.7, '重心Hz': 3246, '周期': 0.18, '低频dB': -9.0}},
                  '41.15–41.17s': {'配音指纹': '93a277750d35',
                                   '依据': '2026-10-29 30（S6 w 0.020–0.045s，噗声）：词头浊音起始：句首 Disgust 的 /d/ 浊音杠（重心 '
                                         '0.3–0.7 kHz、低频重），紧接 /d/ 除阻（w 0.055，3.4–4.4 kHz）（逐 5 ms 实测）',
                                   '实测': {'最响dB': -31.0, '重心Hz': 600, '周期': 0.48, '低频dB': -1.8}},
                  '44.47–44.49s': {'配音指纹': '93a277750d35',
                                   '依据': '2026-10-29 30（S6 w 3.340–3.365s，噗声）：词头气流起始：when 的开头送气（w '
                                         '3.34–3.365，-57 dB），紧连 /w/ 浊音（w 3.371 起），中间没有 -55 dB 低谷；w 3.34 '
                                         '之前是停顿切掉的部分（逐 5 ms 实测）',
                                   '实测': {'最响dB': -42.7, '重心Hz': 2212, '周期': 0.33, '低频dB': -0.8}},
                  '60.64–60.69s': {'配音指纹': '93a277750d35',
                                   '依据': '2026-10-29 30（S8 w 1.290–1.340s，噗声）：词头浊音起始：Bazalgette 的 /b/ 浊音杠（重心 '
                                         '0.5–0.7 kHz、低频重），接在 Joseph 的 /f/（7 kHz）后的闭塞静音之后、/b/ 除阻（w 1.345，3.4 '
                                         'kHz）之前（逐 5 ms 实测）',
                                   '实测': {'最响dB': -32.7, '重心Hz': 810, '周期': 0.76, '低频dB': -0.0}},
                  '66.64–66.66s': {'配音指纹': '93a277750d35',
                                   '依据': '2026-10-29 30（S9 w 2.460–2.470s，孤立杂音）：塞音除阻：intercepting 中 -pt- 的 /p/ '
                                         '除阻（w 2.46，3.6 kHz，10 ms），前后各有闭塞静音（-72、-76 dB），之后是 /t/ 除阻（w 2.495）（逐 '
                                         '5 ms 实测）',
                                   '实测': {'最响dB': -37.4, '重心Hz': 3334, '周期': 0.0, '低频dB': -21.7}},
                  '91.19–91.20s': {'配音指纹': '93a277750d35',
                                   '依据': '2026-10-29 30（S12 w 2.845–2.860s，噗声）：塞音闭塞内的弱声：built 的 /t/ 闭塞段（w '
                                         '2.835 起），紧接 /t/ 除阻（w 2.865，4.4 kHz）和送气，连着词（逐 5 ms 实测）',
                                   '实测': {'最响dB': -49.9, '重心Hz': 1790, '周期': 0.0, '低频dB': -1.0}},
                  '94.04–94.13s': {'配音指纹': '93a277750d35',
                                   '依据': '2026-10-29 30（S12 w 5.785–5.875s，呼吸声）：鼻音收尾：Embankments 的 /n/（w '
                                         '5.72–5.78 起）衰减进 /t/ 闭塞（w 5.875–5.885 静音），之后 /ts/（w 5.89 起 6 '
                                         'kHz），词的一部分（逐 5 ms 实测）',
                                   '实测': {'最响dB': -36.9, '重心Hz': 2560, '周期': 0.23, '低频dB': -3.7}},
                  '96.64–96.66s': {'配音指纹': '93a277750d35',
                                   '依据': '2026-10-29 30（S13 w 1.355–1.370s，噗声）：塞音弱除阻：complete 的 /t/ 弱除阻（w '
                                         '1.355–1.37，-59 dB），之后接 by 的 /b/ 浊音杠（w 1.375）和除阻（w 1.38）（逐 5 ms 实测）',
                                   '实测': {'最响dB': -46.4, '重心Hz': 1965, '周期': 0.0, '低频dB': -1.0}},
                  '100.78–100.86s': {'配音指纹': '93a277750d35',
                                     '依据': '2026-10-29 30（S13 w 5.445–5.525s，呼吸声）：元音的气声收尾：句尾 today 的 /eɪ/ 衰减（w '
                                           '5.365 起 -37 → w 5.52 -65），连着元音、没有 -55 dB 低谷断开（逐 5 ms 实测）',
                                     '实测': {'最响dB': -35.2, '重心Hz': 2687, '周期': 0.27, '低频dB': -3.0}},
                  '118.25–118.33s': {'配音指纹': '93a277750d35',
                                     '依据': '2026-10-29 30（S16 w 2.115–2.195s，呼吸声）：鼻音的嘎裂收尾：reason, 的 /n/ 衰减（-33 '
                                           '→ -66 dB），中间 w 2.145–2.16 是嘎裂脉冲（重心 0.7–1.8 kHz），连着词，之后才是逗号停顿（S10 '
                                           '重新合成后整体后移 0.03 s，原确认按新位置重写；逐 5 ms 实测见首次确认）',
                                     '实测': {'最响dB': -35.4, '重心Hz': 1615, '周期': 0.22, '低频dB': -2.7}},
                  '118.28–118.30s': {'配音指纹': '93a277750d35',
                                     '依据': '2026-10-29 30（S16 w 2.145–2.160s，噗声）：鼻音的嘎裂收尾：同上，reason, 的 /n/ '
                                           '最后几个嘎裂脉冲（w 2.145–2.16，-47 dB，低频重），连着词（逐 5 ms 实测）',
                                     '实测': {'最响dB': -35.4, '重心Hz': 1600, '周期': 0.0, '低频dB': -2.1}}},
          '停顿位置': {'S15 belief, / miasma, @1.270': '2026-10-29 实测（逐 5 ms）：belief 的 /f/ 擦音 w 1.16–1.255（6 '
                                                   'kHz，-37 dB）衰减到 w 1.265–1.270 最低（-60/-61 dB），miasma 的 /m/ '
                                                   '浊音 w 1.295 起；插入点 1.270 正在两词之间的最低处，/f/ 已完整收尾，没插进词里'},
          '删除段': {'S2 raw 1.1950-1.4668': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '93a277750d35',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[1.23, 1.456792, '紧贴词头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['post'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S4 raw 7.6400-8.0310': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '93a277750d35',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[7.64, 8.011083, '紧贴词头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['lost', 'post'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S6 raw 2.9600-3.3503': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '93a277750d35',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[3.14, 3.340292, '紧贴词头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['post'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S6 raw 6.8750-7.2500': '2026-10-15 删除段对应 非人声区间 [[6.87, 7.21]]（w 秒）：自动切点.py '
                                          '用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < -10 dB、周期 < '
                                          "0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms 内最安静处的过零点；复核报 ['lost'] "
                                          '是删掉的呼吸声本身偏响（-34～-47 dB），不是词',
                  'S8 raw 2.0182-2.3369': {'类型': '紧贴两头的非人声',
                                           '配音指纹': '93a277750d35',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[2.008, 2.326875, '紧贴两头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['post', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S15 raw 2.0150-2.3576': {'类型': '紧贴词头的非人声',
                                            '配音指纹': '93a277750d35',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[2.02, 2.357708, '紧贴词头']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"}},
          '响度骤降': {'106.5–106.9s': {'配音指纹': '93a277750d35',
                                    '低': 6.2,
                                    '句子': 'S15 The predominant belief,（第1段，句内调平增益 -4.5 dB）',
                                    '依据': '2026-10-29 实测：belief, 的 /iː/ 后接 /f/ 擦音收尾（w 1.16–1.255 6 kHz -37 '
                                          'dB，衰减到 -61 dB 才停顿），音节完整、没有发闷或吞音；偏轻是 /f/ 本身轻加句内调平 -4.5 dB；6.2 dB 在 '
                                          '01–24 认可上限 7.1 dB 内；用户听后确认',
                                    '用户原话': '可以，可以，可以可以，4k 定稿，定稿，定稿，定稿。'}},
          '牛津逗号': {'S4 dwellers into its currents, where the excrement stewed and': '不是三项并列：stewed and decayed '
                                                                                    '只有两项，where 引出定语从句'},
          '们': {'S2-1 **(festered)，并且议员们**': '“们”在“议员们”（MPs，复数）里，不是给重点词 festered 加的；festered '
                                             '是动词；本次只按用户原话把and下的而改成并且，们仍只属于MPs/议员们，未合进festered重点。'},
          '是的': {'S6-2 是**令人无法忍受的**': '“是”属于“满是”（of 结构：一潭池水，满是……恐怖），不是“是……的”判断句式'},
          '数字': {'S10-2 318': '318 million 读 three hundred and eighteen million，中文按文章定稿写作“三亿一千八百万”，数值相同'},
          '同词异译': {'rested on：之上/建立在': 'S14 rest on“建立在……之上”被“一个谬误”隔开，“建立在”“之上”是同一个意思的两部分（T22/T23），不是两种译法',
                   'short of：之前/在到达': 'S9 short of“在到达……之前”被“河流”隔开，“在到达”“之前”是同一个意思的两部分（T22/T23），不是两种译法',
                   'denounced as：公开抨击/是': 'S6 denounce A as '
                                          'B“公开抨击……是”被“这条河”隔开，“公开抨击”“是”是同一个意思的两部分（T22/T23），不是两种译法'},
          '短语': {'S15 on … foul': '不是搭配：on 属于 blame A on B（blamed disease on，已整组），foul air 是 B，整体标为重点词',
                 'S4 discharged … into': '不是搭配：into 是普通方向介词，引出排放去处（its currents）；discharge 单独就是“排放”',
                 'S4 discharged … of': '不是搭配：of 属于 the untreated sewage of some three million city '
                                       'dwellers（谁的污水）',
                 'S6 denounced … of': '不是搭配：of 属于 a hellish pool of unbearable horrors（满是恐怖的池水）；denounce A as '
                                      'B 已整体标',
                 'S7 fast-tracked … into': '不是搭配：into law 是结果（成为法律），fast-track 单独就是“加快处理”，速查表搭配 fast-track a '
                                           'bill',
                 'S9 diverted … of': '不是搭配：of 属于 downstream of the city，diverted 的宾语是 it',
                 'S9 downstream … of': '不是搭配：of 引出参照地点（城市），downstream 单独就是“在下游”，同 east of、north of 的用法',
                 'S16 purity … of': '不是搭配：the purity of A 是普通的 of 结构（A 的洁净），purity 单独是重点词'},
          '对齐': {'S1-1 the curtains of the new Houses': 'of 结构作后置定语，中文“新落成的议会大厦里的窗帘”定语提前，语序必须倒过来',
                 'S6-2 the Chancellor of the Excheque': 'the Chancellor of the Exchequer '
                                                        '是固定官职名，中文就是“财政大臣”一个词，整体标为重点词，拆开不通',
                 'S7-1 A bill funding new sewers': 'funding new sewers 是现在分词短语作后置定语，中文“为新下水道拨款的法案”定语提前，语序必须倒过来',
                 'S12-1 underneath the newly built Vic': 'underneath '
                                                         '中文是方位词“……之下”，必须放在“河堤”后面，语序必须倒过来；newly、underneath '
                                                         '两个重点词因此同在一组（T34 倒装）',
                 'S16-2 the purity of the water London': 'the purity of A 中文“A 的洁净”，of 结构语序必须倒过来；the water '
                                                         'Londoners drank 省略 that 的定语从句也要提前',
                 'S17-2 the one locality not yet conne': 'not yet connected '
                                                         '是过去分词短语作后置定语，中文“唯一尚未接入的地区”定语提前，语序必须倒过来',
                 'S18-1 A remedy aimed at the nose': 'aimed at the nose '
                                                     '是过去分词短语作后置定语，中文针对鼻子的修饰解决办法，定语放在名词之前，与英文remedy在前的次序相反；remedy/解决办法新增为名词重点，aimed '
                                                     'at/针对整组及gut/肠道保留各自重点。'},
          '合组': {'S11 an adequate calibre for each pipe': '对齐不了：for each pipe 中文“每条管道的”必须放在“足够的管径”前面',
                 'S1 the curtains of the new Houses of Parliament': '对齐不了：of '
                                                                    '结构作后置定语，中文“新落成的议会大厦里的窗帘”定语必须提前，拆开后中文语序就乱了',
                 'S7 A bill funding new sewers': '对齐不了：funding new sewers 是现在分词短语作后置定语，中文“为新下水道拨款的法案”定语必须提前',
                 'S15 blamed disease on': '对齐不了：blame A on B 中文“把 A 归咎于 B”，A 必须提到“归咎于”前面，拆开后中文语序就乱了',
                 'S12 underneath the newly built Victoria, Albert, and Chelsea Embankments.': '对齐不了：underneath '
                                                                                              '中文是方位词“……之下”，必须放在“河堤”后面',
                 'S13 Substantially complete by 1875': '对齐不了：by 1875 中文“到1875年”必须放在“基本完工”前面',
                 'S13 is in use today': '对齐不了：today 中文“至今”必须放在“仍在使用”前面',
                 'S16 the purity of the water Londoners drank': '对齐不了：the purity of A 中文“A 的洁净”，of 结构语序必须倒过来',
                 'S17 the one locality not yet connected': '对齐不了：not yet connected 是后置定语，中文“唯一尚未接入的地区”定语必须提前',
                 'S18 A remedy aimed at the nose': '对齐不了：aimed at the nose 是后置定语，中文针对鼻子的须置于名词解决办法之前，与英文 remedy '
                                                   'aimed at the nose 顺序相反。A只译一项、鼻子普通，不把词性误当动词或改原英文。'}},
 '结尾解说': '简述',
 '合成标点': {'S10': [['tributaries, the', 'tributaries; the']]},
 'allow_clash': ['Houses of Parliament', 'episode', 'intercepting sewers', 'foul air', 'remedy'],
 '说明放宽特批': {'S18': {'倍数': '整屏', '依据': '用户 2026-10-28 特批：“29、30、31 结尾简述都整屏、字号放到最大”（用户同意记录）'}},
 '高亮按实际开口': True,
 '高亮开口门槛': 40,
 '术语': {'Houses of Parliament': '议会大厦',
        'Thames': '泰晤士河',
        'London': '伦敦',
        'Londoners': '伦敦人',
        'Benjamin Disraeli': '本杰明·迪斯雷利',
        'Joseph Bazalgette': '约瑟夫·巴泽尔杰特',
        'Victoria': '维多利亚',
        'Albert': '阿尔伯特',
        'Chelsea': '切尔西',
        'Embankments': '河堤',
        'East End': '伦敦东区'},
 '非人声区间': {'S4': [[7.64, 8.011083, '紧贴词头']],
           'S6': [[3.14, 3.340292, '紧贴词头'], [6.87, 7.21]],
           'S7': [[1.57, 1.77], [1.78, 1.815]],
           'S13': [[3.06, 3.360958, '紧贴词头']],
           'S15': [[2.02, 2.357708, '紧贴词头']],
           'S9': [[6.35, 6.653417, '紧贴词头']],
           'S2': [[1.23, 1.456792, '紧贴词头']],
           'S8': [[2.008, 2.326875, '紧贴两头']]},
 '词尾除阻': {'S1': {'1': [2.805, 't']},
          'S2': {'句末': [3.52, 't']},
          'S11': {'句末': [4.225, 't']},
          'S12': {'2': [4.45, 't']},
          'S18': {'句末': [2.46, 't']}},
 '区间声音指纹': {'S1': 'ec26169a61b3',
            'S2': '3398b5f7d911',
            'S4': '953d5d6a4e56',
            'S6': '165a900397bd',
            'S7': 'a8e16a6394fa',
            'S8': 'd2901078cfed',
            'S9': 'ecc81b4f7a0b',
            'S11': 'e3cdb441a96c',
            'S12': '59e961ef4172',
            'S13': '9b4a5b4989b9',
            'S15': 'f9f9ada898a8',
            'S18': 'd59b240ade34'},
 '换行变更记录': [{'日期': '2026-10-29',
             'S9': '用户 2026-10-29 原话：“intercepting sewer 标注为 重点词汇”“然后这几个全都保留……全都保留，全都保留，全都保留”（intercepting '
                   'sewers 整体标为一组、short of 按用户改，S9 分组、换行随之变）'},
            {'日期': '2026-10-29',
             'S9': '用户 2026-10-29 原话：“intercepting sewer 标注为 重点词汇”“然后这几个全都保留……全都保留，全都保留，全都保留”（intercepting '
                   'sewers 整体标为一组、short of 按用户改，S9 分组、换行随之变）'}],
 '除阻加强': {'S9': {'1': [6.245, 6.305, 4.5]}},
 '换行变更已获同意': {'S18': '用户本次明确要求末页重新排版并最终定稿，实际原话“这地方这个在这个地方，在这个地方有remedy标注为重点词汇。本来在下面所对应的补救措施改为解决办法 。\n'
                     '\n'
                     '\n'
                     '\n'
                     '\n'
                     '\n'
                     '\n'
                     '> **翻译改为：一项针对鼻子的解决办法 却 保护了肠道。&#x20;**\n'
                     '\n'
                     '\n'
                     '\n'
                     '并且这是最后一页，好好排版，你看这个排版又有问题，好好排版，好好排版。然后然后这一篇，然后这一篇4k定稿，然后这一篇4k定稿。”。本处只用既有换行格把 A remedy '
                     'aimed at the nose 名词组与 protected the gut '
                     '谓语部分分成居中两行；原英文每个词/标点及中文两个ASCII空格原样，remedy/解决办法、aimed '
                     'at/针对、gut/肠道各自重点，原语法注和独立五点简述整串保留。这里只是静态排版实施记录，不声称新声音已听审。'}}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
