# EN: Move 37
# ZH: 第37手

## 英文
Go is said to allow more **configurations** than the universe has **atoms**, a **daunting** **computational** challenge. In October 2015 DeepMind's AlphaGo reached a **milestone**, becoming the first **program** to beat a professional on a full board without a **handicap**. In March 2016 its **opponent** in a **televised** Seoul **showdown** was Lee Sedol, a South Korean **strategist** with 18 international titles.

In game two, on 10 March, AlphaGo's 37th move was a shoulder hit, a **tactic** placing a stone **adjacent to** an opponent's on the **diagonal**. On the **grid**'s fifth line, it was hardly **orthodox**. **Commentators** found the **unexpected** **placement** **bizarre**; one took it for a mistake. Lee left the room, his **pause** for **deliberation** lasting over ten minutes.

DeepMind's **diagnostic** tools showed AlphaGo had put the **odds** of a human playing that stone at one in 10,000, a **staggering** **rarity**. AlphaGo had first learned to **imitate** strong **amateurs** online, then **sharpened** its play over tens of millions of **simulated** games against itself. Lee later **acknowledged** the stone's **originality** and beauty.

The fourth game, on 13 March, **reversed** the roles in **neat** **symmetry**. Lee's 78th move **turned the tide**, and many professionals **heralded** it **as** **divine**. DeepMind's team **computed** a professional's **likelihood** of finding it: about one in 10,000. Lee's only win was a **consolation** amid AlphaGo's **overwhelming** 4–1 victory.

In November 2019 Lee **withdrew from** the professional **circuit**, a **farewell** he tied to AI's **unrivalled** **dominance**. Calling AI an **invincible** **entity**, he said the **summit** was beyond him. Yet his one win came from a stone whose odds, by DeepMind's figures, were as **slim** as those of AlphaGo's **audacious** shoulder hit.

## 中文

据说，围棋所允许出现的**布局**(configurations)（数量），比宇宙中的**原子**(atoms)还要多，这是一项**艰巨的**(daunting)**计算**(computational)挑战。（be said to do：据说……；a daunting … challenge：同位语，说明前面整句）2015年10月，DeepMind 的 AlphaGo达成了一个**里程碑**(milestone)，成为首个在全尺寸棋盘上不**让子**(handicap)击败职业棋手的**程序**(program)。（becoming…：现在分词短语，补充说明这个里程碑；the first program to do：第一个做……的程序）2016年3月，在首尔一场**电视转播的**(televised)**对决**(showdown)中，它的**对手**(opponent)是李世石，一个韩国**战略家**(strategist)（围棋大师），拥有18个国际冠军头衔。

第二局于3月10日进行，AlphaGo 的第37手是一记肩冲。这种**招数/手段**(tactic)，是将一枚棋子下在**与**(adjacent to)对方棋子的**斜对角**(diagonal)**相邻**(adjacent to)的地方。（shoulder hit：肩冲，围棋术语；a tactic placing…：同位语，解释 shoulder hit，placing… 作后置定语）在**网格**(grid)（方格构成的网状 - 指 棋盘）第五线上落子，这几乎不能算是**正统**(orthodox)下法。**解说员**(Commentators)觉得这步**出乎意料的**(unexpected)**落子**(placement)（把人或物放到合适位置）**十分怪异**(bizarre)；其中一人还以为是失误。（find + 宾语 + 形容词：觉得……怎么样；take A for B：把A当成B）李世石离开了对局室，他这次**暂停**(pause)**思考**(deliberation)持续了十多分钟。（his pause … lasting…：独立主格，= and his pause … lasted…）

DeepMind 的**诊断**(diagnostic)工具显示，AlphaGo曾把人类下出这一手的**概率**(odds)估算为万分之一，**惊人的**(staggering)**罕见**(rarity)。（put the odds of … at …：把……的概率估算为……；a staggering rarity：同位语，补充说明这个概率）AlphaGo 起初先学会**模仿**(imitate)网上实力很强的**业余者**(amateurs)的下法，随后，在经过了数千万盘自我对弈的**模拟**(simulated)比赛后，它**磨砺了**(sharpened)棋力。李世石后来**承认了**(acknowledged)这一手的**独创性**(originality)和美感。

3月13日的第四局，以**巧妙的**(neat)**对称**(symmetry)，**互换了**(reversed)双方的角色。（互换角色：第二局 AlphaGo 靠万分之一的第37手赢了人类棋手；第四局反过来，人类棋手靠万分之一的第78手赢了 AlphaGo）李世石的第78手**扭转了局势**(turned the tide)，许多职业棋手**把**(heralded as)它**誉为**(heralded as)**神之一手**(divine)。（herald A as B：把A誉为B；divine：神的，神妙的，“神之一手”指围棋中绝妙的一手）DeepMind 团队**算出了**(computed)职业棋手找到这一手的**可能性**(likelihood)：约为万分之一。李世石唯一的胜局，是AlphaGo 4比1**压倒性的**(overwhelming)胜利中的一点**安慰**(consolation)。（amid：在……之中）（consolation：通常作名词，指失望、悲伤或遭受打击时得到的安慰和心理宽慰）

2019年11月，李世石**退出了**(withdrew from)职业**巡回赛**(circuit)（退役），他把这次**告别**(farewell)归咎于人工智能**无可匹敌的**(unrivalled)**统治地位**(dominance)。（a farewell he tied to…：同位语，说明前面整件事；tie A to B：把A和B联系起来，这里指把A归咎于B）称人工智能是**不可战胜的/无敌的**(invincible)**存在**(entity)，他说，那个**顶峰**(summit)已非他所能企及。（Calling…：现在分词短语作伴随状语；call A B：称A为B；be beyond sb：超出某人的能力）然而，他唯一的一场胜局，却源自一着棋。根据 DeepMind 的数据，这手棋的胜率，和 AlphaGo 那次**大胆的**(audacious)肩冲一样**极低/渺茫/非常微小**(slim)。（whose…：定语从句，修饰 a stone；by DeepMind's figures：插入语；as slim as those of…：those = the odds）（简述：▸训练：围棋程序AlphaGo先模仿高水平业余者，再经数千万盘自我对弈提高棋力，2016年与韩国棋手李世石对弈。▸奇手：第二局第37手下在棋盘从边缘数第五条线上，出乎常规，解说员起初疑为失误；李世石后来赞赏这手棋的独创性。▸回应：第四局，李世石的第78手扭转局势，被许多棋手赞为神之一手，带来他在五局比赛中唯一的胜利。▸赛果：AlphaGo最终以4比1获胜；李世石2019年退役时说，AI已不可战胜，自己无法再登顶。▸对照：AlphaGo估计人类下出第37手的可能性约为万分之一，DeepMind团队估计职业棋手想到第78手的可能性也约为万分之一；两者衡量的是想出那一手棋的罕见程度。）

## 速查表
| 词 | 释义 | 段 |
|---|---|---|
| configurations | 本文：布局；n. (configuration) 布局，构型，局面（the configuration of the pieces；system configuration） | 1 |
| atoms | 本文：原子；n. (atom) 原子（split the atom；carbon atoms） | 1 |
| daunting | 本文：艰巨的；adj. 令人生畏的，艰巨的（a daunting task/prospect） | 1 |
| computational | 本文：计算；adj. 计算的（computational power/methods） | 1 |
| milestone | 本文：里程碑；n. 里程碑，重要事件（reach a milestone；a milestone in history） | 1 |
| handicap | 本文：让子；n. （比赛中给弱方的）让子，让分；障碍（play with a handicap；a physical handicap） | 1 |
| televised | 本文：电视转播的；adj./v. (televise) 电视转播的（a televised debate/match） | 1 |
| showdown | 本文：对决；n. 摊牌，决战（a final showdown；a showdown with rivals） | 1 |
| opponent | 本文：对手；n. 对手，反对者（a political opponent；defeat an opponent） | 1 |
| strategist | 本文：战略家；n. 战略家，谋略家（a military/political strategist） | 1 |
| tactic | 本文：招数/手段；n. 策略，招数（a delaying tactic；scare tactics） | 2 |
| adjacent to | 本文：与……相邻；adj. 相邻的，邻近的（adjacent rooms；land adjacent to the river） | 2 |
| diagonal | 本文：斜对角；adj./n. 斜的，对角线的；对角线（a diagonal line；cut along the diagonal） | 2 |
| grid | 本文：网格；n. 网格，格子；电网（a street grid；the national grid） | 2 |
| orthodox | 本文：正统；adj. 正统的，传统的（orthodox medicine/views） | 2 |
| unexpected | 本文：出乎意料的；adj. 出乎意料的（an unexpected visitor/result） | 2 |
| placement | 本文：落子；n. 放置，布置；安置（the placement of furniture；job placement） | 2 |
| bizarre | 本文：十分怪异；adj. 怪异的，离奇的（bizarre behaviour；a bizarre coincidence） | 2 |
| pause | 本文：暂停；n./v. 暂停，停顿（a brief pause；pause for breath） | 2 |
| deliberation | 本文：思考；n. 仔细考虑，斟酌；审议（after much deliberation；jury deliberations） | 2 |
| diagnostic | 本文：诊断；adj. 诊断的（diagnostic tests/tools） | 3 |
| odds | 本文：概率；n. 可能性，概率（the odds are against us；against all odds） | 3 |
| staggering | 本文：惊人的；adj. 惊人的，令人震惊的（a staggering amount/sum） | 3 |
| rarity | 本文：罕见；n. 稀有，罕见；罕见的事物（be something of a rarity） | 3 |
| imitate | 本文：模仿；v. 模仿，效仿（imitate sb's accent/style） | 3 |
| amateurs | 本文：业余者；n. (amateur) 业余爱好者，业余选手（talented amateurs；amateur athletes） | 3 |
| simulated | 本文：模拟；adj. 模拟的，仿真的（a simulated flight；simulated leather） | 3 |
| sharpened | 本文：磨砺了；v. (sharpen) 使锐利；提高，磨炼（sharpen a pencil；sharpen one's skills） | 3 |
| acknowledged | 本文：承认了；v. (acknowledge) 承认，认可（acknowledge a mistake；widely acknowledged） | 3 |
| originality | 本文：独创性；n. 独创性，新颖（a work of great originality） | 3 |
| neat | 本文：巧妙的；adj. 整齐的，工整的；巧妙的（a neat solution；neat handwriting） | 4 |
| symmetry | 本文：对称；n. 对称，匀称（perfect symmetry；the symmetry of a face） | 4 |
| reversed | 本文：互换了；v. (reverse) 颠倒，扭转（reverse a decision/the trend；roles reversed） | 4 |
| turned the tide | 本文：扭转了局势；n. 潮汐；趋势，局势（turn the tide；the tide of public opinion） | 4 |
| heralded as | 本文：把……誉为；v. (herald) 称颂，誉为；预示（be heralded as a breakthrough） | 4 |
| divine | 本文：神之一手；adj. 神的；神妙的，极好的（divine intervention；a divine performance） | 4 |
| computed | 本文：算出了；v. (compute) 计算，算出（compute the cost/total） | 4 |
| likelihood | 本文：可能性；n. 可能性（in all likelihood；increase the likelihood of） | 4 |
| overwhelming | 本文：压倒性的；adj. 压倒性的，势不可挡的（an overwhelming majority/victory） | 4 |
| consolation | 本文：安慰；n. 安慰，慰藉（a consolation prize；take consolation from sth） | 4 |
| withdrew from | 本文：退出了；v. (withdraw) 退出，撤回（withdraw from a race；withdraw troops） | 5 |
| circuit | 本文：巡回赛；n. 巡回赛；电路；环行（the tennis circuit；an electrical circuit） | 5 |
| farewell | 本文：告别；n. 告别（a farewell party；bid farewell to sb） | 5 |
| unrivalled | 本文：无可匹敌的；adj. 无与伦比的，无可匹敌的（unrivalled expertise/views） | 5 |
| dominance | 本文：统治地位；n. 统治地位，优势（market dominance；establish dominance） | 5 |
| invincible | 本文：不可战胜的/无敌的；adj. 不可战胜的（an invincible army；feel invincible） | 5 |
| entity | 本文：存在；n. 实体，存在（a separate legal entity） | 5 |
| summit | 本文：顶峰；n. 顶峰，峰顶；峰会（reach the summit；a G7 summit） | 5 |
| audacious | 本文：大胆的；adj. 大胆的，敢于冒险的（an audacious plan/attack） | 5 |
| slim | 本文：极低/渺茫/非常微小；adj. 微小的，渺茫的；苗条的（a slim chance/majority） | 5 |

| program | n. 程序（本文指围棋计算机程序） | 1 |

| Commentators | n. (commentator) 解说员，评论员（本文指围棋比赛解说员） | 2 |

## 史实与来源
- 【T1】"围棋可能的局面数比宇宙中的原子还多"是常见说法，正文以 is said to（"据说"）标明。S6
- 【T2】2015年10月，DeepMind 的 AlphaGo 以5比0击败欧洲冠军樊麾，成为首个在全尺寸棋盘不让子胜职业棋手的程序（对手为欧洲冠军樊麾，正文不写名与比分）。S1
- 【T3】2016年3月在首尔与拥有18个国际冠军头衔的李世石进行五番棋；李昌镐（21个头衔）不写。S2
- 【T4】第二局（2016年3月10日）AlphaGo 第37手在第五线肩冲；解说员称很奇怪，有人认为是失误；李世石离席，各来源称约12至15分钟后才落子，正文写"十多分钟"，不写确切分钟。S3
- 【T5】英文 DeepMind's diagnostic tools 对应来源中团队事后用诊断工具查询：，AlphaGo 估算人类下出这一手的概率为万分之一；李世石后来称这一手有创造性、很美，正文间接转述。S3
- 【T6】AlphaGo 先学习网络围棋服务器上强业余棋手的对局，再与自己对弈数千万盘。S1
- 【T7】第四局（2016年3月13日）李世石第78手是转折点，许多职业棋手称之为"神之一手"（英文 heralded it as divine，中文译"誉为神之一手"）；DeepMind 团队负责人称人类职业棋手下出这一手的概率同样约为万分之一；AlphaGo 以4比1赢得五番棋。两处"万分之一"分别注明出自 AlphaGo 自身估算和 DeepMind 团队。S4
- 【T8】2019年11月李世石宣布退役，称因人工智能日益占据主导，他已无法成为第一人，并称 AI 是"无法被击败的存在"；正文间接转述。S5
- 【补】肩冲：把一子下在对方棋子的斜对角并与之紧邻，属围棋常识，用来解释术语，不是来源新增的事实。正文第二、四局只写月日，年份已由上段的2016年3月交代。
- 【补】结尾"by DeepMind's figures"：第37手的万分之一是 DeepMind 团队用诊断工具查询 AlphaGo 得出的，第78手的万分之一由 DeepMind 团队负责人提出，两个数字都出自 DeepMind，故可合称"按 DeepMind 的数据"。
- 【说明】所有来源均为检索摘要。直接引语全部改为间接叙述；排除：李世石离席的确切分钟数、奖金与捐款、李昌镐、AlphaGo 第四局"崩溃"细节、第78手的 wedge（挖）之类棋形说法。不渲染"人类败给机器"的悲情。英文未写明的因果，中文不加"因此""于是"。
