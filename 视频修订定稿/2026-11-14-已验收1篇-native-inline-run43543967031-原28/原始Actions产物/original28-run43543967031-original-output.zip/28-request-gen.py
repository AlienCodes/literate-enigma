#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('Project 523,', '523项目'),
     ('a', '是一项'),
     ('**covert**', '**秘密的/隐秘的**(covert)'),
     ('**military**', '**军事**(military)'),
     ('**mission**', '**任务**(mission)，'),
     ('involving', '涉及'),
     ('many institutes,', '多家机构，')],
    '（a covert military mission…：同位语，补充说明 Project 523；\ninvolving many institutes：现在分词短语作后置定语）'],
   [[('was named', '得名'),
     ('after', '于'),
     ('its', '它的'),
     ('launch', '启动'),
     ('date,', '日期，'),
     ('23 May 1967.', '1967年5月23日。')],
    '（be named after…：以……命名）']]),
 (1,
  [[[('Its', '它的'),
     ('**urgent** target', '**紧迫**(urgent)目标'),
     ('was', '是'),
     ('the chloroquine-**resistant**', '对氯喹**产生耐药性的**(resistant)'),
     ('**malaria**', '**疟疾**(malaria)，')],
    '（chloroquine-resistant：对氯喹产生耐药性的，chloroquine 是氯喹）'],
   [[('**weakening**', '它**削弱了**(weakening)'),
     ('**troops** in the **Vietnam War**.', '**越南战争**(Vietnam War)中的**部队**(troops)。')],
    '（weakening troops…：现在分词短语作后置定语，修饰 malaria）']]),
 (1,
  [[[('In January 1969', '1969年1月，'),
     ('Tu Youyou', '屠呦呦'),
     ('was **entrusted with**', '**受命**(entrusted with)'),
     ('leading', '领导'),
     ("her institute's", '她所在研究所的'),
     ('research', '研究'),
     ('group,', '组，')],
    '（be entrusted with doing…：被委以做……的重任，受命做……）'],
   [[('**despite**', '**尽管**(despite)她'),
     ('having no **doctorate**', '既没有**博士学位**(doctorate)，'),
     ('or', '也没有'),
     ('foreign', '在国外'),
     ('training.', '受过训练。')],
    '（despite doing…：尽管……，despite 是介词，后面接动名词）']]),
 (2,
  [[[('In an', '在一次'),
     ('**exhaustive** search,', '**彻底的**(exhaustive)搜寻中，'),
     ('her team', '她的团队'),
     ('**combed**', '**仔细翻检了**(combed)'),
     ('over 2,000', '2,000多个'),
     ('**folk** recipes,', '**民间**(folk)药方，')],
    '（comb：梳理，这里指仔细翻检；over 2,000：2,000多个）'],
   [[('**compiled**', '**编纂/汇编了**(compiled)'),
     ('640 **prescriptions**,', '640个**处方/药方**(prescriptions)，'),
     ('and **evaluated**', '并**评估了**(evaluated)'),
     ('about 380 **extracts**', '约380种**提取物**(extracts)，'),
     ('from', '它们来自'),
     ('some 200', '200种左右的'),
     ('**medicinal**', '**药用的**(medicinal)'),
     ('**herbs**.', '**草药**(herbs)。')],
    '（some 200：大约200，some 表示“大约”）']]),
 (2,
  [[[('Qinghao,', '青蒿，'),
     ('or **sweet wormwood**,', '也就是**黄花蒿**(sweet wormwood)，'),
     ('showed', '展现出'),
     ('**flashes** of **promise**,', '几丝**成功迹象**(promise)的**闪光/闪现**(flashes)，'),
     ('yet', '然而'),
     ('its results', '它的效果'),
     ('were **erratic**.', '却**并不稳定/时好时坏的**(erratic)。')],
    '（or：也就是，引出同一种植物的另一个名称；\nshow flashes of promise：不时显出希望）']]),
 (2,
  [[[('Seeking', '为了寻找'),
     ('a **clue**,', '**线索**(clue)，'),
     ('Tu', '屠呦呦'),
     ('**revisited**', '**重新审阅了**(revisited)'),
     ('the **classical** texts.', '**古典**(classical)文献。')],
    '（Seeking a clue：现在分词短语作状语，表示目的）']]),
 (3,
  [[[('Around AD 340,', '约公元340年，'),
     ('the physician', '医师'),
     ("Ge Hong's", '葛洪的'),
     ('**handbook**', '**手册**(handbook)'),
     ('advised', '建议'),
     ('taking', '服用：')],
    '（advise doing…：建议做……；handbook：手册，指葛洪的《肘后备急方》）'],
   [[('"a handful of qinghao', '“一把'),
     ('**immersed in**', '**浸泡在**(immersed in)'),
     ('two **litres** of water".', '两**升**(litres)水中的青蒿”。')],
    '（a handful of…：一把……；immersed in…：过去分词短语，浸在……里；\n引文是《肘后备急方》原文“青蒿一握，以水二升渍”的英译）']]),
 (3,
  [[[('This', '这个方法'), ('**bypassed**', '**绕开了**(bypassed)'), ('boiling.', '煮沸。')],
    '（This 指上面用水浸泡青蒿的做法；\nbypass：绕过，避开）']]),
 (3,
  [[[('Tu', '屠呦呦'),
     ('suspected', '怀疑，'),
     ('heat during **extraction**', '**提取**(extraction)过程中的高温'),
     ('was **degrading**', '正在**降解/分解**(degrading)'),
     ('a', '某种'),
     ('**delicate**', '**脆弱的**(delicate)'),
     ('**component**,', '**成分**(component)，')],
    '（suspected 后面省略了 that，引出宾语从句；\ndelicate：这里指不耐热、容易被破坏的）'],
   [[('so', '于是'),
     ('she', '她'),
     ('**switched to**', '**改用/换成了**(switched to)'),
     ('**ether**,', '**乙醚**(ether)，')],
    '（switch to…：改用……，换成……）'],
   [[('a', '一种'),
     ('**volatile**', '**易挥发的**(volatile)'),
     ('**solvent**', '**溶剂**(solvent)，'),
     ('boiling at', '沸点为'),
     ('about 35', '约35'),
     ('**degrees Celsius**.', '**摄氏度**(degrees Celsius)。')],
    '（a volatile solvent…：同位语，补充说明 ether；\nboiling at…：现在分词短语作后置定语，在……时沸腾）']]),
 (3,
  [[[('On 4 October 1971', '1971年10月4日，'),
     ('sample 191', '第191号样品'),
     ('completely', '完全'),
     ('**inhibited**', '**抑制了**(inhibited)'),
     ('the **parasite** in **infected** mice.', '**受感染**(infected)小鼠体内的**寄生虫**(parasite)。')],
    '（parasite：寄生虫，这里指疟原虫；\nin infected mice：后置定语，修饰 the parasite）']]),
 (4,
  [[[('**Efficacy** in mice', '在小鼠身上有**药效**(Efficacy)，'),
     ('**indicated** nothing about', '并不能**说明**(indicated)'),
     ('human', '人'),
     ('safety.', '是否安全。')],
    '（indicate nothing about…：对……什么也说明不了）']]),
 (4,
  [[[('In July 1972,', '1972年7月，'),
     ('to **assess**', '为了**评估**(assess)'),
     ('its **toxicity**,', '它的**毒性**(toxicity)，'),
     ('Tu', '屠呦呦'),
     ('and two colleagues', '和两名同事'),
     ('**voluntarily**', '**自愿地**(voluntarily)'),
     ('took', '服下了'),
     ('the extract.', '这种提取物。')],
    '（to assess…：不定式作目的状语）']]),
 (4,
  [[[('**Thereafter**,', '**此后**(Thereafter)，'),
     ('from August to October,', '从8月到10月，'),
     ('it', '这种提取物'),
     ('was **administered to**', '**用于治疗**(administered to)'),
     ('21', '21名'),
     ('malaria', '疟疾'),
     ('**patients**', '**病人**(patients)，'),
     ('in Hainan,', '在海南，')],
    '（administer A to B：给 B 施用 A，这里指给病人用药）'],
   [[('and', '而'),
     ('on 8 November', '在11月8日，'),
     ('her team', '她的团队'),
     ('**obtained**', '**得到了**(obtained)'),
     ('pure **crystals** of the **substance**', '这种**物质**(substance)的纯净**晶体**(crystals)，'),
     ('later', '它后来'),
     ('named', '被命名为'),
     ('artemisinin.', '青蒿素。')],
    '（later named artemisinin：过去分词短语作后置定语，\n修饰 the substance）']]),
 (5,
  [[[('In September 2011', '2011年9月，'),
     ('Tu', '屠呦呦'),
     ('was named', '被评为'),
     ('a Lasker Award', '拉斯克奖'),
     ('**recipient**;', '**得主**(recipient)；')],
    '（recipient 就是“接受者 / 接收者”（在奖项里特指“得主”）。\n'
    '奖项/荣誉场景：award recipient = 获奖者 / 得主\n'
    '物品/信息场景：email recipient = 邮件收件人；\n'
    'welfare recipient = 福利领取者）'],
   [[('its **jury**', '该奖的**评审团**(jury)'), ('credited the drug with saving millions.', '将挽救了数百万人的功劳归功于这种药物。')],
    '（credit A with B：把 B 的功劳归于 A（或：认为 B 是 A 的成就））']]),
 (5,
  [[[('On 5 October 2015', '2015年10月5日，'),
     ('she', '她'),
     ('won', '获得了'),
     ('half', '一半的'),
     ('the Nobel Prize in', '诺贝尔'),
     ('**Physiology**', '**生理学**(Physiology)'),
     ('or Medicine,', '或医学奖，')],
    '（won half the Nobel Prize：获得了诺贝尔奖的一半，\n另一半由另外两位学者分享）'],
   [[('the first', '成为第一位'), ('Chinese woman', '中国女性'), ('Nobel **laureate**.', '诺贝尔奖**获得者**(laureate)。')],
    '（the first Chinese woman Nobel laureate：同位语，补充说明 she）']]),
 (5,
  [[[('Since 2006', '自2006年起，'),
     ('WHO **guidelines**', '世界卫生组织的**指南**(guidelines)'),
     ('have **endorsed**', '一直**公开支持/赞同**(endorsed)'),
     ('artemisinin-based', '以青蒿素为基础的'),
     ('**combination**', '**联合**(combination)'),
     ('**therapies**', '**疗法**(therapies)，'),
     ('against', '用来对付'),
     ("malaria's", '疟疾中'),
     ('**deadliest** form.', '**最致命的**(deadliest)一种。')],
    '（WHO：世界卫生组织；artemisinin-based：以青蒿素为基础的；\nhave endorsed：现在完成时，表示从2006年一直到现在）']]),
 (5,
  [[[("The **essence** of Ge Hong's line", '葛洪那句话的**精髓**(essence)，'),
     ('lay in', '正在于'),
     ('the boiling it **skipped**.', '它**略去**(skipped)的煮沸。')],
    '（lie in…：在于……，lay 是 lie 的过去式；\n'
    'it skipped：定语从句，\n'
    '修饰 the boiling，省略了 that）\n'
    '（简述：▸寻药：部分疟疾已对旧药氯喹产生抗药性，中国启动523联合研究项目寻找新药。屠呦呦团队查古方、测试多种草药提取物。▸线索：青蒿有时有效、有时无效。葛洪古方只说浸泡、不说煮沸，屠呦呦怀疑提取时的高温破坏了有效成分。▸突破：团队改用低温乙醚提取，1971年的样品完全抑制了感染小鼠体内的疟原虫，但小鼠有效仍不能证明人服用安全。▸验证：1972年，她与两名同事先试服，随后给21名疟疾患者使用；团队又分离出纯晶体，后来命名为青蒿素。▸影响：以青蒿素为基础、与其他药物合用的疗法获世卫推荐，挽救众多生命；屠呦呦于2015年获诺贝尔奖。）']])]

out = {'no': '28',
 'title_en': 'A Handful of Wormwood That Saved Millions',
 'title_zh': '青蒿一握，济世千万',
 'title_fx': {'hl': ['Wormwood', 'Millions'], 'ghost': []},
 'sentences': [],
 '核对确认': {'牛津逗号': {"S3 her institute's research group, despite having no doctorate or": '不是三项并列：despite '
                                                                                        '引出让步状语，后面 no '
                                                                                        'doctorate or foreign '
                                                                                        'training 只有两项',
                   'S12 to assess its toxicity, Tu and': '不是三项并列：to assess its toxicity 是目的状语，并列的只有 Tu 和 two '
                                                         'colleagues 两项'},
          '方向': {'S1-2 after→于': 'after 属于 be named after（以……命名），不是时间方向词，“得名于”方向不涉及先后'},
          '短语': {'S4 compiled … from': '不是搭配：from 属于 extracts from some 200 medicinal herbs（来自……的提取物），compiled '
                                       '的宾语是 640 prescriptions',
                 'S4 evaluated … from': '不是搭配：from 引出提取物的来源（extracts from herbs），evaluated 的宾语是 about 380 '
                                        'extracts',
                 'S5 flashes … of': '不是搭配：show flashes of promise 里 flashes 单独是“闪现”，of promise 是普通的 of '
                                    '结构（希望的闪现），已在说明里写出整句意思',
                 'S7 handbook … of': '不是搭配：of 属于引文 a handful of qinghao，和 handbook 无关',
                 'S9 degrading … to': '不是搭配：to 属于 switched to（改用），degrading 的宾语是 a delicate component',
                 'S13 administered … on': '不是搭配：on 引出时间 on 8 November，administered to 已整体标',
                 'S13 obtained … of': '不是搭配：of 属于 crystals of the substance（这种物质的晶体），obtained 的宾语是 pure '
                                      'crystals',
                 'S15 in … Physiology': '不是搭配：in 属于奖项名称 the Nobel Prize in Physiology or Medicine，不是 in flocks '
                                        '那样的固定用法',
                 'S17 essence … of': '不是搭配：the essence of A 是普通的 of 结构（A 的精髓），essence 单独是重点词',
                 'S4 an exhaustive search': '不是搭配：exhaustive 本身就是“详尽的、彻底的”，search 是普通名词“搜寻”，各自对齐即可',
                 'S7 litres … of': '不是搭配：two litres of water 是“数量 + 单位名词 + of + 物质”的普通 of 结构（两升水），litres '
                                   '单独是“升”'},
          '合组': {'S2 troops in the Vietnam War.': '对齐不了：in the Vietnam War 是后置定语修饰 troops，中文“越南战争中的部队”定语必须提前',
                 'S9 heat during extraction': '对齐不了：during extraction 是后置定语修饰 heat，中文“提取时的高温”定语必须提前',
                 'S10 the parasite in infected mice.': '对齐不了：in infected mice 是后置定语修饰 the '
                                                       'parasite，中文“受感染小鼠体内的疟原虫”定语必须提前',
                 'S11 Efficacy in mice': '对齐不了：in mice 修饰 efficacy，中文“在小鼠身上有药效”介词短语必须提前',
                 'S13 pure crystals of the substance': '对齐不了：the crystals of A 中文“A 的晶体”，of 结构语序必须倒过来',
                 "S17 The essence of Ge Hong's line": '对齐不了：the essence of A 中文“A 的精髓”，of 结构语序必须倒过来',
                 'S17 the boiling it skipped.': '对齐不了：it skipped 是定语从句修饰 the boiling，中文“它略去的煮沸”定语必须提前',
                 'S7 immersed in two litres of water".': '对齐不了：引文回译成《肘后备急方》原文“以水二升渍”，文言语序，拆开不通',
                 'S7 "a handful of qinghao': '对齐不了：qinghao 被后面的过去分词短语 immersed in two litres of water '
                                             '修饰，中文“一把浸泡在两升水中的青蒿”里“青蒿”必须放到定语后面（用户 2026-10-28 定的译文）',
                 'S7 immersed in two litres of water"': '对齐不了：后置定语 immersed in two litres of water 修饰 '
                                                        'qinghao，中文“浸泡在两升水中的青蒿”定语提前、中心词青蒿放最后，拆开语序就乱',
                 'S7 two litres of water"': '对齐不了：后置定语 immersed in two litres of water 修饰 '
                                            'qinghao，中文“浸泡在两升水中的青蒿”定语提前、中心词青蒿放最后，拆开语序就乱',
                 'S14 credited the drug with saving millions.': '对齐不了：credit A with B 中文“将 B 的功劳归功于 A”（用户 '
                                                                '2026-10-28 定），B（挽救数百万人）要提到前面、A（这种药）放最后，拆开语序就乱',
                 'S14 credited the drug with saving millions': '对齐不了：credit A with B 中文“将 B 的功劳归功于 A”（用户 '
                                                               '2026-10-28 定），B（挽救数百万人）要提到前面、A（这种药）放最后，拆开语序就乱'},
          '对齐': {'S2-2 troops in the Vietnam War.': 'in the Vietnam War 是后置定语修饰 '
                                                    'troops，中文“越南战争中的部队”定语提前，语序必须倒过来；troops、Vietnam War '
                                                    '两个重点词因此同在一组（T34 倒装）',
                 'S9-1 heat during extraction': 'during extraction 是后置定语修饰 heat，中文“提取时的高温”定语提前，语序必须倒过来',
                 'S10-1 the parasite in infected mice': 'in infected mice 是后置定语修饰 the '
                                                        'parasite，中文“受感染小鼠体内的疟原虫”定语提前，语序必须倒过来；parasite、infected '
                                                        '两个重点词因此同在一组（T34 倒装）',
                 'S11-1 Efficacy in mice': 'in mice 修饰 efficacy，中文“在小鼠身上有药效”介词短语提前，语序必须倒过来',
                 'S13-2 pure crystals of the substan': 'the crystals of A 中文“A 的晶体”，of '
                                                       '结构语序必须倒过来；crystals、substance 两个重点词因此同在一组（T34 倒装）',
                 "S17-1 The essence of Ge Hong's lin": 'the essence of A 中文“A 的精髓”，of 结构语序必须倒过来',
                 'S17-1 the boiling it skipped.': 'it skipped 是定语从句修饰 the boiling，中文“它略去的煮沸”定语提前，语序必须倒过来',
                 'S10-1 the parasite in infected mice.': 'in infected mice 是后置定语修饰 the '
                                                         'parasite，中文“受感染小鼠体内的疟原虫”定语提前，语序必须倒过来；parasite、infected '
                                                         '两个重点词因此同在一组（T34 倒装）',
                 'S13-2 pure crystals of the substance': 'the crystals of A 中文“A 的晶体”，of '
                                                         '结构语序必须倒过来；crystals、substance 两个重点词因此同在一组（T34 倒装）',
                 "S17-1 The essence of Ge Hong's line": 'the essence of A 中文“A 的精髓”，of 结构语序必须倒过来',
                 'S7-2 immersed in two litres of wate': '后置定语 immersed in two litres of water 修饰 '
                                                        'qinghao，中文“浸泡在两升水中的青蒿”定语提前，语序必须倒过来；qinghao '
                                                        '的中文“青蒿”因此放在这一组最后（用户 2026-10-28 定的译文）',
                 'S5-1 flashes of promise,': 'show flashes of promise 中文“展现出几丝成功迹象的闪光/闪现”（用户 2026-10-28 定），of '
                                             '结构语序必须倒过来；flashes、promise 两个重点词因此同在一组（T34 倒装）',
                 'S7-2 two litres of water".': '后置定语 immersed in two litres of water 修饰 '
                                               'qinghao，中文“浸泡在两升水中的青蒿”定语提前，qinghao 的中文“青蒿”放在这一组最后（用户 '
                                               '2026-10-28 定的译文）',
                 'S14-2 credited the drug with saving m': 'credit A with B 中文“将 B 的功劳归功于 A”，B 提前、A '
                                                          '放最后，语序必须倒过来（用户 2026-10-28 定的译文）',
                 'S14-2 credited the drug with saving ': 'credit A with B 中文“将 B 的功劳归功于 A”，B 提前、A '
                                                         '放最后，语序必须倒过来（用户 2026-10-28 定的译文）'},
          '非人声': {'10.33–10.37s': {'配音指纹': '68d4337c775f',
                                   '依据': '2026-10-28 28（S1 w 6.590–6.625s，噗声）：词头起始浊音：紧贴 was 的 /w/ 起音，低频重（L '
                                         '-0），周期 0.17，是 /w/ 前的浊音，不是呼吸',
                                   '实测': {'最响dB': -42.6, '重心Hz': 1918, '周期': 0.17, '低频dB': -0.2}},
                  '12.02–12.04s': {'配音指纹': '68d4337c775f',
                                   '依据': '2026-10-28 28（S1 w 8.275–8.300s，噗声）：词头起始浊音：launch 和 date 之间，周期 '
                                         '0.51、重心 990 Hz，是 date 的 /d/ 浊音起音',
                                   '实测': {'最响dB': -36.0, '重心Hz': 977, '周期': 0.51, '低频dB': -0.5}},
                  '17.80–17.82s': {'配音指纹': '68d4337c775f',
                                   '依据': '2026-10-28 28（S2 w 1.395–1.410s，噗声）：词头起始浊音：紧贴 was 的 /w/ 起音之前 15 '
                                         'ms，低频重（L -1），不是吸气（吸气低频 < -10）',
                                   '实测': {'最响dB': -46.5, '重心Hz': 2826, '周期': 0.0, '低频dB': -0.7}},
                  '33.13–33.22s': {'配音指纹': '68d4337c775f',
                                   '依据': '2026-10-28 28（S3 w 9.785–9.800s，噗声）：元音收尾：同一段 training 末尾 ŋ 收尾里的 15 '
                                         'ms，低频重（L -1），连着词',
                                   '实测': {'最响dB': -36.2, '重心Hz': 2087, '周期': 0.3, '低频dB': -2.0}},
                  '33.17–33.19s': {'配音指纹': '68d4337c775f',
                                   '依据': '2026-10-28 28（S3 w 9.785–9.800s，噗声）：元音收尾：同一段 training 末尾 ŋ 收尾里的 15 '
                                         'ms，低频重（L -1），连着词',
                                   '实测': {'最响dB': -39.1, '重心Hz': 1455, '周期': 0.0, '低频dB': -1.5}},
                  '53.64–53.66s': {'配音指纹': '68d4337c775f',
                                   '依据': '2026-10-28 28（S5 w 3.725–3.745s，噗声）：词头起始浊音：紧贴 yet 的 /j/ 起音（yet 3.75 '
                                         '起），低频重（L -0），20 ms',
                                   '实测': {'最响dB': -48.6, '重心Hz': 2341, '周期': 0.24, '低频dB': -0.2}},
                  '70.29–70.38s': {'配音指纹': '68d4337c775f',
                                   '依据': '2026-10-28 28（S7 w 9.465–9.550s，呼吸声）：元音收尾：water 末尾 ɚ 的气声收尾，低频 L '
                                         '-7、连着词，没有低谷断开',
                                   '实测': {'最响dB': -36.3, '重心Hz': 1715, '周期': 0.21, '低频dB': -6.6}},
                  '78.59–78.61s': {'配音指纹': '68d4337c775f',
                                   '依据': '2026-10-28 28（S9 w 4.875–4.890s，噗声）：塞音除阻：component 的 /t/ 除阻，15 ms',
                                   '实测': {'最响dB': -49.8, '重心Hz': 2440, '周期': 0.0, '低频dB': -0.3}},
                  '96.64–96.79s': {'配音指纹': '68d4337c775f',
                                   '依据': '2026-10-28 28（S11 w 1.415–1.560s，起音前过长）：词头前底噪：已删的吸气（w '
                                         '1.2375–1.39）之后到 indicated 起音之间的静音底噪，平均 -55 dB，逐段看声音实测 -56 到 -72 '
                                         'dB，没有呼吸',
                                   '实测': {'最响dB': -54.8, '重心Hz': 0, '周期': 0.0, '低频dB': 0.0}},
                  '107.79–107.81s': {'配音指纹': '68d4337c775f',
                                     '依据': '2026-10-28 28（S12 w 7.640–7.660s，孤立杂音）：塞音除阻：extract 末尾 /kt/ 的 /t/ '
                                           '除阻，20 ms',
                                     '实测': {'最响dB': -48.6, '重心Hz': 1731, '周期': 0.24, '低频dB': -5.1}},
                  '123.88–123.89s': {'配音指纹': '68d4337c775f',
                                     '依据': '2026-10-28 28（S14 w 0.370–0.380s，孤立杂音）：塞音除阻：September 的 /p/ 除阻，10 '
                                           'ms，重心 3739 Hz',
                                     '实测': {'最响dB': -33.3, '重心Hz': 3738, '周期': 0.0, '低频dB': -26.3}},
                  '125.83–125.87s': {'配音指纹': '68d4337c775f',
                                     '依据': '2026-10-28 28（S14 w 2.375–2.415s，孤立杂音）：鼻音收尾：同上 eleven 末尾 /n/，同一段',
                                     '实测': {'最响dB': -39.3, '重心Hz': 1702, '周期': 0.48, '低频dB': -0.1}},
                  '157.22–157.23s': {'配音指纹': '68d4337c775f',
                                     '依据': '2026-10-28 28（S17 w 3.160–3.170s，孤立杂音）：塞音除阻：skipped 的 /p/ 除阻，10 ms',
                                     '实测': {'最响dB': -35.7, '重心Hz': 2159, '周期': 0.0, '低频dB': -17.9}},
                  '157.26–157.30s': {'配音指纹': '68d4337c775f',
                                     '依据': '2026-10-28 28（S17 w 3.200–3.245s，孤立杂音）：塞音除阻：skipped 末尾 /t/ 除阻，45 '
                                           'ms，重心 3278 Hz',
                                     '实测': {'最响dB': -30.1, '重心Hz': 3277, '周期': 0.2, '低频dB': -14.1}}},
          '停顿位置': {'S5 Qinghao, / or @0.680': '2026-10-28 逐段看声音实测（S5 w）：Qinghao 末尾 aʊ 到 0.675s 降到 -34 '
                                              'dB，0.680s 是两词之间最低处 -45.0 dB，0.690s 起 or 的元音回升到 -29 '
                                              'dB；元音接元音没有静音，插在交界最低点（A42）',
                   'S5 wormwood, / showed @1.765': '2026-10-28 逐段看声音实测（S5 w）：wormwood 的 /d/ 闭塞 1.745–1.765s 在 '
                                                   '-28 到 -33 dB，1.770s 起 showed 的 /ʃ/（低频 -15 到 -50 dB '
                                                   '的擦音）开始；插在 /d/ 之后、/ʃ/ 之前的交界（A42）',
                   'S9 component, / so @4.545': '2026-10-28 逐段看声音实测（S9 w）：删的 4.545–4.865s 全在 component '
                                                '之后的停顿里，4.500–4.610s 是 -52 到 -58 dB 静音，4.605–4.865s '
                                                '是程序已定的非人声区间（吸气，换成静音），so 在 4.98s 才开口，删掉的没有词的声音'},
          '删除段': {'S1 raw 6.2551-6.5950': {'类型': '紧贴词尾的非人声',
                                           '配音指纹': '68d4337c775f',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[6.245125, 6.585, '紧贴词尾']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['lost'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S3 raw 6.4950-6.9250': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '68d4337c775f',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[6.655, 6.88875, '紧贴词头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['lost'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S7 raw 4.7001-4.9250': '2026-10-15 删除段对应 非人声区间 [[4.675, 4.875]]（w 秒）：自动切点.py '
                                          '用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < -10 dB、周期 < '
                                          "0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms 内最安静处的过零点；复核报 ['lost'] "
                                          '是删掉的呼吸声本身偏响（-34～-47 dB），不是词',
                  'S7 raw 7.3140-7.5650': {'类型': '紧贴词尾的非人声',
                                           '配音指纹': '68d4337c775f',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[7.264, 7.495, '紧贴词尾']]（w 秒）：自动切点.py "
                                                 '用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < -10 dB、周期 < '
                                                 '0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms 内最安静处的过零点；复核报 '
                                                 "['lost', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S12 raw 2.0715-2.3700': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '68d4337c775f',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[2.071375, 2.35, '紧贴词尾']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S13 raw 2.3740-2.7350': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '68d4337c775f',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[2.364, 2.725, '紧贴词尾']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S14 raw 2.1665-2.3900': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': '68d4337c775f',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[2.146542, 2.365, '紧贴词尾']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['pre'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S4 raw 7.9900-8.3635': {'类型': '紧贴词头的非人声',
                                           '配音指纹': '68d4337c775f',
                                           '依据': "2026-10-15 删除段对应 非人声区间 [[7.935, 8.303458, '紧贴词头']]（w "
                                                 '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                 '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                 "内最安静处的过零点；复核报 ['lost', 'post'] 是删掉的呼吸声本身偏响（-34～-47 dB），不是词"},
                  'S16 raw 7.3800-7.7250': '2026-10-15 删除段对应 非人声区间 [[7.385, 7.715]]（w 秒）：自动切点.py '
                                           '用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < -10 dB、周期 < '
                                           "0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms 内最安静处的过零点；复核报 ['lost'] "
                                           '是删掉的呼吸声本身偏响（-34～-47 dB），不是词'}},
 '结尾解说': '简述',
 '高亮按实际开口': True,
 '高亮开口门槛': 40,
 '术语': {'Project 523': '523项目',
        'Vietnam War': '越南战争',
        'Tu Youyou': '屠呦呦',
        'Qinghao': '青蒿',
        'Ge Hong': '葛洪',
        'Hainan': '海南',
        'Lasker Award': '拉斯克奖',
        'Nobel Prize': '诺贝尔',
        'WHO': '世界卫生组织',
        'artemisinin': '青蒿素',
        'chloroquine': '氯喹',
        'Celsius': '摄氏度'},
 '非人声区间': {'S9': [[4.605, 4.865], [6.45, 6.63875, '紧贴词头']],
           'S10': [[2.93, 3.045], [5.055, 5.34]],
           'S14': [[2.146542, 2.365, '紧贴词尾']],
           'S7': [[4.675, 4.875], [7.264, 7.495, '紧贴词尾']],
           'S15': [[2.565, 2.84]],
           'S12': [[2.071375, 2.35, '紧贴词尾']],
           'S2': [[1.155, 1.3725]],
           'S11': [[1.2375, 1.39]],
           'S1': [[6.245125, 6.585, '紧贴词尾']],
           'S3': [[6.655, 6.88875, '紧贴词头']],
           'S13': [[2.364, 2.725, '紧贴词尾'], [6.905, 7.075]],
           'S4': [[7.935, 8.303458, '紧贴词头']],
           'S16': [[7.385, 7.715]]},
 '词尾除阻': {'S1': {'3': [8.565, 't']},
          'S9': {'1': [4.47, 't']},
          'S12': {'句末': [7.74, 't']},
          'S14': {'1': [5.085, 't']},
          'S5': {'句末': [5.335, 'k']},
          'S15': {'句末': [9.69, 't']}},
 '区间声音指纹': {'S1': '775bade3b816',
            'S2': 'abd6a7434630',
            'S3': '01c9f8db9510',
            'S4': '7728d1840599',
            'S5': '094c0548ba21',
            'S7': 'bfd54cf115d8',
            'S9': '09009ca6c118',
            'S10': '295124235dbf',
            'S11': 'd6cd59c6fb13',
            'S12': '1428b93a9849',
            'S13': 'a69ce3dda7dd',
            'S14': 'e78cb9befbc7',
            'S15': '78d2bfd1ae12',
            'S16': '46eb4f875828'},
 '合成标点': {'S3': [['group, despite', 'group; despite']],
          'S13': [['Hainan, and', 'Hainan; and']],
          'S4': [['recipes, compiled', 'recipes; compiled']]},
 '除阻加强': {'S3': {'1': [6.44, 6.47, 4.5]}},
 'allow_clash': ['extracts', 'switched to'],
 '说明放宽特批': {'S17': {'倍数': '整屏',
                    '依据': '用户 2026-10-28 原话（直接对本会话说，用户同意 S17 结尾简述整屏，特批）：“第17句的简述铺满整屏，同意放宽”；用户 2026-10-28 原话（看 '
                          '28 S17 '
                          '结尾简述整屏截图，待改清单第23条）：“重新排版一下这个，重新排版一下，这个下面的这些行数实在太多了，尽可能的让这些所有的空间利用起来，ok。不要这个样子，就是尽量让字体能够每一个字体能够在这个空间里面最大化。”'}},
 '换行变更记录': [{'日期': '2026-10-28',
             'S5': '用户 2026-10-28 原话（直接对本会话说）：“第5句的分组照现在这样改”；用户 2026-10-28 原话：“展现出几丝 成功迹象 '
                   '的闪光/闪现。Promise对应成功迹象。Promise在这个地方，在这个地方标为重点词汇，对应的意思为成功迹象。这个是特批的，这个是特批的。”'}]}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
