#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('On 23 June 2018,', '2018年6月23日，'),
     ('twelve boys', '12名男孩，'),
     ('aged', '年龄'),
     ('11 to 16', '在11至16岁，'),
     ('from a', '来自一支'),
     ('**junior**', '**青少年**(junior)'),
     ('football', '足球'),
     ('**squad**', '**小队**(squad)，')],
    '（aged 11 to 16：后置定语，修饰 twelve boys；\nfrom a junior football squad：介词短语作后置定语）'],
   [[('**went on an outing**', '**外出郊游**(went on an outing)，'),
     ('with', '同行的是'),
     ('their', '他们'),
     ('25-year-old', '25岁的'),
     ('**assistant coach**.', '**助理教练**(assistant coach)。')],
    '（go on an outing：外出郊游；\nwith…：介词短语，交代和谁一起）']]),
 (1,
  [[[('They', '他们'), ('**entered**', '**进入了**(entered)'), ('Tham Luang,', '睡美人洞，')],
    '（Tham Luang：睡美人洞，泰国北部的洞穴）'],
   [[('a **sprawling** **maze** of **tunnels**', '那是一座由**隧道**(tunnels)构成、**向四周分散延伸的**(sprawling)**迷宫**(maze)，'),
     ('in northern Thailand,', '位于泰国北部；')],
    '（a sprawling maze of tunnels…：同位语，补充说明 Tham Luang；\nsprawling：杂乱延伸的）'],
   [[('to **penetrate**', '他们想要**穿透/深入**(penetrate)'), ('its **gloom**.', '洞中的**幽暗**(gloom)。')],
    '（to penetrate its gloom：不定式作目的状语；\nits 指 Tham Luang）']]),
 (1,
  [[[('**Monsoon** rain', '**季风**(Monsoon)带来的雨水'),
     ('then', '随后'),
     ('**flooded**', '**淹没了**(flooded)'),
     ('the **passages**,', '**通道**(passages)，')],
    '（monsoon rain：季风带来的降雨）'],
   [[('and', '而'), ('the rising', '上涨的'), ('water', '水'), ('trapped all of them.', '把他们全部困住了。')],
    '（trap：困住；\nall of them：他们全部，指男孩们和教练）']]),
 (2,
  [[[('For nine days', '九天里，'), ('their **whereabouts**', '他们的**下落**(whereabouts)'), ('were unknown.', '不明。')],
    '（for nine days：时间状语，表示持续九天；\nwhereabouts：下落，行踪，这里谓语用复数 were）']]),
 (2,
  [[[('On 2 July', '7月2日，'),
     ('two', '两名'),
     ('**elite** British', '英国**精英**(elite)'),
     ('**divers**,', '**潜水员**(divers)')],
    '（elite：精英的，作定语）'],
   [[('**threading through**', '**穿过**(threading through)'),
     ('**submerged**', '**水下**(submerged)'),
     ('**passages**,', '**通道**(passages)，')],
    '（threading through…：现在分词短语作伴随状语；\nthread through：穿行于）'],
   [[('reached', '到达'),
     ('an **inundated** chamber', '一个**被淹的**(inundated)洞室，'),
     ('about 4 km from the **entrance**.', '距离洞穴的**入口**(entrance)大约4公里。')],
    '（about 4 km from the entrance：后置定语，修饰 chamber；\nkm：kilometres 的缩写）']]),
 (2,
  [[[('All 13', '13人'), ('were there,', '都在那里，')], '（All 13：13人全部；\nthere 指被淹的洞室）'],
   [[('**huddled**', '**挤在一起**(huddled)'),
     ('on a', '在一处'),
     ('**muddy**', '**泥泞的**(muddy)'),
     ('**mound**', '**土堆**(mound)上，')],
    '（huddled…and perched…：\n两个过去分词短语作状语，\n描写他们的状态）'],
   [[('and **perched**', '刚好**栖身**(perched)'), ('just above the water,', '于水面之上，')], '（perch：暂栖，处于高处）'],
   [[('every one of them', '他们每个人'), ('**alive**.', '都还**活着**(alive)。')],
    '（every one of them alive：独立主格结构，\n补充说明全员的状况）']]),
 (3,
  [[[('The only **exit**', '唯一的**出口**(exit)'),
     ('**ran through**', '要**穿过**(ran through)'),
     ('**kilometres** of', '数**公里**(kilometres)'),
     ('**constricted**,', '**狭窄**(constricted)且'),
     ('**treacherous**', '**暗藏危险的**(treacherous)'),
     ('**passages**,', '**通道**(passages)，')],
    '（kilometres of…：数公里的……；\nconstricted, treacherous：两个形容词并列修饰 passages）'],
   [[('many of them', '其中许多段'),
     ('**navigable** only with **scuba** gear.', '只有借助**水肺**(scuba)装备才能**通行**(navigable)。')],
    '（many of them navigable…：独立主格结构，them 指 passages；\n'
    'scuba：水肺，自携式水下呼吸器；\n'
    'navigable：指水域或通道是“可以通行的”或“能够被穿越的”）']]),
 (3,
  [[[('**Rescuers**', '**救援人员**(Rescuers)'),
     ('began', '开始'),
     ('**stockpiling**', '**储备**(stockpiling)'),
     ('oxygen', '氧气'),
     ('**cylinders**', '**钢瓶**(cylinders)，'),
     ('**along the route**.', '放在**沿途**(along the route)。')],
    '（begin doing：开始做某事；\nalong the route：沿途，地点状语）']]),
 (3,
  [[[('On 6 July', '7月6日，'),
     ('Saman Kunan,', '萨曼·古南，'),
     ('a', '一名'),
     ('**former**', '**前**(former)'),
     ('Thai Navy SEAL,', '泰国海军海豹突击队员，')],
    '（a former Thai Navy SEAL：同位语，补充说明 Saman Kunan；\nNavy SEAL：海军海豹突击队员）'],
   [[('fell **unconscious** while laying them', '在布放钢瓶时**失去知觉**(unconscious)，'), ('and died.', '随后死亡。')],
    '（fall unconscious：失去知觉，fall 这里是系动词；\nwhile laying them：时间状语，them 指氧气钢瓶）']]),
 (4,
  [[[('The **evacuation**', '**撤离**(evacuation)'), ('began', '开始'), ('on 8 July,', '于7月8日，')],
    '（on 8 July：时间状语）'],
   [[('and the boys', '男孩们'), ('came out **in batches**.', '**分批**(in batches)出洞。')],
    '（in batches：分批，一批一批地）']]),
 (4,
  [[[('Each', '每人'),
     ('was given', '都用了'),
     ('**doses**', '**数剂**(doses)'),
     ('of **sedative**,', '**镇静药**(sedative)，')],
    '（was given…, wrapped…, and passed…：\n三个被动谓语并列；\ndoses of sedative：数剂镇静药）'],
   [[('**wrapped** **motionless**', '**一动不动地**(motionless)**包裹**(wrapped)'),
     ('in a **stretcher**,', '在**担架**(stretcher)里，')],
    '（motionless：形容词补充说明状态，一动不动的）'],
   [[('and passed from diver to diver,', '由潜水员一个接一个传递出去，')], '（from diver to diver：从一名潜水员到另一名潜水员）'],
   [[('with **medics**', '伴随着**医护人员**(medics)'),
     ('**stationed**', '**驻守**(stationed)在'),
     ('**along the route**.', '**沿途**(along the route)。')],
    '（with medics stationed…：with 复合结构作伴随状语，\nstationed 是过去分词，表示被安排驻守）']]),
 (4,
  [[[('On 10 July', '7月10日，'),
     ('the last four **footballers**', '最后四名**小球员**(footballers)'),
     ('and their coach', '和教练')],
    '（the last four footballers and their coach：并列主语）'],
   [[('were **escorted** out after their **teammates**.', '继**队友**(teammates)之后被**护送**(escorted)出洞。')],
    '（escort out：护送出去；\nafter their teammates：在队友之后）']]),
 (5,
  [[[('The **multinational**', '这场**多国的**(multinational)'),
     ('**mobilisation**', '**动员**(mobilisation)'),
     ('was', '被堪称为'),
     ('a feat of **logistics**.', '一场**后勤**(logistics)壮举。')],
    '（a feat of…：……方面的壮举；\nmobilisation：英式拼写，美式作 mobilization）']]),
 (5,
  [[[('Some 10,000 people', '约1万人'), ('**converged on** the site,', '**汇集到**(converged on)现场，')],
    '（some：用在数字前，表示大约；\nconverge on…：汇集到……）'],
   [[('including', '其中包括'), ('a **contingent** of more than 100 divers,', '一支100多名潜水员组成的**分队**(contingent)，')],
    '（including…：补充说明这1万人的组成；\na contingent of…：一支由……组成的分队）'],
   [[('plus', '另有'), ('2,000 soldiers', '2,000名士兵'), ('and 900 **policemen**,', '和900名**警察**(policemen)，')],
    '（plus：另外还有，引出补充的人数）'],
   [[('with teams', '还有一些救援小组，'), ('**deployed** from abroad.', '从国外**调派**(deployed)而来。')],
    '（with teams deployed…：with 复合结构，deployed 是过去分词；\nfrom abroad：从国外）']]),
 (5,
  [[[('The rescue', '这次救援'),
     ('had', '留下了'),
     ('a **sobering**', '一个**令人警醒的**(sobering)'),
     ('**postscript**:', '**后续**(postscript)：')],
    '（postscript：后记，这里指事后发生的事；\n冒号后面交代这个后续）'],
   [[('in December 2019', '2019年12月，'),
     ('another Navy SEAL', '又一名海军海豹突击队员'),
     ('died of', '死于'),
     ('a **blood infection** caught during the operation.', '在救援中染上的**血液感染**(blood infection)。')],
    '（die of…：死于（疾病）；\ncaught during the operation：过去分词短语作后置定语，修饰 infection）']]),
 (5,
  [[[('Every boy', '每个男孩'), ('came home alive,', '都活着回到了家，')], '（alive：形容词，补充说明回家时的状态）'],
   [[('and', '而'), ('two rescuers', '两名救援者'), ('were **mourned**.', '却只能永远被**悼念**(mourned)。')],
    '（were mourned：被动语态，被悼念；\n'
    '两名救援者指萨曼·古南和2019年去世的海豹队员）\n'
    '（简述：▸被困：2018年，泰国12名少年球员和助理教练进入睡美人洞，因季风雨淹没通道而受困。▸发现：失联九天后，两名英国潜水员在距洞口约4公里处找到他们，十三人全部活着。▸难题：救援需穿过数公里狭窄水道；约万人的多国队伍沿途布放气瓶，协调百余名潜水员。▸救出：7月8日至10日，男孩用镇静药后固定在担架中，由潜水员接力带出，沿途有医护协助。▸代价：十三人全获救；救援者萨曼·古南在前期布气瓶时遇难，另一名救援队员2019年死于救援时染上的血液感染。）']])]

out = {'no': '33',
 'title_en': 'Thirteen in the Cave',
 'title_zh': '洞穴里的十三个人',
 'title_fx': {'hl': ['Thirteen', 'Cave'], 'ghost': []},
 'sentences': [],
 '核对确认': {'合组': {'S3 trapped all of them': '对齐不了：trap A 中文“把 A 困住”，宾语 all of them 必须提到动词前，拆开语序就乱',
                 'S6 just above the water': '对齐不了：above the water 中文“于水面之上”，方位词“之上”必须放到名词后',
                 'S9 fell unconscious while laying them': '对齐不了：while 从句作时间状语，中文“在布放钢瓶时失去知觉”时间必须放到动词前',
                 'S11 and passed from diver to diver': '对齐不了：from diver to diver '
                                                       '是方式状语，中文“由潜水员一个接一个传递出去”必须放到动词前',
                 'S14 deployed from abroad': '对齐不了：from abroad 是来源状语，中文“从国外调派而来”必须放到动词前',
                 'S15 a blood infection caught during the operation': '对齐不了：caught during the operation '
                                                                      '是过去分词短语作后置定语，中文“在救援中染上的血液感染”定语必须提前',
                 'S8 along the route': '对齐不了：along the route 中文就是“沿途”一个词，拆开不通',
                 'S11 along the route': '对齐不了：along the route 中文就是“沿途”一个词，拆开不通',
                 'S16 came home alive': '对齐不了：alive 补充说明回家时的状态，中文“活着回到了家”状态必须放到动词前'},
          '数字写法': {'S1-1 twelve': '文章定稿中文写“12名”，数值相同（twelve = 12）',
                   'S5-1 two': '“7月2日”是日期 2 July；two divers 中文“两名”，数值相同'},
          '数字': {'S14-1 10,000': 'Some 10,000 中文按文章定稿写作“约1万”，数值相同（10,000 = 1万）'},
          '词性': {'S11-2 motionless 一动不动地': '文章定稿译法“一动不动地包裹在担架里”（铁律：定稿中文意思不改）；motionless '
                                           '补充说明被包裹时的状态，中文化成状语，意思一样'},
          '对齐': {'S9-1 a former Thai Navy SEAL,': 'former Thai Navy SEAL 是一个身份名词，中文“前泰国海军海豹突击队员”一个称谓，拆开不通',
                 'S1-2 with their 25-year-old assista': '已拆到词：with 同行的是、their 他们、25-year-old 25岁的、assistant '
                                                        'coach 助理教练',
                 'S2-2 a sprawling maze of tunnels': 'maze of tunnels 是 of 结构，中文“由隧道构成的迷宫”语序必须倒过来；sprawling '
                                                     '是前置定语，文章定稿“由隧道构成、向四周分散延伸的迷宫”两个定语并列放在迷宫前',
                 'S5-3 about 4 km from the entrance.': 'about 4 km from the entrance '
                                                       '是后置定语，中文“距离洞穴的入口大约4公里”from 结构必须提前',
                 'S7-2 navigable only with scuba gear': 'only with scuba gear 是条件状语，中文“只有借助水肺装备才能通行”状语必须放到动词前',
                 'S9-2 fell unconscious while laying ': 'while 从句作时间状语，中文“在布放钢瓶时失去知觉”时间必须放到动词前',
                 'S11-3 and passed from diver to diver': 'from diver to diver 是方式状语，中文“由潜水员一个接一个传递出去”必须放到动词前',
                 'S12-2 were escorted out after their ': 'after their teammates 是时间状语，中文“继队友之后被护送出洞”状语必须放到动词前',
                 'S14-2 a contingent of more than 100 ': 'a contingent of A 是 of 结构，中文“一支 A 组成的分队”语序必须倒过来',
                 'S14-4 deployed from abroad.': 'from abroad 是来源状语，中文“从国外调派而来”必须放到动词前',
                 'S15-2 a blood infection caught durin': 'caught during the operation '
                                                         '是后置定语，中文“在救援中染上的血液感染”定语必须提前'},
          '短语': {'S2 maze … of': '不是搭配：a maze of tunnels 是普通 of 结构（由隧道构成的迷宫），maze 单独就是“迷宫”',
                 'S3 flooded … of': '不是搭配：of 属于后一分句的 all of them，和 flooded 无关',
                 'S6 huddled … on': '不是搭配：on 引出地点（a muddy mound）；huddle 单独就是“蜷缩”',
                 'S6 mound … of': '不是搭配：of 属于后面的 every one of them，和 mound 无关',
                 'S6 perched … of': '不是搭配：of 属于后面的 every one of them，和 perched 无关',
                 'S7 kilometres … of': '不是搭配：kilometres of A 是普通 of 结构（数公里的 A），kilometres 单独就是“公里”',
                 'S7 with … scuba': '不是搭配：with 是普通介词“借助”，with scuba gear 是 with + 名词短语，scuba 修饰 gear',
                 'S11 doses … of': '不是搭配：doses of sedative 是普通 of 结构（数剂镇静药），dose 单独就是“剂”',
                 'S11 wrapped … from': '不是搭配：from 属于 passed from diver to diver，和 wrapped 无关',
                 'S11 wrapped … in': '不是搭配：in 引出包裹所用的东西（a stretcher）；wrap 单独就是“包裹”，速查表 be wrapped in a blanket '
                                     '里 in 也是普通介词',
                 'S11 wrapped … to': '不是搭配：to 属于 from diver to diver，和 wrapped 无关',
                 'S11 with … medics': '不是搭配：with medics stationed… 是 with 复合结构，with 不和 medics 构成固定用法',
                 'S12 escorted … out': '不是搭配：out 是普通方向副词（出来，中文“出洞”），escort 单独就是“护送”，速查表 be escorted by police',
                 'S13 mobilisation … of': '不是搭配：of 属于 a feat of logistics，和 mobilisation 无关',
                 'S14 converged … of': '不是搭配：converged on 已整体标；of 属于 a contingent of more than 100 divers',
                 'S14 contingent … of': '不是搭配：a contingent of A 是普通 of 结构（一支 A 组成的分队），速查表 a contingent of '
                                        'troops/fans，contingent 单独就是“分队”',
                 'S2 entered … of': '不是搭配：of 属于后面的 a sprawling maze of tunnels，entered 的宾语是 Tham Luang',
                 'S14 deployed … from': '不是搭配：from 引出来源（abroad）；deploy 单独就是“调派”'},
          '删除段': {'S1 raw 7.6050-7.8950': '2026-10-15 删除段对应 非人声区间 [[7.615, 7.895]]（w 秒）：自动切点.py '
                                          '用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < -10 dB、周期 < '
                                          "0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms 内最安静处的过零点；复核报 ['lost'] "
                                          '是删掉的呼吸声本身偏响（-34～-47 dB），不是词；2026-10-29 33 逐 10 ms 实测（S1 w '
                                          '7.63–7.88）：squad 的 /d/ 在 w 7.59 降到 -48、7.60 -57 dB，之后 -40～-47 dB、周期 '
                                          '0.15–0.33、重心 2.1–3.2 kHz、低频 -9～-24 dB 是吸气；w 7.90 起 -54、7.92 '
                                          '起低频占优的浊音是 went 的 /w/ 起始，没删',
                  'S2 raw 5.0550-5.3050': '2026-10-15 删除段对应 非人声区间 [[5.045, 5.285]]（w 秒）：自动切点.py '
                                          '用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < -10 dB、周期 < '
                                          "0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms 内最安静处的过零点；复核报 ['lost'] "
                                          '是删掉的呼吸声本身偏响（-34～-47 dB），不是词；2026-10-29 33 实测（S2 w '
                                          '5.05–5.21）：Thailand 的 /d/ 在 w 5.03–5.04 降到 -56/-58 dB，之后 -39～-47 '
                                          'dB、周期 ≤0.36、重心 2.5–3.3 kHz 是吸气；to 的 /t/ 除阻 w 5.29（5.5 kHz）完整保留',
                  'S11 raw 4.4550-4.7861': {'类型': '紧贴词头的非人声',
                                            '配音指纹': 'fc0c3231837f',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[4.47, 4.786125, '紧贴词头']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost', 'post'] 是删掉的呼吸声本身偏响（-34～-47 "
                                                  'dB），不是词；2026-10-29 33 实测（S11 w 4.50–4.75）：stretcher 的 ɚ 在 w '
                                                  '4.45 降到 -57 dB，之后 -37～-51 dB、周期 ≤0.38、重心 2.1–3.1 kHz、低频 '
                                                  '-8～-24 dB 是吸气；切点后 w 4.79–4.80 低频占优（-1～-3 dB）的浊音是 and '
                                                  '的起始，保留，and 的元音 w 4.81 起完整'},
                  'S14 raw 10.6600-11.0062': {'类型': '紧贴词头的非人声',
                                              '配音指纹': 'fc0c3231837f',
                                              '依据': "2026-10-15 删除段对应 非人声区间 [[10.705, 11.006167, '紧贴词头']]（w "
                                                    '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 '
                                                    '< -10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                    "内最安静处的过零点；复核报 ['lost', 'post'] 是删掉的呼吸声本身偏响（-34～-47 "
                                                    'dB），不是词；2026-10-29 33 实测（S14 w 10.74–10.97）：policemen 的 '
                                                    '/n/ 在 w 10.63 后降到 -53～-64 dB，之后 -41～-54 dB、周期 ≤0.34、重心 '
                                                    '2.3–3.2 kHz、低频 -10～-27 dB 是吸气；切点后 w 11.006–11.03 低频占优的浊音是 '
                                                    'with 的 /w/ 起始，保留'},
                  'S15 raw 4.8765-5.0400': {'类型': '紧贴词尾的非人声',
                                            '配音指纹': 'fc0c3231837f',
                                            '依据': "2026-10-15 删除段对应 非人声区间 [[4.866458, 5.025, '紧贴词尾']]（w "
                                                  '秒）：自动切点.py 用实际声音按规则判定是吸气声/噗声（听得见的部分七成以上重心 1.8–3.8 kHz、低频 < '
                                                  '-10 dB、周期 < 0.35，没有连续 20 ms >4 kHz 的擦音），贴词一侧切在紧挨词 40 ms '
                                                  "内最安静处的过零点；复核报 ['lost', 'pre'] 是删掉的呼吸声本身偏响（-34～-47 "
                                                  'dB），不是词；2026-10-29 33 这一段是我实测后写的（不是自动切点）：nineteen 的 /n/ 到 w '
                                                  '4.8625 还是 -27 dB、重心 0.7–0.9 kHz、周期 0.3–0.4；w 4.865 起重心跳到 '
                                                  '1.6–3.1 kHz、周期降到 0.10–0.24、低频 -2～-26 dB，到 4.985 一直 -36～-44 '
                                                  'dB，是吸气（原文 2019 another 中间无标点）；切点 w 4.866458 是过零点，/n/ '
                                                  '本身不动；右边 w 5.025 降到 -55 dB，another 从 w 5.035 起完整。复核把它算成 '
                                                  'nineteen 的词尾 115 ms，是因为吸气和 /n/ 之间没有 -55 dB 低谷'}},
          '非人声': {'9.35–9.38s': {'配音指纹': 'fc0c3231837f',
                                 '依据': '2026-10-29 33（S1 w 6.79–6.82）逐 10 ms 实测：football 中间 /t/ 闭塞之后、/b/ '
                                       '除阻之前的浊音杠：周期 0.42–0.66、低频 -1～-2 dB 占优，w 6.82 起 /b/ 除阻 -22 dB，属于 '
                                       'football',
                                 '实测': {'最响dB': -40.5, '重心Hz': 1163, '周期': 0.65, '低频dB': -0.2}},
                  '10.34–10.38s': {'配音指纹': 'fc0c3231837f',
                                   '依据': '2026-10-29 33（S1 w 7.90–7.935）逐 10 ms 实测：went 的 /w/ 起始浊音：低频 -0～-2 dB '
                                         '占优、周期 0.4–0.5，w 7.95 起 -29 dB、7.97 起 -7 dB 是同一个词，属于 went',
                                   '实测': {'最响dB': -42.6, '重心Hz': 1955, '周期': 0.38, '低频dB': -0.1}},
                  '20.77–20.79s': {'配音指纹': 'fc0c3231837f',
                                   '依据': '2026-10-29 33（S2 w 5.42–5.44）逐 10 ms 实测：penetrate 的 /p/ 除阻起始：to 在 w '
                                         '5.39 收尾，5.40–5.42 降到 -52～-55 dB，5.43 -41 dB 之后 5.44 是 -15 dB、3.9 kHz '
                                         '的 /p/ 爆破，属于 penetrate',
                                   '实测': {'最响dB': -41.4, '重心Hz': 2190, '周期': 0.26, '低频dB': -0.4}},
                  '32.04–32.17s': {'配音指纹': 'fc0c3231837f',
                                   '依据': '2026-10-29 33（S4 w 2.475–2.605）逐 10 ms 实测：unknown. 句尾 /n/ 的自然衰减：w '
                                         '2.515–2.535 周期 0.59–0.68 还是浊音，从 -20 dB 连续降到 2.605 的 -56 '
                                         'dB，中间没有断开；试切过（w 2.5427 起），音频体检报“句尾截断 -38.5 dB”，证明是词尾，已撤回',
                                   '实测': {'最响dB': -35.6, '重心Hz': 1794, '周期': 0.3, '低频dB': -8.4}},
                  '43.73–43.81s': {'配音指纹': 'fc0c3231837f',
                                   '依据': '2026-10-29 33（S5 w 10.51–10.595）逐 10 ms 实测：entrance 的 /n/ 衰减到 '
                                         '/s/：/n/ 从 w 10.43 的 -15 dB 连续降到 10.59 的 -45 dB，10.60–10.61 -56/-63 '
                                         'dB，10.62 起是 /s/（5–6 kHz），属于 entrance',
                                   '实测': {'最响dB': -37.3, '重心Hz': 1790, '周期': 0.29, '低频dB': -3.5}},
                  '35.91–35.93s': {'配音指纹': 'fc0c3231837f',
                                   '依据': '2026-10-29 33（S5 w 2.765–2.785）逐 10 ms 实测：divers 的 /d/ 浊音杠：British 的 '
                                         '/ʃ/（4.5–5 kHz）在 w 2.75–2.76 降到 -54 dB，2.77–2.82 重心 0.3–0.4 kHz、低频 '
                                         '-1～-2 dB 占优，2.83 起 /d/ 除阻，属于 divers',
                                   '实测': {'最响dB': -31.1, '重心Hz': 627, '周期': 0.0, '低频dB': -1.3}},
                  '48.85–48.87s': {'配音指纹': 'fc0c3231837f',
                                   '依据': '2026-10-29 33（S6 w 3.80–3.82）逐 10 ms 实测：just 的 /dʒ/ 浊音杠：perched 的 '
                                         '/t/ 除阻 w 3.72 之后 3.74–3.79 -54～-64 dB，3.80–3.81 低频 -2 dB 占优、周期 '
                                         '0.40–0.45，3.82 起 /dʒ/ 擦音（3–5 kHz），属于 just',
                                   '实测': {'最响dB': -44.5, '重心Hz': 2010, '周期': 0.43, '低频dB': -0.8}},
                  '66.00–66.08s': {'配音指纹': 'fc0c3231837f',
                                   '依据': '2026-10-29 33（S8 w 3.905–3.985）逐 10 ms 实测：route. 里 /aʊ/ 到 /t/ '
                                         '闭塞前的衰减：从 w 3.825 的 -16 dB 连续降到 3.985 的 -59 dB，重心 1.0–2.4 kHz、周期 '
                                         '0.24–0.47，之后 /t/ 闭塞，4.035 是 /t/ 除阻，属于 route',
                                   '实测': {'最响dB': -35.7, '重心Hz': 1515, '周期': 0.27, '低频dB': -7.4}},
                  '63.54–63.56s': {'配音指纹': 'fc0c3231837f',
                                   '依据': '2026-10-29 33（S8 w 1.39–1.415）逐 10 ms 实测：stockpiling 的 /k/ 除阻：/ɑː/ 在 '
                                         'w 1.35–1.38 降到 -55 dB（/k/ 闭塞），1.39–1.41 -45～-50 dB 是 /k/ '
                                         '除阻，1.42–1.44 /p/ 闭塞，1.45 /p/ 爆破，属于 stockpiling',
                                   '实测': {'最响dB': -45.1, '重心Hz': 1327, '周期': 0.18, '低频dB': -5.7}},
                  '84.98–85.00s': {'配音指纹': 'fc0c3231837f',
                                   '依据': '2026-10-29 33（S11 w 2.865–2.885）逐 10 ms 实测：wrapped 的 /p/ 除阻：/æ/ 在 w '
                                         '2.85 降到 -55 dB（/p/ 闭塞），2.87 是 -28 dB、4 kHz、无周期的爆破，2.89–2.90 /t/ '
                                         '闭塞，2.91 /t/ 除阻，属于 wrapped',
                                   '实测': {'最响dB': -30.7, '重心Hz': 3422, '周期': 0.0, '低频dB': -20.7}},
                  '102.81–102.83s': {'配音指纹': 'fc0c3231837f',
                                     '依据': '2026-10-29 33（S13 w 3.615–3.635）逐 10 ms 实测：logistics 中间 /ɪ/ 到 /k/ '
                                           '闭塞前的衰减：从 w 3.54 的 -22 dB 连续降到 3.63 的 -53 dB，之后 /k/ 闭塞，3.69 /k/ '
                                           '爆破，属于 logistics',
                                     '实测': {'最响dB': -41.7, '重心Hz': 2517, '周期': 0.0, '低频dB': -1.2}},
                  '120.59–120.61s': {'配音指纹': 'fc0c3231837f',
                                     '依据': '2026-10-29 33（S15 w 2.33–2.345）逐 10 ms 实测：postscript 的 /p/ 除阻：/ɪ/ '
                                           '在 w 2.285 降到 -57 dB（/p/ 闭塞），2.335 是 -37 dB、3 kHz、无周期的爆破，2.355 /t/ '
                                           '闭塞，2.375 /t/ 除阻，属于 postscript',
                                     '实测': {'最响dB': -40.0, '重心Hz': 2857, '周期': 0.0, '低频dB': -23.8}}},
          '高亮': {'S1 第2块': {'开始读': 10.385,
                            '配音指纹': 'fc0c3231837f',
                            '依据': '2026-10-29 33 实测：went 的 /w/ 在 S1 w 7.92 起是低频浊音起始（-41 dB），w 7.95 升到 -29 '
                                  'dB、7.96 -19 dB（开口），对应 a.wav 10.385s；高亮 10.37s 只差 0.015 s。甲 10.18s '
                                  '是带时长模型的时刻，没算前面 squad 和 went 之间删掉的 0.29 s 吸气（复核 shift -120 ms），不对'}},
          '中文重复': {'穿过': '用户 2026-10-29 原话：S7 ran through “这个也要成为重点词汇  意思对应 穿过”；S5 threading through '
                         '也是用户要求整体标重点、中文“穿过”（待改清单 9、15）。两处都是用户定的译法，保留'}},
 '结尾解说': '简述',
 '说明放宽特批': {'S16': {'倍数': '整屏',
                    '依据': '用户 2026-10-25 看 25 简述截图：“以后以后一定要合理的安排，不要压缩成这个样子……这个地方特批一下”（用户同意记录：原话适用以后各篇，26 '
                          '起沿用）'}},
 '非人声区间': {'S1': [[7.615, 7.895]],
           'S2': [[5.045, 5.285]],
           'S5': [[6.215, 6.555]],
           'S7': [[3.345, 3.485], [4.94, 5.265]],
           'S8': [[2.975, 3.165]],
           'S10': [[2.975, 3.18125, '紧贴词头']],
           'S11': [[4.47, 4.786125, '紧贴词头']],
           'S12': [[1.3, 1.52]],
           'S13': [[1.92, 2.175]],
           'S14': [[10.705, 11.006167, '紧贴词头']],
           'S15': [[4.866458, 5.025, '紧贴词尾']]},
 'allow_clash': ['blood infection'],
 '高亮按实际开口': True,
 '高亮开口门槛': 40,
 '术语': {'Tham Luang': '睡美人洞',
        'Thailand': '泰国',
        'Saman Kunan': '萨曼·古南',
        'Navy SEAL': '海军海豹突击队员',
        'Thai': '泰国',
        'British': '英国'},
 '结尾句': {'S16': {'前段语速': 0.9,
                 '最后一段语速': 0.78,
                 '最后一段前停顿': 0.7,
                 '接点': [55260, 66420],
                 '依据': '全篇结尾句按 07 定下的标准（用户 2026-10-10 同意并要求所有视频统一）：前段 0.9、最后一段“and two rescuers were mourned.” '
                       '0.78、前面停 0.7 秒。接点由 结尾句接点.py 自动找：0.9 那遍最后一个标点后最长静音（20 ms）的正中 2.303 s，0.78 那遍（40 ms）的正中 '
                       '2.768 s，所在帧和两侧各 5 ms 都低于 -55 dB（程序以 08 校准：与人工核实的接点落在同一段静音里）'}},
 '词尾除阻': {'S8': {'句末': [4.03, 't']}, 'S11': {'句末': [9.03, 't']}, 'S14': {'1': [2.85, 't']}},
 '区间声音指纹': {'S1': '8d0d4b6dd94d',
            'S2': '4e8505a2ba0d',
            'S5': '75f7d8f85437',
            'S7': 'b600972951fd',
            'S8': '3be5f9f44f15',
            'S10': '52da73921c28',
            'S11': '118d7fc052de',
            'S12': '1f7eef23f1c1',
            'S13': '16a8776c7406',
            'S14': '39c4b398f34f',
            'S15': 'df27bc5e8dff'}}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
